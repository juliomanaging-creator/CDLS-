# TABULA RASA PRESENTATIONS - CUSTOMIZATION GUIDE

## Overview
You now have three professional PowerPoint presentations ready to use:

1. **Tabula-Rasa-Master-Deck.pptx** (22 slides) - Complete comprehensive presentation
2. **Tabula-Rasa-Quick-Pitch-10-Slides.pptx** (10 slides) - Fast investor/partner meetings
3. **Tabula-Rasa-Dealer-Partners-15-Slides.pptx** (15 slides) - Dealer-focused presentation

## Design Elements

### Color Palette
- **Navy Blue (#16213E)**: Primary brand color - trust, stability, finance
- **Gold (#D4AF37)**: Accent color - opportunity, transformation, value
- **White/Light Gray**: Clean, professional backgrounds

### Typography
- **Headers**: Georgia (serif) - sophisticated, strategic
- **Body**: Arial (sans-serif) - clean, readable

## Customization Instructions

### Adding Your Contact Information

**Master Deck - Slide 1:**
- Replace "Julio" with your full name
- Add email address
- Add phone number
- Add LinkedIn URL if desired

**Quick Pitch - Slide 1:**
Same as above

**Dealer Version - Slide 15:**
- Add complete contact information
- Consider adding: Email, Phone, Website (tabularasamotors.com when ready)

### Updating Financial Data

**All Presentations:**
As your operations evolve, update these metrics:
- Unit counts (currently 20-30/month)
- Margins (currently 15-20%)
- Hold periods (currently 30-45 days)
- Year 1/Year 2 projections

**Location:**
- Master Deck: Slide 5 (metrics boxes), Slide 11 (projections)
- Quick Pitch: Slide 4 (metrics boxes), Slide 6 (projections)
- Dealer Version: Slide 5 (metrics boxes)

### Capital One Integration

**If/When You Join Capital One:**

Master Deck - Create new slide after Slide 6:
- Title: "Capital One Integration"
- Content: How your ASM role complements Tabula Rasa operations
- Benefits of insider perspective on dealer challenges

Quick Pitch - Slide 2:
- Add bullet: "Capital One Auto Finance ASM providing dealer insights"

### Adding Testimonials

**Dealer Version - Slide 13:**
Currently has placeholder testimonials. Replace with:
- Actual dealer quotes (with permission)
- Dealership names (if allowed)
- Specific results/outcomes

**Master Deck:**
Consider adding testimonials slide between Slides 14-15

### Sacramento Market Data

When you have specific market data, enhance:

**Master Deck - Slide 13:**
- Add specific Sacramento wholesale market size
- Regional dealer count
- Local competition analysis

### DBA Registration

Once "Tabula Rasa Automotive" DBA is registered:

**All Presentations:**
- Add DBA disclaimer on relevant slides
- Update legal entity structure slides
- Add license numbers if required for dealer presentations

### CalPERS Update

**Master Deck - Slide 7 & 15:**
When CalPERS submission progresses:
- Update status from "target" to specific stage
- Add any feedback or milestone dates
- Include LOI or commitment letters if received

### Website Integration

When tabularasamotors.com launches:

**All Presentations:**
- Add website URL to title slides
- Add QR code linking to website (optional but professional)
- Update contact slides with web presence

### Photos and Visuals

**Recommended Additions:**
1. Your professional headshot (Master Deck - Slide 15, Dealer Version - Slide 12)
2. Sacramento market photos (local dealerships, market presence)
3. Software screenshots (technology slides)
4. Vehicle inventory examples (Dealer Version - Slide 6)

**How to Add:**
1. Open PowerPoint
2. Insert > Pictures
3. Position and resize as needed
4. Maintain consistent placement across slides

### Presenter Notes

**Master Deck:**
Each slide benefits from presenter notes. Add:
- Key talking points
- Statistics to memorize
- Transition phrases
- Anticipated questions

**To Add Presenter Notes in PowerPoint:**
1. View > Notes Page
2. Type notes in bottom section
3. Print with notes for reference during presentation

## Using the Presentations

### For Investor Meetings
**Use: Quick Pitch (10 slides)**
- 15-20 minute presentation
- Leave time for questions
- Follow up with Master Deck
- Be ready to discuss financials in detail

### For Dealer Partnerships
**Use: Dealer Version (15 slides)**
- Focus on benefits to them
- Emphasize speed and fairness
- Be ready to review specific inventory
- Bring purchase examples/case studies

### For Strategic Partners (Finance, Logistics)
**Use: Master Deck (22 slides)**
- Show complete ecosystem vision
- Emphasize synergies
- Discuss long-term strategic value
- Explain how partnership fits their goals

### For Bank Financing
**Use: Master Deck (22 slides)**
- Focus on: Slides 1, 5, 11, 12, 14, 17
- Emphasize proven operations (Slide 5)
- Detail risk mitigation (Slide 12)
- Be ready with: Personal financial statement, credit report, business plan

## Print Versions

### Creating Handouts
1. File > Print
2. Settings > Full Page Slides > choose format:
   - **3 Slides** (with lines for notes) - Best for detailed meetings
   - **6 Slides** (compact) - Good for quick reference
   - **9 Slides** (very compact) - Overview handouts

### PDF Versions
1. File > Save As
2. Choose PDF format
3. Options > check "Document properties" and "ISO 19005-1 compliant (PDF/A)"

Create PDFs for:
- Email distribution (smaller file size)
- Website download (when ready)
- Archival/version control

## Presentation Delivery Tips

### Master Deck (Serious Investors/Partners)
- Pace: 2-3 minutes per slide = 45-60 minute presentation
- Skip slides if time limited: 8, 9, 13, 16 can be summarized verbally
- Focus on: Philosophy (1-4), Wholesale (5), Syndicate (7), Financials (11)

### Quick Pitch (First Meetings)
- Pace: 1.5-2 minutes per slide = 15-20 minutes
- Energy: Start strong with philosophy, close with vision
- Goal: Secure follow-up meeting with interest in Master Deck

### Dealer Version (Dealer Partners)
- Pace: 1.5-2 minutes per slide = 20-25 minutes
- Focus: Their pain points (Slide 2), Your solution (Slides 3-4, 9)
- Goal: Get them to share 1-2 aged units for evaluation

## Version Control

**Recommended File Naming:**
- Tabula-Rasa-Master-v1.0-2024-12-09.pptx
- Tabula-Rasa-Master-v1.1-2024-12-15.pptx (after first update)
- Keep dated versions in archive folder

**Track Changes:**
Create simple changelog document:
```
v1.0 (2024-12-09): Initial creation
v1.1 (2024-12-15): Updated contact info, added Q4 financials
v1.2 (2025-01-05): Added Capital One role integration
```

## Protecting Your Presentations

### Adding Password Protection (Optional)
1. File > Info > Protect Presentation
2. Choose "Encrypt with Password"
3. Use for confidential financial data versions

### Watermarking Draft Versions
1. Design > Watermark
2. Add "CONFIDENTIAL" or "DRAFT" for internal review versions

## Technical Notes

### File Format
- All presentations created in PowerPoint 2016+ compatible format
- Compatible with: PowerPoint, Google Slides, Keynote
- Web-safe fonts used: Georgia, Arial (universally available)

### Color Consistency
- Navy: RGB(22, 33, 62) or HEX #16213E
- Gold: RGB(212, 175, 55) or HEX #D4AF37
- Use exact colors when updating to maintain brand consistency

### Slide Dimensions
- 16:9 aspect ratio (standard widescreen)
- 10" x 5.625" slide size
- Optimized for: Projector, large screen, or laptop presentation

## Next Actions for You

**Immediate (This Week):**
1. ☐ Add your complete contact information to all three decks
2. ☐ Review each presentation start to finish
3. ☐ Practice delivering Quick Pitch out loud (aim for 15 minutes)
4. ☐ Create PDF versions for email distribution

**Short-term (Next 2 Weeks):**
1. ☐ Add professional headshot photo
2. ☐ Register DBA and update presentations
3. ☐ Update any financial numbers that have changed
4. ☐ Print handout versions for in-person meetings

**As Operations Progress:**
1. ☐ Add actual dealer testimonials (with permission)
2. ☐ Update unit counts and financial metrics monthly
3. ☐ Add website URL when domain launches
4. ☐ Screenshot your software for technology slides
5. ☐ Update Capital One status if/when you get the position

## Questions or Updates Needed?

If you need specific slides modified, customized versions for particular audiences, or additional presentation formats, just let me know what you need and I can create updated versions.

The presentations are designed to be professional, strategic, and adaptable as your business grows. They position you as a sophisticated operator with a unique strategic vision - exactly the Tabula Rasa brand identity we're building.

---

**Remember:** These presentations tell your story. Internalize the philosophy, believe in the model, and let your 14+ years of experience shine through in how you present. The slides support your expertise - they don't replace it.
