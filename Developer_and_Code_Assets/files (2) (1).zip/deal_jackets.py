"""
Virtual Deal Jacket System v1.0
For dealers without DMS - Manual operation support

Creates digital deal jackets from:
- Auction purchase history (CSV/PDF)
- Walk-in customer purchases
- Dealer-to-dealer purchases
- Email receipts (parts, repairs, etc.)

Each jacket tracks:
- Vehicle purchase details
- Parts ordered with receipts
- Repair costs
- Email receipts automatically attached
- Total cost calculation
- Profit margin tracking
"""

import os
import sys
import json
import hashlib
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path
import pandas as pd

# PDF parsing (optional)
try:
    import PyPDF2
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

# Email parsing (optional)
try:
    import email
    from email import policy
    EMAIL_AVAILABLE = True
except ImportError:
    EMAIL_AVAILABLE = False


class VirtualDealJacket:
    """
    A single deal jacket for one vehicle.
    Tracks all costs, receipts, and documents.
    """
    
    def __init__(self, vin: str, purchase_data: Dict):
        """
        Initialize deal jacket.
        
        Args:
            vin: Vehicle Identification Number
            purchase_data: Dict with purchase details
        """
        self.vin = vin
        self.created_date = datetime.now()
        self.jacket_id = self._generate_jacket_id()
        
        # Purchase information
        self.purchase_date = purchase_data.get('purchase_date')
        self.purchase_source = purchase_data.get('source', 'Unknown')  # Auction/Customer/Dealer
        self.purchase_price = float(purchase_data.get('price', 0))
        self.year = purchase_data.get('year')
        self.make = purchase_data.get('make')
        self.model = purchase_data.get('model')
        self.mileage = purchase_data.get('mileage')
        self.color = purchase_data.get('color')
        
        # Auction specific
        self.auction_name = purchase_data.get('auction_name')
        self.auction_location = purchase_data.get('auction_location')
        self.auction_lane = purchase_data.get('lane')
        self.auction_fees = float(purchase_data.get('auction_fees', 0))
        
        # Cost tracking
        self.parts_costs = []  # List of {date, description, cost, receipt_path}
        self.labor_costs = []  # List of {date, description, cost, receipt_path}
        self.other_costs = []  # List of {date, description, cost, receipt_path}
        
        # Documents
        self.receipts = []  # List of file paths
        self.emails = []  # List of parsed emails
        self.photos = []  # List of vehicle photos
        
        # Sale information (when sold)
        self.sale_date = None
        self.sale_price = None
        self.buyer_name = None
        self.sale_type = None  # Retail/Wholesale
        
        # Status tracking
        self.status = 'acquired'  # acquired/reconditioning/ready/sold
        self.notes = []

    def _generate_jacket_id(self) -> str:
        """Generate unique jacket ID."""
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        return f"DJ-{self.vin[-8:]}-{timestamp}"

    def add_parts_cost(self, description: str, cost: float, 
                       receipt_path: Optional[str] = None,
                       date: Optional[datetime] = None):
        """Add a parts expense."""
        self.parts_costs.append({
            'date': date or datetime.now(),
            'description': description,
            'cost': float(cost),
            'receipt_path': receipt_path
        })
        if receipt_path:
            self.receipts.append(receipt_path)

    def add_labor_cost(self, description: str, cost: float,
                       receipt_path: Optional[str] = None,
                       date: Optional[datetime] = None):
        """Add a labor expense."""
        self.labor_costs.append({
            'date': date or datetime.now(),
            'description': description,
            'cost': float(cost),
            'receipt_path': receipt_path
        })
        if receipt_path:
            self.receipts.append(receipt_path)

    def add_other_cost(self, description: str, cost: float,
                       receipt_path: Optional[str] = None,
                       date: Optional[datetime] = None):
        """Add other expenses (transport, title, etc.)."""
        self.other_costs.append({
            'date': date or datetime.now(),
            'description': description,
            'cost': float(cost),
            'receipt_path': receipt_path
        })
        if receipt_path:
            self.receipts.append(receipt_path)

    def add_email_receipt(self, email_path: str):
        """Parse and add email receipt."""
        if not EMAIL_AVAILABLE:
            print("Warning: email parsing not available")
            return
        
        try:
            with open(email_path, 'rb') as f:
                msg = email.message_from_binary_file(f, policy=policy.default)
            
            # Extract cost from email if possible
            subject = msg['subject']
            body = msg.get_body(preferencelist=('plain')).get_content()
            
            # Try to extract dollar amounts
            import re
            amounts = re.findall(r'\$[\d,]+\.?\d*', body)
            
            self.emails.append({
                'date': msg['date'],
                'from': msg['from'],
                'subject': subject,
                'body': body,
                'amounts_found': amounts,
                'file_path': email_path
            })
            
            print(f"Email receipt added: {subject}")
            if amounts:
                print(f"  Found amounts: {', '.join(amounts)}")
                print("  Please manually categorize this cost using add_parts_cost() or add_labor_cost()")
        
        except Exception as e:
            print(f"Error parsing email: {e}")

    def add_photo(self, photo_path: str):
        """Add vehicle photo."""
        self.photos.append(photo_path)

    def add_note(self, note: str):
        """Add a note to the jacket."""
        self.notes.append({
            'date': datetime.now(),
            'note': note
        })

    def mark_sold(self, sale_price: float, buyer_name: str, 
                  sale_type: str = 'retail'):
        """Mark vehicle as sold."""
        self.sale_date = datetime.now()
        self.sale_price = float(sale_price)
        self.buyer_name = buyer_name
        self.sale_type = sale_type
        self.status = 'sold'

    def calculate_total_cost(self) -> Dict[str, float]:
        """Calculate all costs."""
        parts_total = sum(item['cost'] for item in self.parts_costs)
        labor_total = sum(item['cost'] for item in self.labor_costs)
        other_total = sum(item['cost'] for item in self.other_costs)
        
        total_cost = (self.purchase_price + 
                     self.auction_fees + 
                     parts_total + 
                     labor_total + 
                     other_total)
        
        return {
            'purchase_price': self.purchase_price,
            'auction_fees': self.auction_fees,
            'parts_total': parts_total,
            'labor_total': labor_total,
            'other_total': other_total,
            'total_cost': total_cost
        }

    def calculate_profit(self) -> Optional[Dict[str, float]]:
        """Calculate profit if sold."""
        if not self.sale_price:
            return None
        
        costs = self.calculate_total_cost()
        profit = self.sale_price - costs['total_cost']
        profit_margin = (profit / self.sale_price * 100) if self.sale_price > 0 else 0
        
        return {
            'sale_price': self.sale_price,
            'total_cost': costs['total_cost'],
            'gross_profit': profit,
            'profit_margin': profit_margin
        }

    def to_dict(self) -> Dict:
        """Convert to dictionary for saving."""
        return {
            'jacket_id': self.jacket_id,
            'vin': self.vin,
            'created_date': self.created_date.isoformat(),
            'purchase_date': self.purchase_date,
            'purchase_source': self.purchase_source,
            'purchase_price': self.purchase_price,
            'vehicle': {
                'year': self.year,
                'make': self.make,
                'model': self.model,
                'mileage': self.mileage,
                'color': self.color
            },
            'auction': {
                'name': self.auction_name,
                'location': self.auction_location,
                'lane': self.auction_lane,
                'fees': self.auction_fees
            },
            'costs': {
                'parts': self.parts_costs,
                'labor': self.labor_costs,
                'other': self.other_costs
            },
            'documents': {
                'receipts': self.receipts,
                'emails': self.emails,
                'photos': self.photos
            },
            'sale': {
                'date': self.sale_date.isoformat() if self.sale_date else None,
                'price': self.sale_price,
                'buyer': self.buyer_name,
                'type': self.sale_type
            },
            'status': self.status,
            'notes': self.notes,
            'totals': self.calculate_total_cost(),
            'profit': self.calculate_profit()
        }

    def save(self, directory: str = 'deal_jackets'):
        """Save jacket to JSON file."""
        os.makedirs(directory, exist_ok=True)
        
        filename = f"{self.jacket_id}.json"
        filepath = os.path.join(directory, filename)
        
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, indent=2, default=str)
        
        return filepath


class DealJacketManager:
    """
    Manages all deal jackets for a dealership.
    Creates jackets from various sources.
    """
    
    def __init__(self, dealer_name: str = "My Dealership"):
        self.dealer_name = dealer_name
        self.jackets = {}  # VIN -> VirtualDealJacket
        self.jacket_directory = 'deal_jackets'
        os.makedirs(self.jacket_directory, exist_ok=True)
        
        # Load existing jackets
        self._load_existing_jackets()

    def _load_existing_jackets(self):
        """Load all existing jackets from disk."""
        if not os.path.exists(self.jacket_directory):
            return
        
        for filename in os.listdir(self.jacket_directory):
            if filename.endswith('.json'):
                filepath = os.path.join(self.jacket_directory, filename)
                try:
                    with open(filepath, 'r') as f:
                        data = json.load(f)
                    
                    # Reconstruct jacket from saved data
                    # (Simplified - you'd fully reconstruct)
                    vin = data['vin']
                    print(f"Loaded jacket: {data['jacket_id']} ({vin})")
                except Exception as e:
                    print(f"Error loading {filename}: {e}")

    def create_jacket_from_auction_csv(self, csv_path: str) -> List[VirtualDealJacket]:
        """
        Create deal jackets from auction purchase CSV.
        
        Expected CSV columns:
        - vin, year, make, model, purchase_date, purchase_price
        - auction_name, auction_location, auction_fees
        """
        df = pd.read_csv(csv_path)
        
        created_jackets = []
        
        for idx, row in df.iterrows():
            vin = str(row.get('vin', '')).strip()
            
            if not vin or len(vin) != 17:
                print(f"Row {idx}: Invalid VIN, skipping")
                continue
            
            purchase_data = {
                'purchase_date': row.get('purchase_date'),
                'source': 'Auction',
                'price': row.get('purchase_price', 0),
                'year': row.get('year'),
                'make': row.get('make'),
                'model': row.get('model'),
                'mileage': row.get('mileage'),
                'color': row.get('color'),
                'auction_name': row.get('auction_name'),
                'auction_location': row.get('auction_location'),
                'lane': row.get('lane'),
                'auction_fees': row.get('auction_fees', 0)
            }
            
            jacket = VirtualDealJacket(vin, purchase_data)
            jacket.save(self.jacket_directory)
            
            self.jackets[vin] = jacket
            created_jackets.append(jacket)
            
            print(f"✓ Created jacket for {vin} - {row.get('year')} {row.get('make')} {row.get('model')}")
        
        return created_jackets

    def create_jacket_from_auction_pdf(self, pdf_path: str) -> List[VirtualDealJacket]:
        """
        Create deal jackets from auction purchase PDF.
        
        Attempts to extract purchase information from PDF invoice.
        """
        if not PDF_AVAILABLE:
            print("Error: PyPDF2 not installed. Install with: pip install PyPDF2")
            return []
        
        try:
            with open(pdf_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                text = ""
                for page in reader.pages:
                    text += page.extract_text()
            
            # Parse text to extract vehicle information
            # (This is simplified - real implementation would be more sophisticated)
            import re
            
            # Look for VIN (17 characters, alphanumeric)
            vins = re.findall(r'\b[A-HJ-NPR-Z0-9]{17}\b', text)
            
            # Look for prices
            prices = re.findall(r'\$[\d,]+\.?\d*', text)
            
            print(f"Found {len(vins)} VINs and {len(prices)} prices in PDF")
            
            # Create jackets (simplified - would need better parsing)
            created_jackets = []
            
            for vin in vins:
                purchase_data = {
                    'purchase_date': datetime.now().strftime('%Y-%m-%d'),
                    'source': 'Auction (PDF)',
                    'price': 0,  # Would extract from PDF
                    'year': None,
                    'make': None,
                    'model': None
                }
                
                jacket = VirtualDealJacket(vin, purchase_data)
                jacket.add_note(f"Created from PDF: {os.path.basename(pdf_path)}")
                jacket.add_note("Please verify purchase price and vehicle details")
                jacket.save(self.jacket_directory)
                
                self.jackets[vin] = jacket
                created_jackets.append(jacket)
                
                print(f"✓ Created jacket for {vin} (verify details)")
            
            return created_jackets
            
        except Exception as e:
            print(f"Error parsing PDF: {e}")
            return []

    def create_jacket_manual(self, vin: str, year: int, make: str, model: str,
                           purchase_price: float, purchase_source: str = 'Manual',
                           purchase_date: Optional[str] = None) -> VirtualDealJacket:
        """
        Manually create a deal jacket.
        For walk-in purchases or dealer-to-dealer.
        """
        purchase_data = {
            'purchase_date': purchase_date or datetime.now().strftime('%Y-%m-%d'),
            'source': purchase_source,
            'price': purchase_price,
            'year': year,
            'make': make,
            'model': model
        }
        
        jacket = VirtualDealJacket(vin, purchase_data)
        jacket.save(self.jacket_directory)
        
        self.jackets[vin] = jacket
        
        print(f"✓ Created jacket for {vin} - {year} {make} {model}")
        
        return jacket

    def get_jacket(self, vin: str) -> Optional[VirtualDealJacket]:
        """Get jacket by VIN."""
        return self.jackets.get(vin)

    def add_receipt_to_jacket(self, vin: str, receipt_path: str,
                             category: str = 'parts',
                             description: str = '',
                             amount: float = 0):
        """
        Add a receipt to an existing jacket.
        
        Args:
            vin: Vehicle VIN
            receipt_path: Path to receipt file (PDF, JPG, PNG, email)
            category: 'parts', 'labor', or 'other'
            description: What the receipt is for
            amount: Cost amount
        """
        jacket = self.get_jacket(vin)
        
        if not jacket:
            print(f"Error: No jacket found for VIN {vin}")
            return
        
        # Check if it's an email
        if receipt_path.endswith('.eml') or receipt_path.endswith('.msg'):
            jacket.add_email_receipt(receipt_path)
        else:
            # Regular receipt
            if category == 'parts':
                jacket.add_parts_cost(description, amount, receipt_path)
            elif category == 'labor':
                jacket.add_labor_cost(description, amount, receipt_path)
            else:
                jacket.add_other_cost(description, amount, receipt_path)
        
        jacket.save(self.jacket_directory)
        print(f"✓ Added {category} receipt to jacket {vin}")

    def generate_cost_report(self, vin: Optional[str] = None) -> pd.DataFrame:
        """
        Generate cost report for one or all vehicles.
        """
        data = []
        
        jackets_to_report = [self.jackets[vin]] if vin else self.jackets.values()
        
        for jacket in jackets_to_report:
            costs = jacket.calculate_total_cost()
            profit = jacket.calculate_profit()
            
            data.append({
                'VIN': jacket.vin,
                'Vehicle': f"{jacket.year} {jacket.make} {jacket.model}",
                'Purchase Price': costs['purchase_price'],
                'Auction Fees': costs['auction_fees'],
                'Parts': costs['parts_total'],
                'Labor': costs['labor_total'],
                'Other': costs['other_total'],
                'Total Cost': costs['total_cost'],
                'Sale Price': jacket.sale_price or 0,
                'Profit': profit['gross_profit'] if profit else 0,
                'Margin %': profit['profit_margin'] if profit else 0,
                'Status': jacket.status
            })
        
        return pd.DataFrame(data)

    def list_all_jackets(self):
        """List all jackets with summary."""
        print(f"\n{'='*70}")
        print(f"Deal Jackets - {self.dealer_name}")
        print(f"{'='*70}\n")
        
        if not self.jackets:
            print("No jackets found.")
            return
        
        for vin, jacket in self.jackets.items():
            costs = jacket.calculate_total_cost()
            
            print(f"VIN: {vin}")
            print(f"  Vehicle: {jacket.year} {jacket.make} {jacket.model}")
            print(f"  Purchased: {jacket.purchase_date} from {jacket.purchase_source}")
            print(f"  Total Cost: ${costs['total_cost']:,.2f}")
            
            if jacket.sale_price:
                profit = jacket.calculate_profit()
                print(f"  Sold: ${jacket.sale_price:,.2f}")
                print(f"  Profit: ${profit['gross_profit']:,.2f} ({profit['profit_margin']:.1f}%)")
            else:
                print(f"  Status: {jacket.status}")
            
            print(f"  Receipts: {len(jacket.receipts)}")
            print()


# CLI Interface
def main():
    """Command-line interface for deal jacket management."""
    
    print("\n" + "="*70)
    print("Virtual Deal Jacket System v1.0")
    print("For dealers without DMS systems")
    print("="*70 + "\n")
    
    manager = DealJacketManager()
    
    while True:
        print("\nOptions:")
        print("  1. Create jackets from auction CSV")
        print("  2. Create jackets from auction PDF")
        print("  3. Create jacket manually")
        print("  4. Add receipt to existing jacket")
        print("  5. View all jackets")
        print("  6. Generate cost report")
        print("  7. Exit")
        
        choice = input("\nSelect option (1-7): ").strip()
        
        if choice == '1':
            csv_path = input("Enter path to auction CSV file: ").strip()
            if os.path.exists(csv_path):
                manager.create_jacket_from_auction_csv(csv_path)
            else:
                print(f"File not found: {csv_path}")
        
        elif choice == '2':
            pdf_path = input("Enter path to auction PDF file: ").strip()
            if os.path.exists(pdf_path):
                manager.create_jacket_from_auction_pdf(pdf_path)
            else:
                print(f"File not found: {pdf_path}")
        
        elif choice == '3':
            print("\nManual Jacket Creation:")
            vin = input("VIN (17 characters): ").strip()
            year = int(input("Year: "))
            make = input("Make: ").strip()
            model = input("Model: ").strip()
            price = float(input("Purchase price: $"))
            source = input("Source (Customer/Dealer/Auction): ").strip() or "Manual"
            
            manager.create_jacket_manual(vin, year, make, model, price, source)
        
        elif choice == '4':
            vin = input("VIN: ").strip()
            receipt_path = input("Receipt file path: ").strip()
            category = input("Category (parts/labor/other): ").strip().lower()
            description = input("Description: ").strip()
            amount = float(input("Amount: $"))
            
            manager.add_receipt_to_jacket(vin, receipt_path, category, description, amount)
        
        elif choice == '5':
            manager.list_all_jackets()
        
        elif choice == '6':
            report = manager.generate_cost_report()
            print("\n" + "="*70)
            print("COST REPORT")
            print("="*70)
            print(report.to_string(index=False))
            print("\n")
            
            # Save to CSV
            report_path = f"cost_report_{datetime.now().strftime('%Y%m%d')}.csv"
            report.to_csv(report_path, index=False)
            print(f"Report saved to: {report_path}")
        
        elif choice == '7':
            print("\nGoodbye!")
            break
        
        else:
            print("Invalid option. Please try again.")


if __name__ == '__main__':
    main()
