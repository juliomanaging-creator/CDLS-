@echo off
REM ============================================
REM S.A.L.S.A. Complete v2.0 - Windows Launcher
REM Sacramento Auto Leaders Supporting Alliance
REM ============================================

title S.A.L.S.A. Dealer Audit System v2.0
color 0A

echo.
echo ========================================================================
echo.
echo    S.A.L.S.A. - Sacramento Auto Leaders Supporting Alliance
echo    Dealer Compliance Audit System v2.0
echo.
echo ========================================================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found!
    echo.
    echo Please install Python 3.10 or newer from python.org
    echo.
    pause
    exit /b 1
)

echo [1/4] Checking Python... OK
echo.

REM Check if dependencies are installed
python -c "import pandas" >nul 2>&1
if %errorlevel% neq 0 (
    echo [2/4] Installing dependencies...
    echo This may take a few minutes on first run...
    echo.
    python -m pip install -r requirements.txt --quiet
    if %errorlevel% neq 0 (
        echo [ERROR] Dependency installation failed!
        echo.
        echo Try running: python -m pip install -r requirements.txt
        echo.
        pause
        exit /b 1
    )
    echo Dependencies installed successfully!
    echo.
) else (
    echo [2/4] Checking dependencies... OK
    echo.
)

REM Check if Ollama is running
echo [3/4] Checking Ollama AI engine...
tasklist /nh /fi "imagename eq ollama.exe" | find /i "ollama.exe" >nul
if %errorlevel% neq 0 (
    echo Ollama not running. Attempting to start...
    start "" ollama serve >nul 2>&1
    timeout /t 5 /nobreak >nul
    
    REM Check again
    tasklist /nh /fi "imagename eq ollama.exe" | find /i "ollama.exe" >nul
    if %errorlevel% neq 0 (
        echo [WARNING] Ollama not available. System will use rule-based analysis.
        echo For AI-powered analysis, install Ollama from: https://ollama.ai
        echo.
    ) else (
        echo Ollama started successfully!
        echo.
    )
) else (
    echo Ollama running... OK
    echo.
)

REM Check if model is available
if exist "ollama.exe" (
    ollama list | find "llama3.2:3b" >nul
    if %errorlevel% neq 0 (
        echo [INFO] llama3.2:3b model not found.
        echo Downloading model (this may take a few minutes)...
        ollama pull llama3.2:3b
    )
)

echo [4/4] Starting S.A.L.S.A. Engine...
echo.
echo ========================================================================
echo  READY FOR ANALYSIS
echo ========================================================================
echo.
echo  To analyze a file:
echo    python core/engine.py data_input/your_file.csv
echo.
echo  Or drag your CSV file to this window and press Enter
echo.
echo ========================================================================
echo.

REM If file was dropped onto launcher, process it
if "%~1"=="" (
    REM No file provided, show instructions
    echo Waiting for file path...
    echo.
    set /p FILEPATH="Enter path to CSV file (or press Ctrl+C to exit): "
    
    if not "!FILEPATH!"=="" (
        echo.
        echo Processing: !FILEPATH!
        echo.
        python core/engine.py "!FILEPATH!"
    )
) else (
    REM File was provided as argument
    echo Processing: %~1
    echo.
    python core/engine.py "%~1"
)

echo.
echo ========================================================================
echo  Analysis Complete!
echo  Check audit_output/ and audit_reports_pdf/ for reports
echo ========================================================================
echo.
pause
