"""
Easy Deal Jacket Creator
Drop your purchase files here and go!

Supports:
- Auction CSV exports
- Auction PDF invoices  
- Manual entry
- Email receipts
"""

import os
import sys
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.deal_jackets import DealJacketManager, VirtualDealJacket


def quick_start():
    """Quick start wizard for non-technical dealers."""
    
    print("\n" + "="*70)
    print(" Welcome to Virtual Deal Jacket System!")
    print(" Track all your vehicle purchases and costs in one place")
    print("="*70 + "\n")
    
    manager = DealJacketManager("My Dealership")
    
    print("What would you like to do?\n")
    print("1. I bought vehicles at auction (I have CSV or PDF)")
    print("2. I bought a vehicle from a customer")
    print("3. I bought a vehicle from another dealer")
    print("4. I want to add a parts receipt to an existing vehicle")
    print("5. Show me all my vehicles and costs")
    print()
    
    choice = input("Enter number (1-5): ").strip()
    
    if choice == '1':
        import_auction_purchases(manager)
    
    elif choice == '2':
        create_customer_purchase(manager)
    
    elif choice == '3':
        create_dealer_purchase(manager)
    
    elif choice == '4':
        add_receipt(manager)
    
    elif choice == '5':
        show_inventory(manager)
    
    else:
        print("Invalid choice. Run again and select 1-5.")


def import_auction_purchases(manager):
    """Import from auction files."""
    print("\n" + "-"*70)
    print(" Import Auction Purchases")
    print("-"*70 + "\n")
    
    print("Do you have:")
    print("1. CSV file (Excel spreadsheet)")
    print("2. PDF invoice")
    print()
    
    file_type = input("Enter 1 or 2: ").strip()
    
    file_path = input("\nDrag and drop your file here (or type path): ").strip()
    file_path = file_path.replace("'", "").replace('"', '')
    
    if not os.path.exists(file_path):
        print(f"\nError: File not found: {file_path}")
        print("Make sure you dragged the file correctly.")
        return
    
    print(f"\nProcessing: {os.path.basename(file_path)}")
    print("This may take a moment...\n")
    
    if file_type == '1' and file_path.lower().endswith('.csv'):
        jackets = manager.create_jacket_from_auction_csv(file_path)
        print(f"\n✅ Success! Created {len(jackets)} deal jackets.")
    
    elif file_type == '2' and file_path.lower().endswith('.pdf'):
        jackets = manager.create_jacket_from_auction_pdf(file_path)
        print(f"\n✅ Success! Created {len(jackets)} deal jackets.")
        print("⚠️  Note: Please verify vehicle details and prices.")
    
    else:
        print("\n❌ Error: File type doesn't match selection.")
        print("CSV files end with .csv")
        print("PDF files end with .pdf")
        return
    
    if jackets:
        print(f"\nYour deal jackets are saved in: deal_jackets/")
        print("\nNext steps:")
        print("1. Add parts receipts as you buy them")
        print("2. Track repair costs")
        print("3. Update when you sell the vehicle")


def create_customer_purchase(manager):
    """Create jacket for customer walk-in purchase."""
    print("\n" + "-"*70)
    print(" Customer Walk-In Purchase")
    print("-"*70 + "\n")
    
    print("I'll ask a few questions about the vehicle:\n")
    
    vin = input("VIN (17 characters, found on title): ").strip().upper()
    
    if len(vin) != 17:
        print(f"\n❌ Error: VIN must be 17 characters. You entered {len(vin)}.")
        print("Check the title and try again.")
        return
    
    year = input("Year: ").strip()
    make = input("Make (Ford, Toyota, etc.): ").strip()
    model = input("Model (F-150, Camry, etc.): ").strip()
    
    price_str = input("How much did you pay? $").strip().replace(',', '')
    try:
        price = float(price_str)
    except:
        print(f"\n❌ Error: Invalid price: {price_str}")
        return
    
    customer_name = input("Customer name (optional): ").strip()
    
    # Create the jacket
    jacket = manager.create_jacket_manual(
        vin=vin,
        year=int(year),
        make=make,
        model=model,
        purchase_price=price,
        purchase_source=f"Customer: {customer_name}" if customer_name else "Customer"
    )
    
    print(f"\n✅ Deal jacket created for {year} {make} {model}!")
    print(f"   VIN: {vin}")
    print(f"   Purchase Price: ${price:,.2f}")
    print(f"\nJacket ID: {jacket.jacket_id}")
    print(f"Saved to: deal_jackets/{jacket.jacket_id}.json")
    
    # Ask about immediate costs
    print("\nDo you have any receipts to add right now? (parts, repairs, etc.)")
    add_now = input("Enter 'y' for yes, anything else to skip: ").strip().lower()
    
    if add_now == 'y':
        add_receipt_interactive(manager, vin)


def create_dealer_purchase(manager):
    """Create jacket for dealer-to-dealer purchase."""
    print("\n" + "-"*70)
    print(" Dealer-to-Dealer Purchase")
    print("-"*70 + "\n")
    
    vin = input("VIN: ").strip().upper()
    
    if len(vin) != 17:
        print(f"\n❌ Error: VIN must be 17 characters.")
        return
    
    year = input("Year: ").strip()
    make = input("Make: ").strip()
    model = input("Model: ").strip()
    
    price_str = input("Purchase price: $").strip().replace(',', '')
    try:
        price = float(price_str)
    except:
        print(f"\n❌ Error: Invalid price")
        return
    
    dealer_name = input("Dealer name: ").strip()
    
    jacket = manager.create_jacket_manual(
        vin=vin,
        year=int(year),
        make=make,
        model=model,
        purchase_price=price,
        purchase_source=f"Dealer: {dealer_name}"
    )
    
    print(f"\n✅ Deal jacket created!")
    print(f"Jacket ID: {jacket.jacket_id}")


def add_receipt(manager):
    """Add receipt to existing vehicle."""
    print("\n" + "-"*70)
    print(" Add Receipt to Vehicle")
    print("-"*70 + "\n")
    
    # Show existing vehicles
    if not manager.jackets:
        print("No vehicles in system yet.")
        print("Create a vehicle first (option 1, 2, or 3)")
        return
    
    print("Your vehicles:\n")
    for idx, (vin, jacket) in enumerate(manager.jackets.items(), 1):
        print(f"{idx}. {jacket.year} {jacket.make} {jacket.model} (VIN: {vin})")
    
    print()
    vin = input("Enter VIN (or number from list): ").strip().upper()
    
    # Handle number selection
    if vin.isdigit():
        idx = int(vin) - 1
        if 0 <= idx < len(manager.jackets):
            vin = list(manager.jackets.keys())[idx]
        else:
            print("Invalid number")
            return
    
    if vin not in manager.jackets:
        print(f"Vehicle {vin} not found.")
        return
    
    add_receipt_interactive(manager, vin)


def add_receipt_interactive(manager, vin):
    """Interactive receipt adding."""
    jacket = manager.jackets[vin]
    
    print(f"\nAdding receipt to: {jacket.year} {jacket.make} {jacket.model}")
    print()
    
    print("What type of expense?")
    print("1. Parts (oil, filters, brakes, etc.)")
    print("2. Labor (mechanic, body shop, detailing)")
    print("3. Other (transport, title fees, etc.)")
    print()
    
    expense_type = input("Enter 1, 2, or 3: ").strip()
    
    category_map = {'1': 'parts', '2': 'labor', '3': 'other'}
    category = category_map.get(expense_type, 'other')
    
    description = input("What is this for? ").strip()
    
    amount_str = input("Amount: $").strip().replace(',', '')
    try:
        amount = float(amount_str)
    except:
        print("Invalid amount")
        return
    
    print("\nDo you have a receipt file? (PDF, image, or email)")
    has_file = input("Enter 'y' if yes, 'n' if no: ").strip().lower()
    
    receipt_path = None
    if has_file == 'y':
        receipt_path = input("Drag receipt file here: ").strip()
        receipt_path = receipt_path.replace("'", "").replace('"', '')
        
        if not os.path.exists(receipt_path):
            print(f"File not found: {receipt_path}")
            print("Receipt will be added without file.")
            receipt_path = None
    
    # Add the cost
    if category == 'parts':
        jacket.add_parts_cost(description, amount, receipt_path)
    elif category == 'labor':
        jacket.add_labor_cost(description, amount, receipt_path)
    else:
        jacket.add_other_cost(description, amount, receipt_path)
    
    jacket.save(manager.jacket_directory)
    
    print(f"\n✅ Added ${amount:,.2f} for {description}")
    
    # Show updated totals
    costs = jacket.calculate_total_cost()
    print(f"\nUpdated total cost: ${costs['total_cost']:,.2f}")
    print(f"  Purchase: ${costs['purchase_price']:,.2f}")
    print(f"  Parts: ${costs['parts_total']:,.2f}")
    print(f"  Labor: ${costs['labor_total']:,.2f}")
    print(f"  Other: ${costs['other_total']:,.2f}")


def show_inventory(manager):
    """Show all vehicles with costs."""
    print("\n" + "="*70)
    print(" Your Inventory")
    print("="*70 + "\n")
    
    if not manager.jackets:
        print("No vehicles in system yet.\n")
        return
    
    for vin, jacket in manager.jackets.items():
        costs = jacket.calculate_total_cost()
        
        print(f"{jacket.year} {jacket.make} {jacket.model}")
        print(f"VIN: {vin}")
        print(f"Purchased: {jacket.purchase_date} from {jacket.purchase_source}")
        print(f"\nCosts:")
        print(f"  Purchase Price: ${costs['purchase_price']:>10,.2f}")
        
        if costs['auction_fees'] > 0:
            print(f"  Auction Fees:   ${costs['auction_fees']:>10,.2f}")
        
        if costs['parts_total'] > 0:
            print(f"  Parts:          ${costs['parts_total']:>10,.2f}")
            print(f"    ({len(jacket.parts_costs)} items)")
        
        if costs['labor_total'] > 0:
            print(f"  Labor:          ${costs['labor_total']:>10,.2f}")
            print(f"    ({len(jacket.labor_costs)} items)")
        
        if costs['other_total'] > 0:
            print(f"  Other:          ${costs['other_total']:>10,.2f}")
            print(f"    ({len(jacket.other_costs)} items)")
        
        print(f"  {'─'*30}")
        print(f"  TOTAL COST:     ${costs['total_cost']:>10,.2f}")
        
        if jacket.sale_price:
            profit = jacket.calculate_profit()
            print(f"\n  Sold for:       ${jacket.sale_price:>10,.2f}")
            print(f"  Profit:         ${profit['gross_profit']:>10,.2f}")
            print(f"  Margin:         {profit['profit_margin']:>10.1f}%")
        else:
            print(f"\n  Status: {jacket.status.upper()}")
        
        print(f"\nReceipts: {len(jacket.receipts)} files")
        print(f"Jacket ID: {jacket.jacket_id}")
        print("\n" + "-"*70 + "\n")
    
    # Summary
    total_invested = sum(
        jacket.calculate_total_cost()['total_cost'] 
        for jacket in manager.jackets.values() 
        if not jacket.sale_price
    )
    
    print("SUMMARY:")
    print(f"  Total vehicles: {len(manager.jackets)}")
    print(f"  In inventory: {sum(1 for j in manager.jackets.values() if not j.sale_price)}")
    print(f"  Sold: {sum(1 for j in manager.jackets.values() if j.sale_price)}")
    print(f"  Total invested: ${total_invested:,.2f}")
    print()


if __name__ == '__main__':
    try:
        quick_start()
    except KeyboardInterrupt:
        print("\n\nExiting...")
    except Exception as e:
        print(f"\n\nError: {e}")
        import traceback
        traceback.print_exc()
        print("\nIf you need help, save this error and contact support.")
