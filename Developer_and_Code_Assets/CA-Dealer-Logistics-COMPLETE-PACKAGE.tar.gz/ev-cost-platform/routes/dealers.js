const express = require('express');
const router = express.Router();
const { protect, restrictTo } = require('../middleware/auth');
const { validateDealer, validateId, validate } = require('../middleware/validation');
const dealerController = require('../controllers/dealerController');

/**
 * @route   GET /api/dealers
 * @desc    Get all dealers (syndicate members)
 * @access  Private
 */
router.get(
  '/',
  protect,
  dealerController.getAllDealers
);

/**
 * @route   POST /api/dealers
 * @desc    Create new dealer
 * @access  Private - Admin only
 */
router.post(
  '/',
  protect,
  restrictTo('admin'),
  validateDealer,
  validate,
  dealerController.createDealer
);

/**
 * @route   GET /api/dealers/:id
 * @desc    Get dealer by ID
 * @access  Private
 */
router.get(
  '/:id',
  protect,
  validateId,
  validate,
  dealerController.getDealerById
);

/**
 * @route   PUT /api/dealers/:id
 * @desc    Update dealer
 * @access  Private - Admin or dealer owner
 */
router.put(
  '/:id',
  protect,
  validateId,
  validateDealer,
  validate,
  dealerController.updateDealer
);

/**
 * @route   DELETE /api/dealers/:id
 * @desc    Delete/deactivate dealer
 * @access  Private - Admin only
 */
router.delete(
  '/:id',
  protect,
  restrictTo('admin'),
  validateId,
  validate,
  dealerController.deleteDealer
);

/**
 * @route   GET /api/dealers/nearby
 * @desc    Find dealers near coordinates
 * @access  Private
 */
router.get(
  '/search/nearby',
  protect,
  dealerController.getNearbyDealers
);

/**
 * @route   GET /api/dealers/:id/charging
 * @desc    Get charging info for dealer
 * @access  Private
 */
router.get(
  '/:id/charging',
  protect,
  validateId,
  validate,
  dealerController.getDealerCharging
);

module.exports = router;
