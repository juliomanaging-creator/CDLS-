const express = require('express');
const router = express.Router();
const { protect, restrictTo } = require('../middleware/auth');
const { validateCostComparison, validate } = require('../middleware/validation');
const costController = require('../controllers/costController');

/**
 * @route   POST /api/cost-comparison/calculate
 * @desc    Calculate cost comparison for a route
 * @access  Private
 */
router.post(
  '/calculate',
  protect,
  validateCostComparison,
  validate,
  costController.calculateCostComparison
);

/**
 * @route   GET /api/cost-comparison/history
 * @desc    Get user's calculation history
 * @access  Private
 */
router.get(
  '/history',
  protect,
  costController.getCalculationHistory
);

/**
 * @route   GET /api/cost-comparison/:id
 * @desc    Get specific calculation by ID
 * @access  Private
 */
router.get(
  '/:id',
  protect,
  costController.getCalculationById
);

/**
 * @route   POST /api/cost-comparison/save
 * @desc    Save calculation for future reference
 * @access  Private
 */
router.post(
  '/save',
  protect,
  costController.saveCalculation
);

/**
 * @route   GET /api/cost-comparison/syndicate/aggregate
 * @desc    Get aggregated syndicate costs
 * @access  Private - Syndicate Admin only
 */
router.get(
  '/syndicate/aggregate',
  protect,
  restrictTo('admin', 'syndicate_manager'),
  costController.getSyndicateAggregate
);

module.exports = router;
