const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { validateIncentiveSearch, validate } = require('../middleware/validation');
const incentiveController = require('../controllers/incentiveController');

/**
 * @route   GET /api/incentives
 * @desc    Get all available incentives
 * @access  Public
 */
router.get(
  '/',
  validateIncentiveSearch,
  validate,
  incentiveController.getAllIncentives
);

/**
 * @route   GET /api/incentives/:id
 * @desc    Get incentive by ID
 * @access  Public
 */
router.get(
  '/:id',
  incentiveController.getIncentiveById
);

/**
 * @route   POST /api/incentives/check-eligibility
 * @desc    Check eligibility for incentives
 * @access  Private
 */
router.post(
  '/check-eligibility',
  protect,
  incentiveController.checkEligibility
);

/**
 * @route   GET /api/incentives/expiring-soon
 * @desc    Get incentives expiring in next 90 days
 * @access  Public
 */
router.get(
  '/alerts/expiring-soon',
  incentiveController.getExpiringSoon
);

module.exports = router;
