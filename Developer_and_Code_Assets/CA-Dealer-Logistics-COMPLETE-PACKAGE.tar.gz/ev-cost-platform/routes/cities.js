const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { validateCitySearch, validatePagination, validate } = require('../middleware/validation');
const cityController = require('../controllers/cityController');

/**
 * @route   GET /api/cities
 * @desc    Get all cities with pricing data
 * @access  Public
 */
router.get(
  '/',
  validateCitySearch,
  validatePagination,
  validate,
  cityController.getAllCities
);

/**
 * @route   GET /api/cities/:id
 * @desc    Get city details by ID
 * @access  Public
 */
router.get(
  '/:id',
  cityController.getCityById
);

/**
 * @route   GET /api/cities/:id/prices
 * @desc    Get current fuel and EV prices for a city
 * @access  Public
 */
router.get(
  '/:id/prices',
  cityController.getCityPrices
);

/**
 * @route   GET /api/cities/:id/charging-stations
 * @desc    Get charging stations in a city
 * @access  Public
 */
router.get(
  '/:id/charging-stations',
  cityController.getChargingStations
);

/**
 * @route   GET /api/cities/compare
 * @desc    Compare pricing across multiple cities
 * @access  Public
 */
router.get(
  '/compare',
  cityController.compareCities
);

module.exports = router;
