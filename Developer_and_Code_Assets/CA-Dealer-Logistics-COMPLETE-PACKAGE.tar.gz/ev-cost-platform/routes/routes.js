const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { validateRouteCreation, validateId, validate } = require('../middleware/validation');
const routeController = require('../controllers/routeController');

/**
 * @route   GET /api/routes
 * @desc    Get all routes for current user/dealer
 * @access  Private
 */
router.get(
  '/',
  protect,
  routeController.getRoutes
);

/**
 * @route   POST /api/routes
 * @desc    Create new route
 * @access  Private
 */
router.post(
  '/',
  protect,
  validateRouteCreation,
  validate,
  routeController.createRoute
);

/**
 * @route   GET /api/routes/:id
 * @desc    Get route by ID
 * @access  Private
 */
router.get(
  '/:id',
  protect,
  validateId,
  validate,
  routeController.getRouteById
);

/**
 * @route   PUT /api/routes/:id
 * @desc    Update route
 * @access  Private
 */
router.put(
  '/:id',
  protect,
  validateId,
  validateRouteCreation,
  validate,
  routeController.updateRoute
);

/**
 * @route   DELETE /api/routes/:id
 * @desc    Delete route
 * @access  Private
 */
router.delete(
  '/:id',
  protect,
  validateId,
  validate,
  routeController.deleteRoute
);

/**
 * @route   GET /api/routes/:id/optimize
 * @desc    Get optimized route with charging stops
 * @access  Private
 */
router.get(
  '/:id/optimize',
  protect,
  validateId,
  validate,
  routeController.optimizeRoute
);

module.exports = router;
