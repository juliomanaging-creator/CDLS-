const express = require('express');
const router = express.Router();
const { validateLogin, validateRegistration, validate } = require('../middleware/validation');
const { protect } = require('../middleware/auth');
const authController = require('../controllers/authController');

/**
 * @route   POST /api/auth/register
 * @desc    Register new dealer/user
 * @access  Public
 */
router.post(
  '/register',
  validateRegistration,
  validate,
  authController.register
);

/**
 * @route   POST /api/auth/login
 * @desc    Login user
 * @access  Public
 */
router.post(
  '/login',
  validateLogin,
  validate,
  authController.login
);

/**
 * @route   POST /api/auth/logout
 * @desc    Logout user
 * @access  Private
 */
router.post(
  '/logout',
  protect,
  authController.logout
);

/**
 * @route   GET /api/auth/me
 * @desc    Get current user profile
 * @access  Private
 */
router.get(
  '/me',
  protect,
  authController.getMe
);

/**
 * @route   PUT /api/auth/update-password
 * @desc    Update password
 * @access  Private
 */
router.put(
  '/update-password',
  protect,
  authController.updatePassword
);

/**
 * @route   POST /api/auth/forgot-password
 * @desc    Request password reset
 * @access  Public
 */
router.post(
  '/forgot-password',
  authController.forgotPassword
);

/**
 * @route   POST /api/auth/reset-password/:token
 * @desc    Reset password with token
 * @access  Public
 */
router.post(
  '/reset-password/:token',
  authController.resetPassword
);

/**
 * @route   POST /api/auth/refresh-token
 * @desc    Refresh JWT token
 * @access  Private
 */
router.post(
  '/refresh-token',
  protect,
  authController.refreshToken
);

module.exports = router;
