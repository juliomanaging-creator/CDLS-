# Quick Start Guide
## California Dealer Logistics Platform

Get your EV cost analysis platform running in 5 minutes!

---

## Prerequisites Check

```bash
node --version    # Should be >= 16.x
npm --version     # Should be >= 8.x
psql --version    # Should be >= 15.x (optional for full setup)
```

---

## Instant Setup (Without Database)

For immediate testing and development:

### 1. Install Dependencies

```bash
cd ev-cost-platform
npm install
```

### 2. Create Environment File

```bash
cp .env.example .env
```

**Edit `.env` and set minimum required:**
```env
NODE_ENV=development
PORT=3000
JWT_SECRET=change-this-to-a-long-random-string-min-32-chars
SESSION_SECRET=change-this-to-another-long-random-string
```

### 3. Start Server

```bash
npm start
```

### 4. Open Browser

Navigate to: **http://localhost:3000**

The application will run with mock data for demonstration.

---

## Full Setup (With Database)

For production-ready deployment:

### 1. Create PostgreSQL Database

```bash
# Using psql
createdb ca_dealer_logistics

# Or using SQL
psql -U postgres
CREATE DATABASE ca_dealer_logistics;
\q
```

### 2. Configure Database Connection

Edit `.env`:
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=ca_dealer_logistics
DB_USER=your_username
DB_PASSWORD=your_password
DB_SSL=false    # Set to true in production
```

### 3. Import Database Schema

```bash
# If you have the schema file
psql ca_dealer_logistics < database/schema.sql

# Or manually create tables using the technical spec document
```

### 4. Start with Database

```bash
npm start
```

---

## Docker Deployment

Fastest way to deploy with all dependencies:

### 1. Build Image

```bash
docker build -t ca-dealer-logistics .
```

### 2. Run Container

```bash
docker run -d \
  --name ca-logistics \
  -p 3000:3000 \
  --env-file .env \
  ca-dealer-logistics
```

### 3. With Docker Compose (Recommended)

```bash
docker-compose up -d
```

This will start:
- Application server (port 3000)
- PostgreSQL database (port 5432)
- Redis cache (port 6379)

---

## Verify Installation

### Health Check

```bash
curl http://localhost:3000/api/health
```

Expected response:
```json
{
  "success": true,
  "message": "Server is running",
  "timestamp": "2025-12-12T..."
}
```

### Test API

```bash
# Get all cities
curl http://localhost:3000/api/cities

# Login (mock)
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"julio@dealer.com","password":"password123"}'
```

---

## Common Issues & Solutions

### Issue: Port 3000 Already in Use

**Solution:**
```bash
# Change port in .env
PORT=3001

# Or kill process on port 3000
lsof -ti:3000 | xargs kill -9
```

### Issue: Cannot Connect to Database

**Solution:**
```bash
# Check PostgreSQL is running
pg_isready

# If not running, start it
sudo service postgresql start

# Verify credentials
psql -U your_username -d ca_dealer_logistics
```

### Issue: Module Not Found

**Solution:**
```bash
# Clean install
rm -rf node_modules package-lock.json
npm install
```

### Issue: Permission Denied

**Solution:**
```bash
# Fix permissions
sudo chown -R $USER:$USER .

# Or run with sudo (not recommended)
sudo npm start
```

---

## Development Mode

For hot-reloading during development:

```bash
# Install nodemon globally
npm install -g nodemon

# Start in dev mode
npm run dev
```

Changes to server files will auto-restart the server.

---

## Production Deployment

### 1. Set Production Environment

```env
NODE_ENV=production
PORT=3000
CORS_ORIGIN=https://yourdomain.com
```

### 2. Enable HTTPS

Use reverse proxy (nginx or Apache):

```nginx
server {
    listen 443 ssl http2;
    server_name yourdomain.com;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### 3. Process Manager

Use PM2 for production:

```bash
# Install PM2
npm install -g pm2

# Start application
pm2 start server.js --name "ca-logistics"

# Save configuration
pm2 save

# Setup startup script
pm2 startup
```

---

## Next Steps

1. **Read Documentation**
   - README.md - Full documentation
   - SECURITY.md - Security guidelines
   - Technical spec - System architecture

2. **Configure External APIs**
   - GasBuddy API for fuel prices
   - PlugShare API for charging stations
   - Google Maps API for routing

3. **Customize**
   - Update branding (logo, colors)
   - Add your dealer locations
   - Configure email notifications

4. **Test**
   - Create test calculations
   - Verify all routes work
   - Test security features

5. **Deploy**
   - Set up production database
   - Configure SSL/TLS
   - Set up monitoring

---

## Useful Commands

```bash
# View logs
tail -f logs/app.log

# Check running processes
ps aux | grep node

# Monitor system resources
htop

# Database backup
pg_dump ca_dealer_logistics > backup.sql

# Database restore
psql ca_dealer_logistics < backup.sql

# Check security headers
curl -I http://localhost:3000

# Test API with authentication
TOKEN="your-jwt-token"
curl http://localhost:3000/api/routes \
  -H "Authorization: Bearer $TOKEN"
```

---

## Support Resources

- **Documentation**: Full README.md and technical specs
- **GitHub Issues**: Report bugs and feature requests
- **Email**: support@cadealer logistics.com
- **Community**: Developer forum (link)

---

## Development Roadmap

**Completed:**
- ✅ Core cost calculation engine
- ✅ City pricing comparison
- ✅ Route management
- ✅ Security implementation
- ✅ Responsive UI

**Coming Soon:**
- 🔄 Real-time pricing API integration
- 🔄 Mobile app (React Native)
- 🔄 Advanced analytics dashboard
- 🔄 Multi-factor authentication
- 🔄 Payment processing

---

**Version:** 1.0.0  
**Last Updated:** December 2025  
**Setup Time:** 5 minutes (mock data) / 30 minutes (full setup)

---

**Need Help?**

If you encounter issues not covered here:
1. Check the full README.md
2. Review error logs
3. Search GitHub issues
4. Contact support team

Happy coding! 🚀
