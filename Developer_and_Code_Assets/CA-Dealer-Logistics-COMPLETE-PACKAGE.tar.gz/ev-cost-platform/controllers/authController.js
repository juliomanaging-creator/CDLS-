const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Generate JWT Token
const signToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '7d'
  });
};

// Create and send token response
const createSendToken = (user, statusCode, res) => {
  const token = signToken(user.id);
  
  const cookieOptions = {
    expires: new Date(
      Date.now() + (process.env.JWT_COOKIE_EXPIRE || 7) * 24 * 60 * 60 * 1000
    ),
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict'
  };
  
  res.cookie('jwt', token, cookieOptions);
  
  // Remove password from output
  user.password = undefined;
  
  res.status(statusCode).json({
    success: true,
    token,
    data: {
      user
    }
  });
};

// Register new user
exports.register = async (req, res, next) => {
  try {
    const { email, password, dealer_name, phone } = req.body;
    
    // TODO: Check if user already exists
    // const existingUser = await User.findOne({ email });
    // if (existingUser) {
    //   return res.status(400).json({
    //     success: false,
    //     message: 'Email already registered'
    //   });
    // }
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);
    
    // TODO: Create user in database
    // const user = await User.create({
    //   email,
    //   password: hashedPassword,
    //   dealer_name,
    //   phone,
    //   role: 'dealer',
    //   syndicate_member: false
    // });
    
    const mockUser = {
      id: Date.now(),
      email,
      dealer_name,
      role: 'dealer',
      syndicate_member: false
    };
    
    createSendToken(mockUser, 201, res);
  } catch (error) {
    next(error);
  }
};

// Login user
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    
    // TODO: Find user in database
    // const user = await User.findOne({ email }).select('+password');
    // if (!user) {
    //   return res.status(401).json({
    //     success: false,
    //     message: 'Invalid email or password'
    //   });
    // }
    
    // TODO: Check password
    // const isPasswordValid = await bcrypt.compare(password, user.password);
    // if (!isPasswordValid) {
    //   return res.status(401).json({
    //     success: false,
    //     message: 'Invalid email or password'
    //   });
    // }
    
    // Mock successful login
    const mockUser = {
      id: 1,
      email,
      dealer_name: 'Sacramento Wholesale Auto',
      role: 'dealer',
      syndicate_member: true
    };
    
    createSendToken(mockUser, 200, res);
  } catch (error) {
    next(error);
  }
};

// Logout user
exports.logout = async (req, res, next) => {
  try {
    res.cookie('jwt', 'loggedout', {
      expires: new Date(Date.now() + 10 * 1000),
      httpOnly: true
    });
    
    res.status(200).json({
      success: true,
      message: 'Logged out successfully'
    });
  } catch (error) {
    next(error);
  }
};

// Get current user
exports.getMe = async (req, res, next) => {
  try {
    // TODO: Fetch full user details from database
    // const user = await User.findById(req.user.id);
    
    res.status(200).json({
      success: true,
      data: {
        user: req.user
      }
    });
  } catch (error) {
    next(error);
  }
};

// Update password
exports.updatePassword = async (req, res, next) => {
  try {
    const { current_password, new_password } = req.body;
    
    // TODO: Get user with password
    // const user = await User.findById(req.user.id).select('+password');
    
    // TODO: Verify current password
    // const isValid = await bcrypt.compare(current_password, user.password);
    // if (!isValid) {
    //   return res.status(401).json({
    //     success: false,
    //     message: 'Current password is incorrect'
    //   });
    // }
    
    // TODO: Hash and save new password
    // user.password = await bcrypt.hash(new_password, 12);
    // await user.save();
    
    res.status(200).json({
      success: true,
      message: 'Password updated successfully'
    });
  } catch (error) {
    next(error);
  }
};

// Forgot password
exports.forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    
    // TODO: Find user and generate reset token
    // const user = await User.findOne({ email });
    // if (!user) {
    //   return res.status(404).json({
    //     success: false,
    //     message: 'No user found with that email'
    //   });
    // }
    
    // TODO: Generate reset token and send email
    // const resetToken = user.createPasswordResetToken();
    // await user.save();
    
    // TODO: Send email with reset link
    
    res.status(200).json({
      success: true,
      message: 'Password reset email sent'
    });
  } catch (error) {
    next(error);
  }
};

// Reset password
exports.resetPassword = async (req, res, next) => {
  try {
    const { token } = req.params;
    const { password } = req.body;
    
    // TODO: Find user by reset token
    // const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
    // const user = await User.findOne({
    //   passwordResetToken: hashedToken,
    //   passwordResetExpires: { $gt: Date.now() }
    // });
    
    // TODO: Update password
    // user.password = await bcrypt.hash(password, 12);
    // user.passwordResetToken = undefined;
    // user.passwordResetExpires = undefined;
    // await user.save();
    
    res.status(200).json({
      success: true,
      message: 'Password reset successful'
    });
  } catch (error) {
    next(error);
  }
};

// Refresh token
exports.refreshToken = async (req, res, next) => {
  try {
    // Generate new token
    const newToken = signToken(req.user.id);
    
    res.status(200).json({
      success: true,
      token: newToken
    });
  } catch (error) {
    next(error);
  }
};
