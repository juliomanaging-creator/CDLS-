exports.getAllIncentives = async (req, res, next) => {
  try {
    res.status(200).json({ success: true, data: { incentives: [] } });
  } catch (error) {
    next(error);
  }
};

exports.getIncentiveById = async (req, res, next) => {
  try {
    res.status(200).json({ success: true, data: {} });
  } catch (error) {
    next(error);
  }
};

exports.checkEligibility = async (req, res, next) => {
  try {
    res.status(200).json({ success: true, data: { eligible_incentives: [] } });
  } catch (error) {
    next(error);
  }
};

exports.getExpiringSoon = async (req, res, next) => {
  try {
    res.status(200).json({ success: true, data: { incentives: [] } });
  } catch (error) {
    next(error);
  }
};
