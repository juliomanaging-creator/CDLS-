/**
 * Main Application JavaScript
 * Handles routing, navigation, and core functionality
 */

const app = {
    // Application state
    state: {
        currentSection: 'dashboard',
        user: null,
        token: null,
        calculations: [],
        cities: []
    },

    // Initialize application
    init() {
        console.log('Initializing CA Dealer Logistics Platform...');
        
        // Check authentication
        this.checkAuth();
        
        // Setup event listeners
        this.setupEventListeners();
        
        // Setup navigation
        this.setupNavigation();
        
        // Load initial data
        this.loadDashboardData();
        
        // Initialize charts
        this.initializeCharts();
        
        console.log('Application initialized successfully');
    },

    // Check if user is authenticated
    checkAuth() {
        const token = localStorage.getItem('token');
        const user = localStorage.getItem('user');
        
        if (token && user) {
            this.state.token = token;
            this.state.user = JSON.parse(user);
            this.updateUIForAuth();
        } else {
            // Redirect to login if on protected page
            // For demo, we'll use mock auth
            this.state.user = {
                id: 1,
                name: 'Julio',
                dealer_name: 'Sacramento Wholesale Auto',
                email: 'julio@dealer.com',
                role: 'dealer',
                syndicate_member: true
            };
            this.updateUIForAuth();
        }
    },

    // Update UI based on authentication status
    updateUIForAuth() {
        const userName = document.getElementById('userName');
        const userAvatar = document.querySelector('.user-avatar');
        
        if (this.state.user) {
            if (userName) {
                userName.textContent = this.state.user.name || 'User';
            }
            if (userAvatar) {
                const initials = this.state.user.name
                    ? this.state.user.name.split(' ').map(n => n[0]).join('')
                    : 'U';
                userAvatar.textContent = initials;
            }
        }
    },

    // Setup event listeners
    setupEventListeners() {
        // Navigation toggle
        const navToggle = document.getElementById('navToggle');
        const navMenu = document.getElementById('navMenu');
        if (navToggle) {
            navToggle.addEventListener('click', () => {
                navMenu.classList.toggle('active');
            });
        }

        // User menu toggle
        const userButton = document.getElementById('userButton');
        const userMenu = document.getElementById('userMenu');
        if (userButton) {
            userButton.addEventListener('click', (e) => {
                e.stopPropagation();
                userMenu.classList.toggle('active');
            });
        }

        // Close dropdowns on outside click
        document.addEventListener('click', () => {
            document.querySelectorAll('.dropdown-menu').forEach(menu => {
                menu.closest('.user-menu')?.classList.remove('active');
            });
        });

        // Logout button
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.logout();
            });
        }

        // Cost calculator form
        const calculatorForm = document.getElementById('costCalculatorForm');
        if (calculatorForm) {
            calculatorForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.calculateCost();
            });
        }

        // City search
        const citySearch = document.getElementById('citySearch');
        if (citySearch) {
            citySearch.addEventListener('input', this.debounce((e) => {
                this.searchCities(e.target.value);
            }, 300));
        }
    },

    // Setup navigation between sections
    setupNavigation() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetSection = link.getAttribute('href').substring(1);
                this.navigateTo(targetSection);
            });
        });

        // Handle browser back/forward
        window.addEventListener('popstate', (e) => {
            if (e.state && e.state.section) {
                this.navigateTo(e.state.section, false);
            }
        });
    },

    // Navigate to a specific section
    navigateTo(sectionId, updateHistory = true) {
        // Hide all sections
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('section-active');
        });

        // Show target section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('section-active');
            this.state.currentSection = sectionId;

            // Update navigation active state
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${sectionId}`) {
                    link.classList.add('active');
                }
            });

            // Update browser history
            if (updateHistory) {
                history.pushState({ section: sectionId }, '', `#${sectionId}`);
            }

            // Load section-specific data
            this.loadSectionData(sectionId);

            // Scroll to top
            window.scrollTo(0, 0);
        }
    },

    // Load data for specific section
    loadSectionData(sectionId) {
        switch(sectionId) {
            case 'dashboard':
                this.loadDashboardData();
                break;
            case 'cities':
                this.loadCityPrices();
                break;
            case 'routes':
                this.loadRoutes();
                break;
            case 'syndicate':
                this.loadSyndicateData();
                break;
            case 'incentives':
                this.loadIncentives();
                break;
        }
    },

    // Load dashboard data
    async loadDashboardData() {
        try {
            // Load recent calculations
            this.loadCalculationHistory(5);
            
            // Update metrics (in production, fetch from API)
            this.updateDashboardMetrics();
        } catch (error) {
            console.error('Error loading dashboard:', error);
            this.showToast('Error loading dashboard data', 'error');
        }
    },

    // Update dashboard metrics
    updateDashboardMetrics() {
        // In production, these would come from API
        // For now, using mock data
        const metrics = {
            avgSavings: 29.83,
            savingsPercent: 35.7,
            avgDieselPrice: 5.01,
            routesAnalyzed: 247,
            annualProjection: 7748
        };

        // Update metric cards (already in HTML)
    },

    // Load calculation history
    async loadCalculationHistory(limit = 20) {
        try {
            const response = await api.get(`/cost-comparison/history?limit=${limit}`);
            
            if (response.success) {
                this.state.calculations = response.data.calculations;
                this.renderCalculationsTable();
            }
        } catch (error) {
            console.error('Error loading calculations:', error);
            
            // Use mock data for demo
            const mockCalculations = [
                {
                    id: 1,
                    date: '2024-12-10',
                    route: 'Sacramento → Modesto',
                    distance: 127.4,
                    diesel_cost: 83.63,
                    ev_cost: 53.80,
                    savings: 29.83
                }
            ];
            this.renderCalculationsTable(mockCalculations);
        }
    },

    // Render calculations table
    renderCalculationsTable(calculations = []) {
        const tbody = document.getElementById('calculationsTableBody');
        if (!tbody) return;

        if (calculations.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">No calculations yet. Create your first one!</td></tr>';
            return;
        }

        tbody.innerHTML = calculations.map(calc => `
            <tr>
                <td>${this.formatDate(calc.date)}</td>
                <td>${this.escapeHtml(calc.route)}</td>
                <td>${calc.distance} mi</td>
                <td>$${calc.diesel_cost.toFixed(2)}</td>
                <td>$${calc.ev_cost.toFixed(2)}</td>
                <td class="metric-change positive">$${calc.savings.toFixed(2)}</td>
                <td>
                    <button class="btn btn-sm btn-outline" onclick="app.viewCalculation(${calc.id})">
                        View
                    </button>
                </td>
            </tr>
        `).join('');
    },

    // Calculate cost comparison
    async calculateCost() {
        this.showLoading();

        try {
            const formData = {
                origin: document.getElementById('routeOrigin').value,
                destination: document.getElementById('routeDestination').value,
                payload_vehicles: parseInt(document.getElementById('payloadVehicles').value),
                diesel_vehicle_id: parseInt(document.getElementById('dieselVehicle').value),
                ev_vehicle_id: parseInt(document.getElementById('evVehicle').value),
                departure_time: document.getElementById('departureTime').value || null
            };

            // Validate form data
            if (!formData.origin || !formData.destination) {
                throw new Error('Please select both origin and destination');
            }

            const response = await api.post('/cost-comparison/calculate', formData);

            if (response.success) {
                this.displayCalculationResults(response.data);
                this.showToast('Calculation completed successfully!', 'success');
            }
        } catch (error) {
            console.error('Calculation error:', error);
            this.showToast(error.message || 'Calculation failed', 'error');
            
            // Show mock results for demo
            this.displayCalculationResults(this.getMockCalculationResults());
        } finally {
            this.hideLoading();
        }
    },

    // Display calculation results
    displayCalculationResults(data) {
        const resultsDiv = document.getElementById('calculatorResults');
        if (!resultsDiv) return;

        // Update diesel analysis
        document.getElementById('dieselVehicleName').textContent = data.diesel_analysis.vehicle;
        document.getElementById('dieselTotalCost').textContent = `$${data.diesel_analysis.total_cost.toFixed(2)}`;
        document.getElementById('dieselFuelCost').textContent = `$${data.diesel_analysis.fuel_cost.toFixed(2)}`;
        document.getElementById('dieselMaintCost').textContent = `$${data.diesel_analysis.maintenance_cost.toFixed(2)}`;
        document.getElementById('dieselPerMile').textContent = `$${data.diesel_analysis.cost_per_mile.toFixed(2)}`;
        document.getElementById('dieselPerVehicle').textContent = `$${data.diesel_analysis.cost_per_vehicle_hauled.toFixed(2)}`;

        // Update EV analysis
        document.getElementById('evVehicleName').textContent = data.ev_analysis.vehicle;
        document.getElementById('evTotalCost').textContent = `$${data.ev_analysis.total_cost.toFixed(2)}`;
        document.getElementById('evChargingCost').textContent = `$${data.ev_analysis.total_charging_cost.toFixed(2)}`;
        document.getElementById('evMaintCost').textContent = `$${data.ev_analysis.maintenance_cost.toFixed(2)}`;
        document.getElementById('evPerMile').textContent = `$${data.ev_analysis.cost_per_mile.toFixed(2)}`;
        document.getElementById('evPerVehicle').textContent = `$${data.ev_analysis.cost_per_vehicle_hauled.toFixed(2)}`;

        // Update savings
        document.getElementById('savingsAmount').textContent = `$${data.comparison.ev_savings.toFixed(2)}`;
        document.getElementById('savingsPercent').textContent = `(${data.comparison.ev_savings_pct.toFixed(1)}%)`;
        document.getElementById('annualSavings').textContent = `$${data.comparison.annual_savings_projection.toLocaleString()}`;

        // Show results
        resultsDiv.style.display = 'block';
        resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    },

    // Load city prices
    async loadCityPrices() {
        try {
            const response = await api.get('/cities');
            
            if (response.success) {
                this.state.cities = response.data.cities;
                this.renderCityPricesTable();
            }
        } catch (error) {
            console.error('Error loading cities:', error);
            this.renderCityPricesTable(this.getMockCityData());
        }
    },

    // Render city prices table
    renderCityPricesTable(cities = []) {
        const tbody = document.getElementById('cityPricesTableBody');
        if (!tbody) return;

        if (cities.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">Loading...</td></tr>';
            return;
        }

        tbody.innerHTML = cities.map(city => {
            const advantage = ((city.diesel_price / city.level2_rate - 1) * 100).toFixed(1);
            return `
                <tr>
                    <td><strong>${this.escapeHtml(city.city_name)}</strong></td>
                    <td>${this.escapeHtml(city.region)}</td>
                    <td>$${city.diesel_price.toFixed(2)}</td>
                    <td>$${city.level2_rate.toFixed(3)}</td>
                    <td>$${city.dc_fast_rate.toFixed(3)}</td>
                    <td class="metric-change positive">${advantage}% ✓</td>
                    <td>
                        <button class="btn btn-sm btn-outline" onclick="app.viewCityDetails(${city.city_id})">
                            Details
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
    },

    // Initialize charts
    initializeCharts() {
        this.initCostTrendChart();
        this.initCityComparisonChart();
    },

    // Initialize cost trend chart
    initCostTrendChart() {
        const ctx = document.getElementById('costTrendChart');
        if (!ctx) return;

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                datasets: [
                    {
                        label: 'Diesel Cost',
                        data: [850, 920, 880, 950],
                        borderColor: '#f59e0b',
                        backgroundColor: 'rgba(245, 158, 11, 0.1)',
                        tension: 0.4
                    },
                    {
                        label: 'EV Cost',
                        data: [520, 540, 510, 560],
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => '$' + value
                        }
                    }
                }
            }
        });
    },

    // Initialize city comparison chart
    initCityComparisonChart() {
        const ctx = document.getElementById('cityComparisonChart');
        if (!ctx) return;

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Sacramento', 'Stockton', 'Modesto', 'Fresno'],
                datasets: [
                    {
                        label: 'Diesel',
                        data: [4.89, 4.76, 4.68, 4.72],
                        backgroundColor: '#f59e0b'
                    },
                    {
                        label: 'EV (Level 2)',
                        data: [0.15, 0.16, 0.17, 0.18],
                        backgroundColor: '#10b981'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    },

    // Utility functions
    showLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) overlay.style.display = 'flex';
    },

    hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) overlay.style.display = 'none';
    },

    showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        container.appendChild(toast);

        setTimeout(() => {
            toast.remove();
        }, 5000);
    },

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        });
    },

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    logout() {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        this.state.token = null;
        this.state.user = null;
        window.location.href = '/login.html';
    },

    // Mock data functions (remove in production)
    getMockCalculationResults() {
        return {
            diesel_analysis: {
                vehicle: 'Ford F-550 Super Duty',
                total_cost: 83.63,
                fuel_cost: 77.26,
                maintenance_cost: 6.37,
                cost_per_mile: 0.656,
                cost_per_vehicle_hauled: 11.95
            },
            ev_analysis: {
                vehicle: 'BrightDrop Zevo 600',
                total_cost: 53.80,
                total_charging_cost: 49.25,
                maintenance_cost: 2.55,
                cost_per_mile: 0.422,
                cost_per_vehicle_hauled: 7.69
            },
            comparison: {
                ev_savings: 29.83,
                ev_savings_pct: 35.7,
                annual_savings_projection: 7748
            }
        };
    },

    getMockCityData() {
        return [
            { city_id: 1, city_name: 'Sacramento', region: 'Central Valley', diesel_price: 4.89, level2_rate: 0.15, dc_fast_rate: 0.52 },
            { city_id: 2, city_name: 'Stockton', region: 'Central Valley', diesel_price: 4.76, level2_rate: 0.16, dc_fast_rate: 0.49 },
            { city_id: 3, city_name: 'Modesto', region: 'Central Valley', diesel_price: 4.68, level2_rate: 0.17, dc_fast_rate: 0.51 }
        ];
    }
};

// Initialize app when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => app.init());
} else {
    app.init();
}
