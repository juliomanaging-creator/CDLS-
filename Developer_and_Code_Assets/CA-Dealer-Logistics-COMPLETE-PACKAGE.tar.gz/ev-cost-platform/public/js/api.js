/**
 * API Wrapper
 * Handles all API communications with security features
 */

const api = {
    baseURL: '/api',
    token: null,

    // Initialize API wrapper
    init() {
        this.token = localStorage.getItem('token');
    },

    // Get authorization headers
    getHeaders() {
        const headers = {
            'Content-Type': 'application/json',
        };

        if (this.token) {
            headers['Authorization'] = `Bearer ${this.token}`;
        }

        return headers;
    },

    // Handle API response
    async handleResponse(response) {
        const data = await response.json();

        if (!response.ok) {
            // Handle specific error codes
            if (response.status === 401) {
                // Unauthorized - clear token and redirect to login
                this.clearAuth();
                window.location.href = '/login.html';
            }

            throw new Error(data.message || 'API request failed');
        }

        return data;
    },

    // Handle API errors
    handleError(error) {
        console.error('API Error:', error);
        
        // Don't expose internal errors to user
        if (error.message.includes('fetch')) {
            return {
                success: false,
                message: 'Network error. Please check your connection.'
            };
        }

        return {
            success: false,
            message: error.message || 'An error occurred'
        };
    },

    // GET request
    async get(endpoint, params = {}) {
        try {
            const queryString = new URLSearchParams(params).toString();
            const url = `${this.baseURL}${endpoint}${queryString ? '?' + queryString : ''}`;

            const response = await fetch(url, {
                method: 'GET',
                headers: this.getHeaders(),
                credentials: 'same-origin', // Security: only send cookies to same origin
            });

            return await this.handleResponse(response);
        } catch (error) {
            return this.handleError(error);
        }
    },

    // POST request
    async post(endpoint, data = {}) {
        try {
            const response = await fetch(`${this.baseURL}${endpoint}`, {
                method: 'POST',
                headers: this.getHeaders(),
                credentials: 'same-origin',
                body: JSON.stringify(data),
            });

            return await this.handleResponse(response);
        } catch (error) {
            return this.handleError(error);
        }
    },

    // PUT request
    async put(endpoint, data = {}) {
        try {
            const response = await fetch(`${this.baseURL}${endpoint}`, {
                method: 'PUT',
                headers: this.getHeaders(),
                credentials: 'same-origin',
                body: JSON.stringify(data),
            });

            return await this.handleResponse(response);
        } catch (error) {
            return this.handleError(error);
        }
    },

    // DELETE request
    async delete(endpoint) {
        try {
            const response = await fetch(`${this.baseURL}${endpoint}`, {
                method: 'DELETE',
                headers: this.getHeaders(),
                credentials: 'same-origin',
            });

            return await this.handleResponse(response);
        } catch (error) {
            return this.handleError(error);
        }
    },

    // Set authentication token
    setAuth(token, user) {
        this.token = token;
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
    },

    // Clear authentication
    clearAuth() {
        this.token = null;
        localStorage.removeItem('token');
        localStorage.removeItem('user');
    },

    // Specific API endpoints
    auth: {
        async login(email, password) {
            return await api.post('/auth/login', { email, password });
        },

        async register(data) {
            return await api.post('/auth/register', data);
        },

        async logout() {
            const response = await api.post('/auth/logout');
            api.clearAuth();
            return response;
        },

        async getProfile() {
            return await api.get('/auth/me');
        },

        async updatePassword(currentPassword, newPassword) {
            return await api.put('/auth/update-password', {
                current_password: currentPassword,
                new_password: newPassword
            });
        }
    },

    costComparison: {
        async calculate(data) {
            return await api.post('/cost-comparison/calculate', data);
        },

        async getHistory(limit = 20) {
            return await api.get('/cost-comparison/history', { limit });
        },

        async getById(id) {
            return await api.get(`/cost-comparison/${id}`);
        },

        async save(data) {
            return await api.post('/cost-comparison/save', data);
        },

        async getSyndicateAggregate(startDate, endDate) {
            return await api.get('/cost-comparison/syndicate/aggregate', {
                start_date: startDate,
                end_date: endDate
            });
        }
    },

    cities: {
        async getAll(params = {}) {
            return await api.get('/cities', params);
        },

        async getById(id) {
            return await api.get(`/cities/${id}`);
        },

        async getPrices(id) {
            return await api.get(`/cities/${id}/prices`);
        },

        async getChargingStations(id) {
            return await api.get(`/cities/${id}/charging-stations`);
        },

        async compare(cityIds) {
            return await api.get('/cities/compare', { city_ids: cityIds.join(',') });
        }
    },

    routes: {
        async getAll() {
            return await api.get('/routes');
        },

        async create(data) {
            return await api.post('/routes', data);
        },

        async getById(id) {
            return await api.get(`/routes/${id}`);
        },

        async update(id, data) {
            return await api.put(`/routes/${id}`, data);
        },

        async delete(id) {
            return await api.delete(`/routes/${id}`);
        },

        async optimize(id) {
            return await api.get(`/routes/${id}/optimize`);
        }
    },

    dealers: {
        async getAll() {
            return await api.get('/dealers');
        },

        async create(data) {
            return await api.post('/dealers', data);
        },

        async getById(id) {
            return await api.get(`/dealers/${id}`);
        },

        async update(id, data) {
            return await api.put(`/dealers/${id}`, data);
        },

        async delete(id) {
            return await api.delete(`/dealers/${id}`);
        },

        async getNearby(lat, lng, radius) {
            return await api.get('/dealers/search/nearby', { lat, lng, radius });
        },

        async getCharging(id) {
            return await api.get(`/dealers/${id}/charging`);
        }
    },

    incentives: {
        async getAll(params = {}) {
            return await api.get('/incentives', params);
        },

        async getById(id) {
            return await api.get(`/incentives/${id}`);
        },

        async checkEligibility(data) {
            return await api.post('/incentives/check-eligibility', data);
        },

        async getExpiringSoon() {
            return await api.get('/incentives/alerts/expiring-soon');
        }
    }
};

// Initialize API wrapper
api.init();
