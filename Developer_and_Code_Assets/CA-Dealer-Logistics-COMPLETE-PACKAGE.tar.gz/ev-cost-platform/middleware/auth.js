const jwt = require('jsonwebtoken');
const { promisify } = require('util');

// Protect routes - verify JWT token
exports.protect = async (req, res, next) => {
  try {
    let token;
    
    // Check if token exists in Authorization header
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    } else if (req.cookies.jwt) {
      token = req.cookies.jwt;
    }
    
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'You are not logged in. Please log in to access this resource.'
      });
    }
    
    // Verify token
    const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);
    
    // Check if user still exists (you would query database here)
    // const currentUser = await User.findById(decoded.id);
    // if (!currentUser) {
    //   return res.status(401).json({
    //     success: false,
    //     message: 'The user belonging to this token no longer exists.'
    //   });
    // }
    
    // Grant access to protected route
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired token. Please log in again.'
    });
  }
};

// Restrict to specific roles
exports.restrictTo = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'You do not have permission to perform this action.'
      });
    }
    next();
  };
};

// Check if user is syndicate member
exports.requireSyndicateMember = (req, res, next) => {
  if (!req.user.syndicateMember) {
    return res.status(403).json({
      success: false,
      message: 'This feature is only available to syndicate members.'
    });
  }
  next();
};

// API key authentication (for external integrations)
exports.validateApiKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  
  if (!apiKey) {
    return res.status(401).json({
      success: false,
      message: 'API key is required'
    });
  }
  
  // Validate API key (you would check against database)
  // const validKey = await ApiKey.findOne({ key: apiKey, active: true });
  // if (!validKey) {
  //   return res.status(401).json({
  //     success: false,
  //     message: 'Invalid API key'
  //   });
  // }
  
  next();
};
