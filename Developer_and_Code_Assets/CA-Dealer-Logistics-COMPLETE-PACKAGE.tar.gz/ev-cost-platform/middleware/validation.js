const { body, param, query, validationResult } = require('express-validator');

// Middleware to check validation results
exports.validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array()
    });
  }
  next();
};

// Cost comparison validation rules
exports.validateCostComparison = [
  body('route_id').optional().isInt({ min: 1 }).withMessage('Route ID must be a positive integer'),
  body('origin').optional().isObject().withMessage('Origin must be an object'),
  body('origin.lat').optional().isFloat({ min: -90, max: 90 }).withMessage('Invalid latitude'),
  body('origin.lng').optional().isFloat({ min: -180, max: 180 }).withMessage('Invalid longitude'),
  body('destination').optional().isObject().withMessage('Destination must be an object'),
  body('destination.lat').optional().isFloat({ min: -90, max: 90 }).withMessage('Invalid latitude'),
  body('destination.lng').optional().isFloat({ min: -180, max: 180 }).withMessage('Invalid longitude'),
  body('payload_vehicles').isInt({ min: 0, max: 15 }).withMessage('Payload must be between 0 and 15 vehicles'),
  body('diesel_vehicle_id').isInt({ min: 1 }).withMessage('Diesel vehicle ID required'),
  body('ev_vehicle_id').isInt({ min: 1 }).withMessage('EV vehicle ID required'),
  body('departure_time').optional().isISO8601().withMessage('Invalid departure time format'),
  body('return_same_day').optional().isBoolean().withMessage('Return same day must be boolean')
];

// City search validation
exports.validateCitySearch = [
  query('search').optional().isString().trim().isLength({ min: 2, max: 50 })
    .withMessage('Search term must be 2-50 characters'),
  query('region').optional().isIn(['Central Valley', 'Bay Area', 'Southern CA', 'Northern CA'])
    .withMessage('Invalid region'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be 1-100')
];

// Route creation validation
exports.validateRouteCreation = [
  body('route_name').isString().trim().isLength({ min: 3, max: 100 })
    .withMessage('Route name must be 3-100 characters'),
  body('origin_dealer_id').isInt({ min: 1 }).withMessage('Origin dealer ID required'),
  body('destination_dealer_id').isInt({ min: 1 }).withMessage('Destination dealer ID required'),
  body('waypoints').optional().isArray().withMessage('Waypoints must be an array'),
  body('waypoints.*.dealer_id').isInt({ min: 1 }).withMessage('Invalid dealer ID in waypoints'),
  body('waypoints.*.sequence').isInt({ min: 1 }).withMessage('Invalid sequence in waypoints'),
  body('total_distance_miles').isFloat({ min: 0.1 }).withMessage('Distance must be positive'),
  body('typical_payload_vehicles').isInt({ min: 0, max: 15 })
    .withMessage('Typical payload must be 0-15 vehicles'),
  body('frequency').isIn(['daily', 'weekly', 'on_demand'])
    .withMessage('Invalid frequency')
];

// Dealer creation/update validation
exports.validateDealer = [
  body('dealer_name').isString().trim().isLength({ min: 3, max: 200 })
    .withMessage('Dealer name must be 3-200 characters'),
  body('city_id').isInt({ min: 1 }).withMessage('City ID required'),
  body('address').optional().isString().trim().isLength({ max: 500 })
    .withMessage('Address too long'),
  body('latitude').optional().isFloat({ min: -90, max: 90 }).withMessage('Invalid latitude'),
  body('longitude').optional().isFloat({ min: -180, max: 180 }).withMessage('Invalid longitude'),
  body('has_charging').optional().isBoolean().withMessage('Has charging must be boolean'),
  body('charging_capacity_kw').optional().isInt({ min: 0 })
    .withMessage('Charging capacity must be positive'),
  body('contact_email').optional().isEmail().normalizeEmail()
    .withMessage('Invalid email format'),
  body('contact_phone').optional().matches(/^\+?[\d\s\-\(\)]+$/)
    .withMessage('Invalid phone format')
];

// Login validation
exports.validateLogin = [
  body('email').isEmail().normalizeEmail().withMessage('Invalid email address'),
  body('password').isString().isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
];

// Registration validation
exports.validateRegistration = [
  body('email').isEmail().normalizeEmail().withMessage('Invalid email address'),
  body('password').isString().isLength({ min: 8 })
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
    .withMessage('Password must contain uppercase, lowercase, number, and special character'),
  body('confirm_password').custom((value, { req }) => {
    if (value !== req.body.password) {
      throw new Error('Passwords do not match');
    }
    return true;
  }),
  body('dealer_name').isString().trim().isLength({ min: 3, max: 200 })
    .withMessage('Dealer name must be 3-200 characters'),
  body('phone').optional().matches(/^\+?[\d\s\-\(\)]+$/)
    .withMessage('Invalid phone format')
];

// Incentive search validation
exports.validateIncentiveSearch = [
  query('vehicle_type').optional().isString().trim(),
  query('jurisdiction').optional().isIn(['federal', 'california', 'local']),
  query('active_only').optional().isBoolean().toBoolean()
];

// Pagination validation
exports.validatePagination = [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be 1-100'),
  query('sort').optional().isString().trim(),
  query('order').optional().isIn(['asc', 'desc']).withMessage('Order must be asc or desc')
];

// ID parameter validation
exports.validateId = [
  param('id').isInt({ min: 1 }).withMessage('Invalid ID parameter')
];

// Date range validation
exports.validateDateRange = [
  query('start_date').optional().isISO8601().withMessage('Invalid start date'),
  query('end_date').optional().isISO8601().withMessage('Invalid end date'),
  query('end_date').optional().custom((value, { req }) => {
    if (req.query.start_date && new Date(value) < new Date(req.query.start_date)) {
      throw new Error('End date must be after start date');
    }
    return true;
  })
];
