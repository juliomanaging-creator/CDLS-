# Security Documentation
## California Dealer Logistics Platform

**Document Version:** 1.0  
**Last Updated:** December 2025  
**Classification:** Internal

---

## Table of Contents
1. [Overview](#overview)
2. [Security Architecture](#security-architecture)
3. [Authentication & Authorization](#authentication--authorization)
4. [Data Protection](#data-protection)
5. [Network Security](#network-security)
6. [Application Security](#application-security)
7. [API Security](#api-security)
8. [Compliance](#compliance)
9. [Incident Response](#incident-response)
10. [Security Checklist](#security-checklist)

---

## Overview

This document outlines the comprehensive security measures implemented in the California Dealer Logistics Platform to protect user data, prevent unauthorized access, and maintain system integrity.

### Security Principles

1. **Defense in Depth** - Multiple layers of security controls
2. **Least Privilege** - Minimal access rights for users/processes
3. **Secure by Default** - Security built-in, not bolted-on
4. **Zero Trust** - Verify everything, trust nothing
5. **Privacy by Design** - Data protection throughout lifecycle

---

## Security Architecture

### 1. Multi-Layer Security Model

```
┌─────────────────────────────────────────────────────┐
│ Layer 7: User Access                                │
│ - Multi-factor Authentication (Roadmap)             │
│ - Session Management                                │
│ - Role-Based Access Control                         │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ Layer 6: Application Security                       │
│ - Input Validation                                  │
│ - Output Encoding                                   │
│ - CSRF Protection                                   │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ Layer 5: API Security                               │
│ - JWT Authentication                                │
│ - Rate Limiting                                     │
│ - Request Throttling                                │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ Layer 4: Transport Security                         │
│ - TLS 1.3                                          │
│ - HSTS                                             │
│ - Certificate Pinning                               │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ Layer 3: Network Security                           │
│ - Firewall Rules                                    │
│ - VPC Isolation                                     │
│ - DDoS Protection                                   │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ Layer 2: Data Security                              │
│ - Encryption at Rest                                │
│ - Database Encryption                               │
│ - Backup Encryption                                 │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ Layer 1: Infrastructure Security                    │
│ - Hardened OS                                       │
│ - Patch Management                                  │
│ - Access Logging                                    │
└─────────────────────────────────────────────────────┘
```

---

## Authentication & Authorization

### JWT Token Implementation

**Token Structure:**
```javascript
{
  "id": "user_id",
  "email": "user@example.com",
  "role": "dealer",
  "syndicateMember": true,
  "iat": 1234567890,
  "exp": 1234654290
}
```

**Security Features:**
- HS256 algorithm (HMAC with SHA-256)
- 256-bit secret key minimum
- 7-day expiration
- httpOnly cookies for web
- Refresh token rotation
- Token blacklisting on logout

**Password Requirements:**
- Minimum 8 characters
- At least 1 uppercase letter
- At least 1 lowercase letter
- At least 1 number
- At least 1 special character (@$!%*?&)
- BCrypt hashing with 12 rounds
- Password history (prevent reuse of last 5)

**Session Management:**
```javascript
{
  maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  httpOnly: true,
  secure: true, // HTTPS only
  sameSite: 'strict', // CSRF protection
  rolling: true // Extend on activity
}
```

### Role-Based Access Control (RBAC)

| Role | Permissions |
|------|-------------|
| **Guest** | View public pricing data |
| **Dealer** | Create routes, calculate costs, view own data |
| **Syndicate Member** | Access dealer network features, shared data |
| **Manager** | View syndicate aggregates, manage team |
| **Admin** | Full system access, user management |

### Authorization Flow

```
User Request → JWT Validation → Role Check → Permission Check → Access Granted/Denied
```

---

## Data Protection

### Encryption

**At Rest:**
- AES-256-GCM for database encryption
- Full disk encryption on servers
- Encrypted backups
- Encrypted log files

**In Transit:**
- TLS 1.3 minimum
- Perfect Forward Secrecy
- Strong cipher suites only:
  - TLS_AES_128_GCM_SHA256
  - TLS_AES_256_GCM_SHA384
  - TLS_CHACHA20_POLY1305_SHA256

**Key Management:**
- Hardware Security Module (HSM) for production
- Key rotation every 90 days
- Separate keys per environment
- Key escrow for disaster recovery

### Sensitive Data Handling

**Personally Identifiable Information (PII):**
- Name
- Email address
- Phone number
- Business information
- Payment information (if implemented)

**Protection Measures:**
1. Encrypted storage
2. Masked in logs
3. Redacted in error messages
4. Access logging
5. Data minimization
6. Retention policies

**Data Classification:**

| Level | Examples | Protection |
|-------|----------|------------|
| Public | City pricing | None |
| Internal | Route calculations | Authentication |
| Confidential | Dealer financials | Encryption + Auth |
| Restricted | User passwords | Hashing + Encryption |

---

## Network Security

### Firewall Rules

```
# Allow HTTPS
ALLOW TCP 443 FROM 0.0.0.0/0

# Allow SSH (restricted IPs only)
ALLOW TCP 22 FROM 10.0.0.0/8

# Block all other inbound
DENY ALL FROM 0.0.0.0/0

# Allow all outbound
ALLOW ALL TO 0.0.0.0/0
```

### DDoS Protection

**Layers:**
1. **L3/L4:** CloudFlare / AWS Shield
2. **L7:** Rate limiting + WAF rules
3. **Application:** Request throttling

**Mitigation Strategies:**
- IP reputation filtering
- Geo-blocking (if needed)
- Challenge-response (CAPTCHA)
- Traffic analysis and anomaly detection

### VPC Configuration

```
Production VPC: 10.0.0.0/16
  ├── Public Subnet:  10.0.1.0/24 (Load Balancers)
  ├── Private Subnet: 10.0.2.0/24 (Application Servers)
  └── Database Subnet: 10.0.3.0/24 (RDS, ElastiCache)
```

**Security Groups:**
- Load Balancer: Allow 443 from Internet
- App Servers: Allow 3000 from Load Balancer only
- Database: Allow 5432 from App Servers only

---

## Application Security

### Input Validation

**Server-Side Validation (Express-Validator):**
```javascript
// Example: Route creation
body('route_name')
  .isString()
  .trim()
  .isLength({ min: 3, max: 100 })
  .escape()
  .withMessage('Invalid route name')
```

**Validation Rules:**
1. Whitelist allowed characters
2. Validate data types
3. Check length constraints
4. Sanitize HTML entities
5. Reject suspicious patterns

### XSS Prevention

**Output Encoding:**
```javascript
// Escape HTML in user input
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
```

**Content Security Policy:**
```
default-src 'self';
script-src 'self' https://cdn.jsdelivr.net;
style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
img-src 'self' data: https:;
connect-src 'self' https://api.gasbuddy.com;
font-src 'self' https://fonts.gstatic.com;
frame-src 'none';
object-src 'none';
```

### SQL Injection Prevention

**Parameterized Queries:**
```javascript
// GOOD - Parameterized
const query = 'SELECT * FROM users WHERE email = $1';
await db.query(query, [userEmail]);

// BAD - String concatenation (NEVER DO THIS)
const query = `SELECT * FROM users WHERE email = '${userEmail}'`;
```

**Database User Permissions:**
- Application user: SELECT, INSERT, UPDATE only
- No DROP, TRUNCATE, or ALTER permissions
- Separate admin user for schema changes

### CSRF Protection

**Token Implementation:**
```javascript
// Generate CSRF token
const csrfToken = crypto.randomBytes(32).toString('hex');

// Validate token on state-changing requests
if (req.body._csrf !== req.session.csrfToken) {
  throw new Error('CSRF token mismatch');
}
```

**SameSite Cookies:**
```javascript
sameSite: 'strict' // Prevents CSRF attacks
```

---

## API Security

### Rate Limiting

**Configuration:**
```javascript
// General API
windowMs: 15 * 60 * 1000, // 15 minutes
max: 100 // requests per window

// Authentication endpoints
windowMs: 15 * 60 * 1000,
max: 5 // login attempts per window
```

**Response Headers:**
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1640000000
```

### API Keys (For External Integrations)

**Generation:**
```bash
# Generate 256-bit key
openssl rand -hex 32
```

**Storage:**
- Hashed in database (SHA-256)
- Never logged in plaintext
- Rotated quarterly
- Revocable instantly

**Usage:**
```http
GET /api/data
X-API-Key: your-api-key-here
```

### Request/Response Security

**Security Headers:**
```javascript
// Helmet.js configuration
helmet({
  contentSecurityPolicy: { /* CSP config */ },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  },
  frameguard: { action: 'deny' },
  noSniff: true,
  xssFilter: true
})
```

**Response Sanitization:**
- Strip sensitive fields (password_hash, tokens)
- Mask partial data (email: j***o@example.com)
- No stack traces in production
- Generic error messages

---

## Compliance

### GDPR Compliance

**User Rights:**
1. **Right to Access** - API endpoint for data export
2. **Right to Rectification** - Profile update functionality
3. **Right to Erasure** - Account deletion (30-day retention)
4. **Right to Data Portability** - JSON export
5. **Right to Object** - Opt-out mechanisms

**Implementation:**
```javascript
// Data export
GET /api/auth/export-data

// Account deletion
DELETE /api/auth/delete-account

// Consent management
PUT /api/auth/consent
```

### CCPA Compliance

**California Consumer Privacy Act Requirements:**
- Privacy policy disclosure
- Do Not Sell My Personal Information
- Opt-out link in footer
- 12-month data retention disclosure

### SOC 2 (Roadmap)

**Controls:**
- Security
- Availability
- Processing Integrity
- Confidentiality
- Privacy

---

## Incident Response

### Security Incident Classification

| Severity | Definition | Response Time |
|----------|------------|---------------|
| **Critical** | Data breach, system compromise | Immediate (< 1 hour) |
| **High** | Unauthorized access attempt | 4 hours |
| **Medium** | Vulnerability discovered | 24 hours |
| **Low** | Security misconfiguration | 72 hours |

### Incident Response Plan

**Phase 1: Detection**
- Automated monitoring alerts
- Log analysis (SIEM)
- User reports
- Security audit findings

**Phase 2: Containment**
1. Isolate affected systems
2. Block malicious IPs
3. Revoke compromised credentials
4. Enable enhanced logging

**Phase 3: Eradication**
1. Identify root cause
2. Remove malware/backdoors
3. Patch vulnerabilities
4. Update security controls

**Phase 4: Recovery**
1. Restore from clean backups
2. Verify system integrity
3. Monitor for re-infection
4. Gradual service restoration

**Phase 5: Lessons Learned**
1. Incident timeline documentation
2. Root cause analysis
3. Security improvements
4. Team training

### Breach Notification

**Timeline:**
- Internal notification: Immediate
- User notification: Within 72 hours
- Regulatory notification: As required by law

**Communication Template:**
```
Subject: Security Incident Notification

We are writing to inform you of a security incident that may 
have affected your account.

What happened: [Brief description]
When: [Date/time]
Data affected: [Specific data types]
Actions taken: [Mitigation steps]
Your action required: [User steps]

For questions: security@cadealer logistics.com
```

---

## Security Checklist

### Development

- [ ] Code review for security issues
- [ ] Static application security testing (SAST)
- [ ] Dependency vulnerability scanning
- [ ] Secure coding standards followed
- [ ] No hardcoded secrets
- [ ] Input validation implemented
- [ ] Output encoding implemented
- [ ] Error handling doesn't leak info

### Deployment

- [ ] Environment variables configured
- [ ] TLS certificates installed
- [ ] Firewall rules configured
- [ ] Database encryption enabled
- [ ] Backup encryption enabled
- [ ] Monitoring/alerting configured
- [ ] Rate limiting enabled
- [ ] Security headers configured

### Production

- [ ] Regular security audits
- [ ] Penetration testing (annual)
- [ ] Vulnerability scanning (monthly)
- [ ] Log review (weekly)
- [ ] Access review (quarterly)
- [ ] Backup testing (monthly)
- [ ] Incident response drill (quarterly)
- [ ] Security training (annual)

### Maintenance

- [ ] Patch OS within 30 days
- [ ] Update dependencies within 14 days
- [ ] Rotate API keys (quarterly)
- [ ] Review user permissions (monthly)
- [ ] Update security policies (annual)
- [ ] Test disaster recovery (quarterly)

---

## Security Tools & Resources

### Development Tools
- **ESLint Security Plugin** - Static code analysis
- **Snyk** - Dependency vulnerability scanning
- **npm audit** - Built-in vulnerability checker
- **OWASP Dependency-Check** - Additional scanning

### Testing Tools
- **Burp Suite** - Web application security testing
- **OWASP ZAP** - Penetration testing
- **Postman** - API security testing
- **sqlmap** - SQL injection testing

### Monitoring Tools
- **Winston** - Application logging
- **Datadog** - Infrastructure monitoring
- **CloudWatch** - AWS monitoring
- **Splunk** - Log analysis (enterprise)

### Security Scanning
- **Nessus** - Vulnerability scanning
- **Qualys** - Web application scanning
- **SecurityHeaders.com** - Header analysis
- **SSL Labs** - TLS configuration testing

---

## Contact Information

**Security Team:**
- Email: security@cadealer logistics.com
- PGP Key: [Key fingerprint]
- Bug Bounty: [Program details]

**Incident Reporting:**
1. Email security team immediately
2. Include detailed description
3. Do not publicly disclose
4. Response within 24 hours

---

**Document Classification:** Internal  
**Review Frequency:** Quarterly  
**Next Review:** March 2026  
**Document Owner:** Security Team
