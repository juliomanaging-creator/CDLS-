# California Dealer Logistics Platform - EV Cost Analysis

A comprehensive web platform for comparing diesel vs. electric vehicle operating costs for wholesale automotive dealerships and car hauling operations.

## 🚀 Features

### Core Functionality
- **Real-time Cost Comparison**: Calculate diesel vs. EV costs for specific routes
- **City Price Tracking**: Monitor fuel and charging prices across 15+ California cities
- **Route Optimization**: Find optimal charging strategies for multi-stop routes
- **Syndicate Dashboard**: Aggregated cost analysis for dealer network members
- **Incentive Tracking**: Automated eligibility checking for federal and state EV incentives

### Security Features
- ✅ **Helmet.js** - Comprehensive HTTP header security
- ✅ **Rate Limiting** - Prevent brute force attacks (100 req/15min general, 5 req/15min auth)
- ✅ **CORS Protection** - Controlled cross-origin requests
- ✅ **Input Validation** - Express-validator on all endpoints
- ✅ **XSS Protection** - Input sanitization and output escaping
- ✅ **SQL Injection Prevention** - Parameterized queries
- ✅ **JWT Authentication** - Secure token-based auth with httpOnly cookies
- ✅ **Password Hashing** - BCrypt with 12 rounds
- ✅ **HTTPS Enforced** - HSTS with preload
- ✅ **CSP Headers** - Content Security Policy
- ✅ **HPP Protection** - HTTP Parameter Pollution prevention
- ✅ **Compression** - GZIP for reduced bandwidth

## 📋 Prerequisites

- Node.js >= 16.x
- PostgreSQL >= 15.x
- Redis >= 6.x (optional, for session management)
- npm or yarn

## 🛠️ Installation

### 1. Clone Repository

```bash
git clone <repository-url>
cd ev-cost-platform
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Environment Configuration

Copy `.env.example` to `.env` and configure:

```bash
cp .env.example .env
```

**Critical Environment Variables:**

```env
# Security - CHANGE THESE IN PRODUCTION
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
SESSION_SECRET=your_super_secret_session_key_change_this

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=ca_dealer_logistics
DB_USER=your_db_user
DB_PASSWORD=your_secure_password
DB_SSL=true

# API Keys
GASBUDDY_API_KEY=your_gasbuddy_api_key
PLUGSHARE_API_KEY=your_plugshare_api_key
GOOGLE_MAPS_API_KEY=your_google_maps_api_key
```

### 4. Database Setup

```bash
# Create database
createdb ca_dealer_logistics

# Run migrations (if using migration tool)
npm run migrate

# Or import schema directly
psql ca_dealer_logistics < database/schema.sql
```

### 5. Start Development Server

```bash
# Development mode with hot reload
npm run dev

# Production mode
npm start
```

Server will be available at `http://localhost:3000`

## 📁 Project Structure

```
ev-cost-platform/
├── server.js                 # Main server file
├── package.json              # Dependencies
├── .env.example             # Environment template
├── controllers/             # Business logic
│   ├── authController.js
│   ├── costController.js
│   ├── cityController.js
│   └── ...
├── routes/                  # API routes
│   ├── auth.js
│   ├── costComparison.js
│   ├── cities.js
│   └── ...
├── middleware/              # Custom middleware
│   ├── auth.js             # JWT authentication
│   └── validation.js       # Input validation
├── models/                  # Database models (optional ORM)
├── utils/                   # Utility functions
├── public/                  # Frontend static files
│   ├── index.html          # Main HTML
│   ├── css/
│   │   └── main.css        # Styles
│   ├── js/
│   │   ├── main.js         # Main app logic
│   │   ├── api.js          # API wrapper
│   │   ├── auth.js         # Authentication
│   │   └── ...
│   └── images/
└── logs/                    # Application logs
```

## 🔐 Security Best Practices

### Production Checklist

- [ ] Generate strong JWT_SECRET (minimum 32 characters)
- [ ] Use HTTPS in production (never HTTP)
- [ ] Enable database SSL connections
- [ ] Configure CORS for specific origin only
- [ ] Set up rate limiting per user/IP
- [ ] Enable request logging with Winston
- [ ] Configure CSP headers for your domain
- [ ] Use environment-specific secrets
- [ ] Enable SQL query logging for audit
- [ ] Set up intrusion detection monitoring
- [ ] Configure automated backups
- [ ] Use Redis for session storage in production
- [ ] Implement API key rotation policy
- [ ] Set up DDoS protection (CloudFlare)
- [ ] Enable WAF (Web Application Firewall)

### Authentication Flow

1. **Login**: POST `/api/auth/login` with email/password
2. **Token**: Receive JWT token (expires in 7 days)
3. **Storage**: Token stored in httpOnly cookie + localStorage
4. **Requests**: Include `Authorization: Bearer <token>` header
5. **Refresh**: POST `/api/auth/refresh-token` before expiry
6. **Logout**: POST `/api/auth/logout` clears tokens

### API Rate Limits

| Endpoint | Limit | Window |
|----------|-------|--------|
| General API | 100 requests | 15 minutes |
| Auth (login) | 5 attempts | 15 minutes |
| Password reset | 3 requests | 1 hour |

### Input Validation

All inputs are validated using express-validator:
- Email format validation
- Password strength requirements (8+ chars, uppercase, lowercase, number, special)
- SQL injection prevention
- XSS attack prevention
- File upload restrictions (if implemented)

## 🗄️ Database Schema

### Key Tables

```sql
-- Users & Authentication
users (id, email, password_hash, dealer_id, role, created_at)

-- Core Business Logic
cities (city_id, city_name, region, latitude, longitude)
fuel_prices (price_id, city_id, fuel_type, price_per_gallon, price_date)
ev_charging_rates (rate_id, city_id, charging_network, base_rate)
dealers (dealer_id, dealer_name, city_id, syndicate_member)
routes (route_id, origin_dealer_id, destination_dealer_id, total_distance)
cost_calculations (calc_id, route_id, diesel_total_cost, ev_total_cost)
incentives (incentive_id, incentive_name, amount, eligibility_criteria)
```

## 🔌 API Endpoints

### Authentication
```
POST   /api/auth/register          - Register new user
POST   /api/auth/login             - Login
POST   /api/auth/logout            - Logout
GET    /api/auth/me                - Get profile
PUT    /api/auth/update-password   - Update password
```

### Cost Comparison
```
POST   /api/cost-comparison/calculate       - Calculate costs
GET    /api/cost-comparison/history         - Get history
GET    /api/cost-comparison/:id             - Get by ID
POST   /api/cost-comparison/save            - Save calculation
GET    /api/cost-comparison/syndicate/aggregate - Syndicate stats
```

### Cities & Pricing
```
GET    /api/cities                     - Get all cities
GET    /api/cities/:id                 - Get city details
GET    /api/cities/:id/prices          - Get current prices
GET    /api/cities/:id/charging-stations - Get charging stations
```

### Routes
```
GET    /api/routes                - Get all routes
POST   /api/routes                - Create route
GET    /api/routes/:id            - Get route
PUT    /api/routes/:id            - Update route
DELETE /api/routes/:id            - Delete route
GET    /api/routes/:id/optimize   - Optimize route
```

### Dealers
```
GET    /api/dealers                    - Get all dealers
POST   /api/dealers                    - Create dealer (admin)
GET    /api/dealers/:id                - Get dealer
PUT    /api/dealers/:id                - Update dealer
DELETE /api/dealers/:id                - Delete dealer (admin)
GET    /api/dealers/search/nearby      - Find nearby
```

### Incentives
```
GET    /api/incentives                        - Get all incentives
GET    /api/incentives/:id                    - Get incentive
POST   /api/incentives/check-eligibility      - Check eligibility
GET    /api/incentives/alerts/expiring-soon   - Expiring soon
```

## 🧪 Testing

```bash
# Run all tests
npm test

# Run specific test suite
npm test -- auth.test.js

# Coverage report
npm run test:coverage
```

## 📊 Monitoring

### Health Check

```bash
curl http://localhost:3000/api/health
```

### Logs

Application logs are stored in `./logs/app.log`

Monitor with:
```bash
tail -f logs/app.log
```

## 🚢 Deployment

### Docker Deployment

```dockerfile
# Dockerfile included in project
docker build -t ca-dealer-logistics .
docker run -p 3000:3000 --env-file .env ca-dealer-logistics
```

### AWS Deployment

1. EC2 instance with Node.js
2. RDS PostgreSQL database
3. ElastiCache Redis
4. CloudFront CDN
5. Route 53 DNS
6. ACM SSL certificate

### Environment-Specific Config

```bash
# Development
NODE_ENV=development npm start

# Production
NODE_ENV=production npm start
```

## 🔄 Updates & Maintenance

### Database Migrations

```bash
# Create migration
npm run migrate:create <migration-name>

# Run migrations
npm run migrate:up

# Rollback
npm run migrate:down
```

### Dependency Updates

```bash
# Check for updates
npm outdated

# Update dependencies
npm update

# Security audit
npm audit
npm audit fix
```

## 📝 R&D Tax Credit Documentation

This software qualifies for R&D tax credits under IRC Section 41. Key innovations:

1. **Multi-stop route optimization** with charging strategy
2. **Payload-adjusted EV range modeling**
3. **Time-of-use rate optimization engine**
4. **Dealer network cost aggregation with privacy**
5. **Real-time multi-source pricing integration**
6. **Predictive maintenance cost modeling**
7. **Incentive eligibility automation**
8. **Stochastic fuel price forecasting**

Document development time quarterly for tax purposes.

## 🤝 Contributing

1. Fork repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Open Pull Request

## 📄 License

Proprietary - California Dealer Logistics Syndicate

## 📧 Support

For technical support or questions:
- Email: support@cadealer logistics.com
- Documentation: https://docs.cadealer logistics.com

## ⚠️ Important Security Notes

1. **Never commit `.env` file** - Contains sensitive credentials
2. **Rotate API keys quarterly** - Maintain security hygiene
3. **Monitor failed login attempts** - Detect brute force attacks
4. **Keep dependencies updated** - Patch security vulnerabilities
5. **Use strong passwords** - Enforce policy for all users
6. **Backup database daily** - Maintain disaster recovery capability
7. **Review logs regularly** - Monitor for suspicious activity
8. **Test security headers** - Use securityheaders.com
9. **Scan for vulnerabilities** - Use npm audit and Snyk
10. **Implement 2FA** - Add second factor authentication (roadmap)

---

**Version:** 1.0.0  
**Last Updated:** December 2025  
**Node Version:** >=16.x  
**PostgreSQL Version:** >=15.x
