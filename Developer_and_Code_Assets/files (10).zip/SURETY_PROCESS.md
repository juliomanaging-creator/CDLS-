# Surety Bond — Acquisition Process

Two separate bonds are in play. Only the first is urgent.

| Bond | Amount | Trigger | Status |
|---|---|---|---|
| **BMC-84** freight broker bond | $75,000 | Required before you may lawfully broker a single load | **Urgent — R-01** |
| DFAL surety bond | ~$500,000 | Only if you issue or administer a transferable digital asset | Not applicable under v2.0 |
| Attestor bond (private) | Your choice | Optional control on the quorum | Design decision |

Not legal advice. Confirm scope with transportation counsel before filing.

---

## 1. BMC-84 — what it actually is

A common and expensive misunderstanding: **this bond does not protect you.** It is a
$75,000 financial guarantee to the FMCSA that carriers and shippers get paid. If you fail to
pay a hauler, they claim against the bond.

It is **not insurance — it is a credit relationship.** When the surety pays a claim, it
seeks full reimbursement from you, and will pursue you in court if you don't repay.
Personal indemnity from principals is standard. Read §5 before signing anything.

The $75,000 is a **maximum aggregate**, not a per-claim limit. Claims stack. If your
security drops below $75,000 you have roughly seven business days to restore it or lose
operating authority.

---

## 2. Process and timing

Approval typically runs 1–3 business days with a clean profile; a week if anything is
complicated. The bond is one component of broker authority, not the whole thing.

**Step 1 — Identity verification.** As of 2026 you must complete identity verification via
Login.gov before FMCSA will process your application. Do this first; it gates everything.

**Step 2 — Apply to a surety.** Online application, soft credit pull only (confirm this —
some agencies hard-pull). You get a quoted rate as a percentage of $75,000.

**Step 3 — Purchase and electronic filing.** The agency files Form BMC-84 with FMCSA on your
behalf. **Insist on electronic filing.** FMCSA status flips to "Bonded" almost immediately,
where paper filings can take weeks.

**Step 4 — BOC-3 process agents.** Designates a legal agent in every state to accept court
papers. Separate filing, cheap, and authority isn't finalised without it.

**Step 5 — Confirm authority is active** before moving a load. Not "applied for." Active.

---

## 3. What it costs

Premium is a percentage of the $75,000, set by credit and financials:

| Profile | Rate | Annual premium |
|---|---|---|
| Well-qualified, strong credit | ~1.25% | ~$938 |
| Most new brokers | 2–4% | $1,500–$3,000 |
| Average credit | 7–13% | $5,000–$10,000 |

**The market is tightening.** California, Texas, Florida, Georgia and Illinois accounted for
roughly half of all net broker closures over the past two years, and sureties have become
more selective about who they bond and at what rate. Being a new California brokerage puts
you in the segment they are scrutinising hardest.

### BMC-84 vs BMC-85
BMC-85 is the alternative: deposit the full $75,000 into a trust fund. It ties up capital
you do not have. At $53K annual revenue, the bond is the only realistic option — but expect
the underwriter to notice that revenue figure.

---

## 4. Underwriting — what they will actually look at

Assume they ask for all of it:

- Personal credit of every principal (the dominant pricing factor)
- Business financials — and yours are thin
- Industry experience of the principals
- Claims history
- Whether you have been brokering already

**Prepare for the last one.** If loads have moved on those handshake agreements without
authority, an underwriter may ask directly. Answering badly is worse than the underlying
problem. Get counsel's view on how to characterise past activity before you fill in a form.

### Improving your rate
- Apply with the strongest-credit principal as primary indemnitor
- Have twelve months of clean financials ready even if the numbers are small
- Signed dealer MSAs help — they read as revenue durability, and you need them anyway
- Shop three agencies. Rates vary widely for identical risk.
- Lock the initial rate if offered; some agencies hold quotes up to 90 days

---

## 5. Before you sign — read the indemnity agreement

This is the part people skim and regret.

- **Personal guarantees.** Most sureties require principals to personally indemnify. Given
  49 U.S.C. § 14916 already exposes officers and directors personally for unauthorised
  brokering, understand exactly how much personal exposure you are stacking.
- **Spousal signatures.** Frequently requested. Know before it is put in front of you.
- **Collateral.** Most applicants avoid posting cash, but weak financials can trigger a
  demand for it.
- **Renewal terms.** Annual. The rate can move at renewal, and a claim moves it sharply.
- **Cancellation notice.** How much warning you get if the surety exits. This determines
  whether you can replace coverage inside the seven-day restoration window.

---

## 6. Sequencing

1. Stop brokering until authority is active, if you have started.
2. Login.gov identity verification.
3. Quotes from three agencies simultaneously.
4. Counsel reviews the indemnity agreement — not just the premium.
5. Purchase, electronic BMC-84 filing, BOC-3.
6. Confirm active authority in FMCSA records.
7. Bind contingent cargo and contingent auto liability. The bond does not cover cargo loss
   or accidents; it covers non-payment.

---

## 7. The attestor bond (separate, optional)

If you want economic consequences for fraudulent attestations, three routes:

| Route | Mechanics | Trade-off |
|---|---|---|
| **Cash escrow** | Attestor deposits USD; forfeited on proven fraud | Simplest. Ties up attestor capital. |
| **Commercial surety** | Attestor posts a bond naming CDLS as obligee | No capital tied up. Slow claims; underwriter must understand the risk. |
| **On-chain stablecoin stake** | USDC in a slashing contract | Fast, programmatic. Custody and smart-contract risk. |

For a quorum of professional verifiers, **contractual liability with an E&O requirement is
usually sufficient** and far simpler than any bonding scheme. Escalate to escrow or staking
only if attestors are parties you cannot otherwise hold accountable.

Whichever route: do not issue a token for this. A cash bond produces identical slashing
economics with none of the securities exposure.
