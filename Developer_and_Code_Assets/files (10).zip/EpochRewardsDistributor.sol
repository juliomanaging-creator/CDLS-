// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {MerkleProof} from "@openzeppelin/contracts/utils/cryptography/MerkleProof.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/**
 * @title EpochRewardsDistributor
 * @notice Pays operator rewards per epoch via Merkle proof, from PRE-FUNDED budgets only.
 *
 * ============================ DESIGN CONSTRAINT: NO UNFUNDED PROMISES ====================
 *
 * An epoch cannot be opened unless the tokens for it are already sitting in this contract
 * and unreserved. This is deliberate and is the main thing separating a rewards program
 * from an accrual liability.
 *
 * The whitepaper allocates 350,000,000 CDLS (35%) to operator rewards and separately
 * promises operators 40% of carbon credit revenue. If reward emissions are not hard-capped
 * against a funded budget, the program becomes an obligation the treasury cannot meet once
 * credit revenue undershoots -- which, on the corrected price assumptions in
 * docs/POST_MORTEM.md, it will by roughly a factor of six.
 *
 * Merkle distribution (rather than on-chain per-trip payout) is used because:
 *   - Reward computation depends on off-chain LCFS credit settlement, which lands quarterly
 *     and is subject to third-party verification (mandatory for electricity pathways from
 *     2026). On-chain instant payout would front-run the verification it depends on.
 *   - Gas cost of per-trip settlement across 500+ operators is prohibitive.
 *   - Unclaimed rewards can expire back to treasury rather than leaking permanently.
 *
 * OPERATIONAL REQUIREMENT: publish the full epoch leaf set (operator, amount, contributing
 * trip IDs) to IPFS or equivalent and record the CID on-chain via `dataURI`. A Merkle root
 * with no published preimage is unauditable and operators cannot verify they were paid
 * correctly.
 *
 * ========================================================================================
 */
contract EpochRewardsDistributor is AccessControl, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant DISTRIBUTOR_ROLE = keccak256("DISTRIBUTOR_ROLE");
    bytes32 public constant TREASURER_ROLE = keccak256("TREASURER_ROLE");

    struct Epoch {
        bytes32 merkleRoot;
        uint128 budget; // total claimable in this epoch
        uint128 claimed;
        uint64 claimDeadline; // after this, remainder is sweepable
        string dataURI; // IPFS CID of the full leaf set -- REQUIRED
    }

    IERC20 public immutable token;

    mapping(uint256 epochId => Epoch) public epochs;
    mapping(uint256 epochId => mapping(uint256 wordIndex => uint256 bitmap)) private _claimed;

    /// @notice Tokens locked against open epochs. Cannot be swept.
    uint256 public reserved;

    event EpochOpened(uint256 indexed epochId, bytes32 merkleRoot, uint256 budget, string dataURI);
    event Claimed(uint256 indexed epochId, uint256 index, address indexed account, uint256 amount);
    event EpochExpired(uint256 indexed epochId, uint256 returned);

    error EpochExists();
    error EpochUnknown();
    error AlreadyClaimed();
    error InvalidProof();
    error ClaimWindowClosed();
    error ClaimWindowOpen();
    error InsufficientUnreservedBalance();
    error BudgetExceeded();
    error MissingDataURI();

    constructor(IERC20 token_, address admin) {
        token = token_;
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
    }

    /**
     * @notice Open an epoch. Reverts unless the contract already holds `budget` unreserved.
     * @param dataURI IPFS CID (or equivalent) of the published leaf set. Non-empty enforced.
     */
    function openEpoch(
        uint256 epochId,
        bytes32 merkleRoot,
        uint128 budget,
        uint64 claimDeadline,
        string calldata dataURI
    ) external onlyRole(DISTRIBUTOR_ROLE) {
        if (epochs[epochId].merkleRoot != bytes32(0)) revert EpochExists();
        if (bytes(dataURI).length == 0) revert MissingDataURI();
        if (claimDeadline <= block.timestamp) revert ClaimWindowClosed();

        uint256 unreserved = token.balanceOf(address(this)) - reserved;
        if (unreserved < budget) revert InsufficientUnreservedBalance();

        epochs[epochId] = Epoch({
            merkleRoot: merkleRoot,
            budget: budget,
            claimed: 0,
            claimDeadline: claimDeadline,
            dataURI: dataURI
        });
        reserved += budget;

        emit EpochOpened(epochId, merkleRoot, budget, dataURI);
    }

    function isClaimed(uint256 epochId, uint256 index) public view returns (bool) {
        uint256 word = index / 256;
        uint256 bit = index % 256;
        return (_claimed[epochId][word] >> bit) & 1 == 1;
    }

    function claim(
        uint256 epochId,
        uint256 index,
        address account,
        uint128 amount,
        bytes32[] calldata proof
    ) external nonReentrant {
        Epoch storage e = epochs[epochId];
        if (e.merkleRoot == bytes32(0)) revert EpochUnknown();
        if (block.timestamp > e.claimDeadline) revert ClaimWindowClosed();
        if (isClaimed(epochId, index)) revert AlreadyClaimed();

        // Double-hashed leaf: standard defence against second-preimage attacks on
        // Merkle trees where an internal node could be replayed as a leaf.
        bytes32 leaf = keccak256(bytes.concat(keccak256(abi.encode(index, account, amount))));
        if (!MerkleProof.verifyCalldata(proof, e.merkleRoot, leaf)) revert InvalidProof();

        if (e.claimed + amount > e.budget) revert BudgetExceeded();

        _claimed[epochId][index / 256] |= (1 << (index % 256));
        e.claimed += amount;
        reserved -= amount;

        token.safeTransfer(account, amount);
        emit Claimed(epochId, index, account, amount);
    }

    /// @notice After the deadline, release the unclaimed remainder back to unreserved balance.
    function expireEpoch(uint256 epochId) external onlyRole(TREASURER_ROLE) {
        Epoch storage e = epochs[epochId];
        if (e.merkleRoot == bytes32(0)) revert EpochUnknown();
        if (block.timestamp <= e.claimDeadline) revert ClaimWindowOpen();

        uint256 remainder = e.budget - e.claimed;
        if (remainder == 0) return;

        e.budget = e.claimed;
        reserved -= remainder;

        emit EpochExpired(epochId, remainder);
    }

    /// @notice Withdraw tokens not reserved against any open epoch.
    function withdrawUnreserved(address to, uint256 amount) external onlyRole(TREASURER_ROLE) {
        uint256 unreserved = token.balanceOf(address(this)) - reserved;
        if (amount > unreserved) revert InsufficientUnreservedBalance();
        token.safeTransfer(to, amount);
    }
}
