// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {EnvironmentalAttributeRegistry as Reg} from "../src/EnvironmentalAttributeRegistry.sol";
import {IAccessControl} from "@openzeppelin/contracts/access/IAccessControl.sol";

contract EnvironmentalAttributeRegistryTest is Test {
    Reg reg;

    address admin = address(0xA11CE);
    address issuer = address(0x155);
    address custodian = address(0xC057);
    address verifier = address(0x7E51);
    address stranger = address(0x57A);

    address holder = address(0x901DE7);
    address buyer = address(0xB07);
    address buyer2 = address(0xB08);
    address buyer3 = address(0xB09);

    bytes32 constant SERIAL = keccak256("LRT-CBTS-2026Q3-000001");
    bytes32 constant ROOT = keccak256("merkle-root-of-finalized-trips");
    string constant URI = "ipfs://bafy.../disclosure";

    function setUp() public {
        reg = new Reg(admin);
        vm.startPrank(admin);
        reg.grantRole(reg.ISSUER_ROLE(), issuer);
        reg.grantRole(reg.CUSTODIAN_ROLE(), custodian);
        reg.grantRole(reg.VERIFIER_ROLE(), verifier);
        vm.stopPrank();
    }

    function _issue(bytes32 serial, uint64 credits) internal returns (uint256 id) {
        vm.prank(issuer);
        id = reg.issueBatch(serial, 20263, credits, 1_000_000, ROOT, holder, URI);
    }

    function _issueVerified(bytes32 serial, uint64 credits) internal returns (uint256 id) {
        id = _issue(serial, credits);
        vm.prank(verifier);
        reg.recordVerification(id, keccak256("verification-statement"));
    }

    function _status(uint256 id) internal view returns (Reg.Status) {
        (,,,,,,,, Reg.Status s) = reg.batches(id);
        return s;
    }

    function _holder(uint256 id) internal view returns (address h) {
        (,,,,,,, h,) = reg.batches(id);
    }

    function _hops(uint256 id) internal view returns (uint32 c) {
        (,,,, c,,,,) = reg.batches(id);
    }

    // ------------------------------------------------------------------ lifecycle

    function test_FullLifecycle() public {
        uint256 id = _issue(SERIAL, 1_000);
        assertEq(uint8(_status(id)), uint8(Reg.Status.Issued));
        assertEq(reg.totalCreditsIssuedMilli(), 1_000);

        vm.prank(verifier);
        reg.recordVerification(id, keccak256("vs"));
        assertEq(uint8(_status(id)), uint8(Reg.Status.Verified));

        vm.prank(custodian);
        reg.recordTransfer(id, buyer);
        assertEq(uint8(_status(id)), uint8(Reg.Status.Transferred));
        assertEq(_holder(id), buyer);

        vm.prank(custodian);
        reg.retireBatch(id, buyer, "compliance surrender");
        assertEq(uint8(_status(id)), uint8(Reg.Status.Retired));
        assertEq(reg.totalCreditsRetiredMilli(), 1_000);
    }

    function test_RetireDirectlyFromVerified() public {
        uint256 id = _issueVerified(SERIAL, 500);
        vm.prank(custodian);
        reg.retireBatch(id, holder, "self-retirement");
        assertEq(uint8(_status(id)), uint8(Reg.Status.Retired));
    }

    function test_BatchIdsIncrement() public {
        assertEq(_issue(keccak256("s1"), 100), 1);
        assertEq(_issue(keccak256("s2"), 100), 2);
        assertEq(reg.nextBatchId(), 3);
    }

    // ------------------------------------------------------------------ double counting

    function test_RevertWhen_DuplicateSerial() public {
        _issue(SERIAL, 1_000);
        vm.prank(issuer);
        vm.expectRevert(Reg.SerialAlreadyRecorded.selector);
        reg.issueBatch(SERIAL, 20263, 1_000, 1_000_000, ROOT, holder, URI);
    }

    /// @dev The critical property: a retired serial can never re-enter the ledger.
    function test_RevertWhen_SerialReusedAfterRetirement() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        vm.prank(custodian);
        reg.retireBatch(id, buyer, "retired");

        vm.prank(issuer);
        vm.expectRevert(Reg.SerialAlreadyRecorded.selector);
        reg.issueBatch(SERIAL, 20264, 1_000, 1_000_000, ROOT, holder, URI);
    }

    function testFuzz_SerialUniquenessHolds(bytes32 serial) public {
        _issue(serial, 100);
        vm.prank(issuer);
        vm.expectRevert(Reg.SerialAlreadyRecorded.selector);
        reg.issueBatch(serial, 20263, 100, 1_000_000, ROOT, holder, URI);
    }

    // ------------------------------------------------------------------ input validation

    function test_RevertWhen_MissingDisclosureURI() public {
        vm.prank(issuer);
        vm.expectRevert(Reg.MissingDisclosure.selector);
        reg.issueBatch(SERIAL, 20263, 1_000, 1_000_000, ROOT, holder, "");
    }

    function test_RevertWhen_ZeroTripSetRoot() public {
        vm.prank(issuer);
        vm.expectRevert(Reg.InvalidParams.selector);
        reg.issueBatch(SERIAL, 20263, 1_000, 1_000_000, bytes32(0), holder, URI);
    }

    function test_RevertWhen_ZeroCredits() public {
        vm.prank(issuer);
        vm.expectRevert(Reg.InvalidParams.selector);
        reg.issueBatch(SERIAL, 20263, 0, 1_000_000, ROOT, holder, URI);
    }

    function test_RevertWhen_ZeroHolder() public {
        vm.prank(issuer);
        vm.expectRevert(Reg.InvalidParams.selector);
        reg.issueBatch(SERIAL, 20263, 1_000, 1_000_000, ROOT, address(0), URI);
    }

    function test_RevertWhen_ZeroVerificationHash() public {
        uint256 id = _issue(SERIAL, 1_000);
        vm.prank(verifier);
        vm.expectRevert(Reg.InvalidParams.selector);
        reg.recordVerification(id, bytes32(0));
    }

    function test_RevertWhen_UpdateDisclosureEmpty() public {
        uint256 id = _issue(SERIAL, 1_000);
        vm.prank(issuer);
        vm.expectRevert(Reg.MissingDisclosure.selector);
        reg.updateDisclosure(id, "");
    }

    function test_UpdateDisclosureSucceeds() public {
        uint256 id = _issue(SERIAL, 1_000);
        vm.prank(issuer);
        reg.updateDisclosure(id, "ipfs://updated");
        assertEq(reg.disclosureURI(id), "ipfs://updated");
    }

    // ------------------------------------------------------------------ state machine

    function test_RevertWhen_VerifyUnknownBatch() public {
        vm.prank(verifier);
        vm.expectRevert(Reg.UnknownBatch.selector);
        reg.recordVerification(999, keccak256("vs"));
    }

    function test_RevertWhen_VerifyTwice() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        vm.prank(verifier);
        vm.expectRevert(Reg.WrongStatus.selector);
        reg.recordVerification(id, keccak256("vs2"));
    }

    function test_RevertWhen_TransferBeforeVerification() public {
        uint256 id = _issue(SERIAL, 1_000);
        vm.prank(custodian);
        vm.expectRevert(Reg.WrongStatus.selector);
        reg.recordTransfer(id, buyer);
    }

    function test_RevertWhen_RetireBeforeVerification() public {
        uint256 id = _issue(SERIAL, 1_000);
        vm.prank(custodian);
        vm.expectRevert(Reg.WrongStatus.selector);
        reg.retireBatch(id, buyer, "premature");
    }

    function test_RevertWhen_RetireTwice() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        vm.startPrank(custodian);
        reg.retireBatch(id, buyer, "first");
        vm.expectRevert(Reg.WrongStatus.selector);
        reg.retireBatch(id, buyer, "second");
        vm.stopPrank();
    }

    function test_RevertWhen_TransferToZero() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        vm.prank(custodian);
        vm.expectRevert(Reg.InvalidParams.selector);
        reg.recordTransfer(id, address(0));
    }

    function test_RevertWhen_VerifyAfterTransfer() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        vm.prank(custodian);
        reg.recordTransfer(id, buyer);
        vm.prank(verifier);
        vm.expectRevert(Reg.WrongStatus.selector);
        reg.recordVerification(id, keccak256("vs2"));
    }

    // ------------------------------------------------------------------ multi-hop custody

    /// @dev Was FINDING #1: a batch could only ever be transferred once, truncating the
    ///      custody chain at the first sale. Real chains are CDLS -> broker -> end buyer.
    function test_MultiHopTransferChain() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        assertEq(_hops(id), 0);

        vm.startPrank(custodian);
        reg.recordTransfer(id, buyer);
        assertEq(_holder(id), buyer);
        assertEq(_hops(id), 1);

        reg.recordTransfer(id, buyer2); // broker on-sells
        assertEq(_holder(id), buyer2);
        assertEq(_hops(id), 2);

        reg.recordTransfer(id, buyer3); // and again
        assertEq(_holder(id), buyer3);
        assertEq(_hops(id), 3);
        vm.stopPrank();

        assertEq(uint8(_status(id)), uint8(Reg.Status.Transferred));
    }

    function test_MultiHop_RetireAtEndOfChain() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        vm.startPrank(custodian);
        reg.recordTransfer(id, buyer);
        reg.recordTransfer(id, buyer2);
        reg.retireBatch(id, buyer2, "end buyer surrender");
        vm.stopPrank();

        assertEq(uint8(_status(id)), uint8(Reg.Status.Retired));
        assertEq(reg.totalCreditsRetiredMilli(), 1_000);
        assertEq(_hops(id), 2, "custody depth preserved through retirement");
    }

    function test_RevertWhen_TransferToCurrentHolder() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        vm.prank(custodian);
        vm.expectRevert(Reg.InvalidParams.selector);
        reg.recordTransfer(id, holder); // no-op hop would pollute the chain
    }

    function test_RevertWhen_TransferAfterRetirement() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        vm.startPrank(custodian);
        reg.retireBatch(id, buyer, "done");
        vm.expectRevert(Reg.WrongStatus.selector);
        reg.recordTransfer(id, buyer2);
        vm.stopPrank();
    }

    function testFuzz_HopCountMatchesTransfers(uint8 hops) public {
        hops = uint8(bound(hops, 1, 20));
        uint256 id = _issueVerified(SERIAL, 1_000);
        vm.startPrank(custodian);
        for (uint256 i = 0; i < hops; ++i) {
            reg.recordTransfer(id, address(uint160(0x2000 + i)));
        }
        vm.stopPrank();
        assertEq(_hops(id), hops);
    }

    // ------------------------------------------------------------------ batch rejection

    /// @dev Was FINDING #2: an erroneously issued batch was unfixable and left
    ///      totalCreditsIssuedMilli permanently inflated. Public reporting built on that
    ///      total would overstate — bad anywhere, worse under AB 1305.
    function test_RejectBatch_BacksOutIssuedTotal() public {
        uint256 id = _issue(SERIAL, 5_000);
        assertEq(reg.totalCreditsIssuedMilli(), 5_000);

        vm.prank(verifier);
        reg.rejectBatch(id, "meter data failed sampling");

        assertEq(uint8(_status(id)), uint8(Reg.Status.Rejected));
        assertEq(reg.totalCreditsIssuedMilli(), 0, "issued total corrected");
    }

    function test_RejectBatch_OnlyAffectsThatBatch() public {
        _issue(keccak256("s1"), 3_000);
        uint256 bad = _issue(keccak256("s2"), 5_000);
        _issue(keccak256("s3"), 2_000);
        assertEq(reg.totalCreditsIssuedMilli(), 10_000);

        vm.prank(verifier);
        reg.rejectBatch(bad, "rejected");
        assertEq(reg.totalCreditsIssuedMilli(), 5_000);
    }

    /// @dev Key design decision: rejection does NOT release the serial. Freeing it would
    ///      open an issue-reject-reissue loop defeating the double-count guarantee.
    function test_RejectedSerialStaysBurnedForever() public {
        uint256 id = _issue(SERIAL, 1_000);
        vm.prank(verifier);
        reg.rejectBatch(id, "bad batch");

        vm.prank(issuer);
        vm.expectRevert(Reg.SerialAlreadyRecorded.selector);
        reg.issueBatch(SERIAL, 20263, 1_000, 1_000_000, ROOT, holder, URI);
    }

    function test_RevertWhen_RejectAfterVerification() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        vm.prank(verifier);
        vm.expectRevert(Reg.WrongStatus.selector);
        reg.rejectBatch(id, "too late");
    }

    function test_RevertWhen_RejectTwice() public {
        uint256 id = _issue(SERIAL, 1_000);
        vm.startPrank(verifier);
        reg.rejectBatch(id, "first");
        vm.expectRevert(Reg.WrongStatus.selector);
        reg.rejectBatch(id, "second");
        vm.stopPrank();
    }

    function test_RevertWhen_RejectUnknownBatch() public {
        vm.prank(verifier);
        vm.expectRevert(Reg.UnknownBatch.selector);
        reg.rejectBatch(999, "nope");
    }

    function test_RevertWhen_VerifyAfterReject() public {
        uint256 id = _issue(SERIAL, 1_000);
        vm.startPrank(verifier);
        reg.rejectBatch(id, "rejected");
        vm.expectRevert(Reg.WrongStatus.selector);
        reg.recordVerification(id, keccak256("vs"));
        vm.stopPrank();
    }

    function test_RevertWhen_TransferAfterReject() public {
        uint256 id = _issue(SERIAL, 1_000);
        vm.prank(verifier);
        reg.rejectBatch(id, "rejected");
        vm.prank(custodian);
        vm.expectRevert(Reg.WrongStatus.selector);
        reg.recordTransfer(id, buyer);
    }

    function test_RevertWhen_RetireAfterReject() public {
        uint256 id = _issue(SERIAL, 1_000);
        vm.prank(verifier);
        reg.rejectBatch(id, "rejected");
        vm.prank(custodian);
        vm.expectRevert(Reg.WrongStatus.selector);
        reg.retireBatch(id, buyer, "nope");
    }

    /// @dev Issuers deliberately cannot erase their own entries. The independent verifier
    ///      is the control that makes public totals trustworthy.
    function test_RevertWhen_IssuerRejects() public {
        uint256 id = _issue(SERIAL, 1_000);
        bytes32 role = reg.VERIFIER_ROLE();
        vm.expectRevert(
            abi.encodeWithSelector(IAccessControl.AccessControlUnauthorizedAccount.selector, issuer, role)
        );
        vm.prank(issuer);
        reg.rejectBatch(id, "self-erase");
    }

    function test_RetiredNeverExceedsIssued_WithRejections() public {
        uint256 a = _issueVerified(keccak256("s1"), 4_000);
        uint256 bad = _issue(keccak256("s2"), 9_000);

        vm.prank(verifier);
        reg.rejectBatch(bad, "rejected");

        vm.prank(custodian);
        reg.retireBatch(a, buyer, "r");

        assertLe(reg.totalCreditsRetiredMilli(), reg.totalCreditsIssuedMilli());
        assertEq(reg.totalCreditsIssuedMilli(), 4_000);
        assertEq(reg.totalCreditsRetiredMilli(), 4_000);
    }

    // ------------------------------------------------------------------ accounting

    function test_TotalsAccumulateCorrectly() public {
        uint256 a = _issueVerified(keccak256("s1"), 1_500);
        uint256 b = _issueVerified(keccak256("s2"), 2_500);
        assertEq(reg.totalCreditsIssuedMilli(), 4_000);

        vm.startPrank(custodian);
        reg.retireBatch(a, buyer, "r1");
        assertEq(reg.totalCreditsRetiredMilli(), 1_500);
        reg.retireBatch(b, buyer, "r2");
        assertEq(reg.totalCreditsRetiredMilli(), 4_000);
        vm.stopPrank();
    }

    function test_RetiredNeverExceedsIssued() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        vm.prank(custodian);
        reg.retireBatch(id, buyer, "r");
        assertLe(reg.totalCreditsRetiredMilli(), reg.totalCreditsIssuedMilli());
    }

    // ------------------------------------------------------------------ access control

    function test_RevertWhen_StrangerIssues() public {
        bytes32 role = reg.ISSUER_ROLE();
        vm.expectRevert(
            abi.encodeWithSelector(IAccessControl.AccessControlUnauthorizedAccount.selector, stranger, role)
        );
        vm.prank(stranger);
        reg.issueBatch(SERIAL, 20263, 1_000, 1_000_000, ROOT, holder, URI);
    }

    function test_RevertWhen_StrangerVerifies() public {
        uint256 id = _issue(SERIAL, 1_000);
        bytes32 role = reg.VERIFIER_ROLE();
        vm.expectRevert(
            abi.encodeWithSelector(IAccessControl.AccessControlUnauthorizedAccount.selector, stranger, role)
        );
        vm.prank(stranger);
        reg.recordVerification(id, keccak256("vs"));
    }

    function test_RevertWhen_StrangerTransfers() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        bytes32 role = reg.CUSTODIAN_ROLE();
        vm.expectRevert(
            abi.encodeWithSelector(IAccessControl.AccessControlUnauthorizedAccount.selector, stranger, role)
        );
        vm.prank(stranger);
        reg.recordTransfer(id, buyer);
    }

    function test_RevertWhen_StrangerRetires() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        bytes32 role = reg.CUSTODIAN_ROLE();
        vm.expectRevert(
            abi.encodeWithSelector(IAccessControl.AccessControlUnauthorizedAccount.selector, stranger, role)
        );
        vm.prank(stranger);
        reg.retireBatch(id, buyer, "theft");
    }

    /// @dev The holder has NO on-chain agency: the custodian alone moves and retires
    ///      batches. Correct for a bookkeeping mirror (and what keeps this outside DFAL
    ///      scope), but it makes CUSTODIAN_ROLE a critical key. Multisig only.
    function test_HolderCannotActOnOwnBatch_KeyRiskDocumented() public {
        uint256 id = _issueVerified(SERIAL, 1_000);
        bytes32 role = reg.CUSTODIAN_ROLE();
        vm.expectRevert(
            abi.encodeWithSelector(IAccessControl.AccessControlUnauthorizedAccount.selector, holder, role)
        );
        vm.prank(holder);
        reg.recordTransfer(id, buyer);
    }
}
