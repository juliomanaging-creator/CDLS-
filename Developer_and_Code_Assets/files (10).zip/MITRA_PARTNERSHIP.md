# Mitra EV — Partnership Approach & Term Sheet Checklist

Prepared 6 August 2026. Structures below are market-typical for charging-as-a-service
and channel arrangements — they are **not** Mitra's published terms, which are not public.
Treat this as a negotiation map, not a quote.

---

## 1. Who you are dealing with

| | |
|---|---|
| Company | Mitra EV, Sacramento |
| Leadership | Galina Russell (Co-founder/CEO, ex-REEF Energy, SIXT, McKinsey); James Tong (Co-founder/CSO, ex-Zeem Solutions, Chanje Energy, Spruce Power) |
| Funding | $27M closed Feb 2026 — equity led by Ultra Capital, credit facility from S2G Investments. Ultra led a $5M seed in 2023. |
| Model | Fully managed: no-upfront-cost EV leasing from GM, Ford and Mercedes-Benz, plus dedicated overnight charging and access to shared DC fast-charging hubs. Vehicle- and charger-agnostic. |
| Footprint | Shared hubs in Rancho Cordova hosted at Sierra Pacific (2576 Mercantile Dr.) and Aztec Solar (11370 Trade Center Dr. #3). Eleven more hubs reported under construction as of April 2025. |
| Programme | Project REEF — DOE-supported, partners in CA, CO, OH, GA. |
| Stated strategy | Deepen California presence before measured geographic expansion. |

**Read on posture:** they are well-capitalised, explicitly focused on your home state, and
their stated target — SMB fleets under 50 trucks — is precisely your operator base. This is
a natural fit, but the size asymmetry is real. $27M against $53K of revenue is not a
negotiation between equals. Your leverage is demand, not scale.

---

## 2. Resolve this before you make the call

**Does Mitra's equipment actually serve your trucks?**

Their OEM lineup — GM, Ford, Mercedes-Benz — is vans and light/medium-duty. Their hubs are
built for "small urban fleets." That is delivery vans and service fleets, not Class 8.

- If your haulers run **wedge trailers behind medium-duty trucks, or single-car
  enclosed/driveaway**, Mitra's product may fit directly and this is an easy conversation.
- If they run **9-car Class 8 stingers**, Mitra's current hubs likely cannot serve them and
  the conversation changes entirely — you would be asking them to build something new.

Find out what your ten dealers' moves are actually run with. The answer determines whether
this is a channel partnership or a development conversation.

---

## 3. What you actually bring

Do not lead with software or blockchain. Lead with the thing they are short of.

1. **Anchor utilisation.** Empty chargers are the enemy of hub economics. You bring
   contracted dealer demand with predictable, repeatable short routes.
2. **Complementary duty cycle.** Their van fleets charge overnight. Dealer trades happen
   during the day. You fill their trough rather than competing for their peak — this is the
   single most persuasive point you have.
3. **A channel to their exact customer.** Independent haulers under 50 trucks are who Mitra
   sells to. You have the relationships and the reason to call.
4. **Siting pipeline.** Your dealers own large, well-lit, arterial-adjacent lots and have
   their own reasons to want green infrastructure on site. Mitra hosts hubs at businesses —
   Sierra Pacific and Aztec Solar are host sites. Dealer lots are a credible pipeline and
   this is your most differentiated asset.

**What you should not oversell:** Mitra states it already handles compliance. Do not pitch
your verification software as the centrepiece; it will land as naive. Mention it only if
they raise a reporting gap.

---

## 4. What you want out of it

Ranked by actual value to CDLS:

1. **Vehicle access.** Mitra's no-upfront-cost leasing solves your binding constraint. No
   operator owns a BEV today, which is why LCFS revenue models at roughly nothing. This is
   worth more to you than the charging.
2. **Charging access** at predictable rates for your operators.
3. **LCFS revenue share** — negotiate for it, but see §6 on realistic expectations.
4. **Zero capex.** You avoid the ~$1.4M depot and the closed-incentive problem entirely.

---

## 5. Four structures, easiest first

### A. Referral / channel agreement — start here
CDLS refers operators to Mitra for leases and charging. Fee per vehicle placed, or a per-kWh
override on referred volume.
*Zero capex, zero risk, revenue in weeks. Non-exclusive both ways. This is the handshake
that proves you can deliver before you ask for anything structural.*

### B. Anchor tenant / offtake
CDLS commits minimum monthly kWh across its operator base in exchange for discounted rates,
guaranteed access windows, and an LCFS share.
*This is where credit-sharing gets negotiated. **Danger:** do not sign take-or-pay volume
backed by independent contractors you do not control. Your operators can walk; your
commitment cannot.*

### C. Host site partnership
Introduce dealer lots as hub sites. Host typically receives rent, sometimes revenue share,
and priority access.
*Your most differentiated play. Also gives the dealer a reason to deepen the relationship
with you — it converts a handshake into infrastructure.*

### D. Joint venture on a Class 8 hub
Only if the Class 8 answer in §2 comes back yes and volume justifies it.
*Defer. Revisit when EnergIIZE reopens and you have signed dealer contracts.*

---

## 6. Term sheet checklist

### LCFS credit allocation — the one to get right
Default position is that Mitra owns the registered fuel supply equipment and therefore holds
100% of the credit claim. That claim is legitimate — they financed the asset.

- Ask for a share of credits attributable to **your operators' kWh specifically**. Opening
  at 25–50% is reasonable; expect to land well below.
- **Consider taking a rate reduction instead of a credit share.** Cleaner, immediately
  valuable, and it keeps the LCFS reporting burden off your books. Often the better trade.
- Require session-level kWh data per operator regardless of who holds the credits. You need
  it for your own reporting and for any future claim.

### Commercial
- $/kWh rate and how it is set
- **Demand charge treatment** — pass-through or absorbed. This is where fleets get hurt.
- Time-of-use windows and whether your daytime cycle is priced favourably
- Volume tiers and how they step
- Payment terms and who bills the operator: you or Mitra

### Operational
- Guaranteed access windows matched to dealer-trade timing
- Uptime SLA and what happens when a load cannot move — credits or penalties
- Queue priority relative to their other fleet customers
- Notice period for rate changes

### Legal
- **Term: 12–24 months, not 5–10.** You do not know your volume yet.
- **Exclusivity: resist. If granted, price it.** Never give it away in a first agreement.
- Data rights — session data, and confirmation it is not used to approach your dealers
- Non-solicit covering your dealer relationships
- Termination for convenience with reasonable notice
- Assignment rights if either side is acquired

---

## 7. How to make the approach

**Warm beats cold.** Candidate bridges:
- Sacramento Clean Cities Coalition — Tim Taylor, Executive Director, was quoted at the
  Mitra hub launch. Natural, credible introduction.
- City of Rancho Cordova economic development, who participated in the ribbon-cutting.
- Their host sites, Sierra Pacific and Aztec Solar, if you have any commercial overlap.

**Who to target:** James Tong, Chief Strategy Officer. Partnerships and channel structure sit
with strategy, not sales, at a company this size.

**What to send:** one page. Dealer count, monthly car volume, route profile, operator count,
and the duty-cycle complementarity argument. No whitepaper, no token narrative, no IRR.

**Opening ask:** a thirty-minute call about referral structure and whether their hubs can
serve your vehicle class. Small, concrete, easy to say yes to.

---

## 8. Do not

- Position as a competitor. You are demand; they are supply.
- Mention the withdrawn v1.0 tokenomics paper, or tokens at all.
- Commit volume your independent contractors are not contractually bound to deliver.
- Grant exclusivity in a first agreement.
- Sign anything before your FMCSA broker authority is resolved — a partner will diligence it,
  and finding it open is a bad first impression.
