// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

/**
 * @title TripAttestationRegistry
 * @notice Records verified zero-emission haul events under an M-of-N attestor quorum,
 *         with a mandatory dispute window before any economic value settles.
 *
 * ================================ WHY THIS CONTRACT EXISTS ================================
 *
 * This is the single highest-risk component in the entire system and the whitepaper gives it
 * one sentence ("redundant data verification across multiple oracle sources").
 *
 * The structural problem: the system PAYS OPERATORS TOKENS PER VERIFIED TRIP. That creates a
 * direct, unbounded financial incentive to fabricate trips. GPS and telematics feeds are
 * software-reportable and therefore spoofable -- a $30 GPS simulator defeats naive telematics
 * ingestion. If fabricated trips mint rewards, the reward pool is drained and, worse, the
 * environmental claims sold to credit buyers become fraudulent, which is a criminal exposure
 * far more serious than the token loss.
 *
 * Mitigations implemented here:
 *   1. M-of-N attestor quorum -- no single oracle can create a trip record.
 *   2. Attestations must include a hash of off-chain evidence (charger session records,
 *      dealer-countersigned bill of lading, weigh-in data). Independent parties, not just
 *      the operator's own device.
 *   3. Mandatory dispute window. Nothing settles instantly. An auditor can void a record.
 *   4. Per-operator rolling energy cap -- bounds the blast radius of a compromised attestor
 *      set to a known maximum before humans notice.
 *   5. Records are FINALIZED, not PAID. Payment happens in a separate epoch distributor
 *      funded from actual realised revenue. Attestation never mints.
 *
 * ================================ UNIT OF MEASURE CHANGE ================================
 *
 * The whitepaper measures "45 kg CO2e avoided per trip" and treats that as a saleable
 * carbon credit. It is not (see docs/POST_MORTEM.md, Finding 1). California's Low Carbon
 * Fuel Standard credits ZEV transport on ENERGY DISPENSED (MJ of electricity), adjusted by
 * an Energy Economy Ratio, against a declining carbon-intensity benchmark -- NOT on
 * counterfactual avoided diesel tonnage.
 *
 * This contract therefore records `energyWattHours` as the primary metered quantity, which
 * is what an LCFS Fuel Supply Equipment report actually needs. Avoided-emissions figures
 * may be computed off-chain for marketing, but they are not the creditable unit.
 *
 * ==========================================================================================
 */
contract TripAttestationRegistry is EIP712, AccessControl {
    bytes32 public constant ATTESTOR_ROLE = keccak256("ATTESTOR_ROLE");
    bytes32 public constant AUDITOR_ROLE = keccak256("AUDITOR_ROLE");
    bytes32 public constant GOVERNOR_ROLE = keccak256("GOVERNOR_ROLE");

    bytes32 private constant TRIP_TYPEHASH = keccak256(
        "Trip(bytes32 tripId,address operator,uint64 startTime,uint64 endTime,uint32 distanceMeters,uint64 energyWattHours,bytes32 evidenceHash)"
    );

    enum Status {
        None,
        Pending,
        Finalized,
        Voided
    }

    struct Trip {
        address operator;
        uint64 startTime;
        uint64 endTime;
        uint32 distanceMeters;
        uint64 energyWattHours; // metered charging energy attributable to this haul
        bytes32 evidenceHash; // keccak256 of the off-chain evidence bundle
        uint64 submittedAt;
        Status status;
    }

    /// @notice Number of distinct attestor signatures required per trip.
    uint8 public quorum;

    /// @notice Seconds after submission before a trip can be finalized.
    uint64 public disputeWindow;

    /// @notice Max watt-hours a single operator may accrue per rolling capPeriod.
    uint64 public operatorEnergyCap;
    uint64 public capPeriod;

    mapping(bytes32 tripId => Trip) public trips;
    mapping(address operator => mapping(uint256 periodIndex => uint64 wh)) public periodEnergy;

    event TripSubmitted(bytes32 indexed tripId, address indexed operator, uint64 energyWattHours);
    event TripFinalized(bytes32 indexed tripId, address indexed operator, uint64 energyWattHours);
    event TripVoided(bytes32 indexed tripId, string reason);
    event ParamsUpdated(uint8 quorum, uint64 disputeWindow, uint64 operatorEnergyCap);

    error TripAlreadyExists();
    error TripNotPending();
    error DisputeWindowOpen();
    error QuorumNotMet();
    error SignaturesNotSorted();
    error NotAnAttestor(address signer);
    error OperatorCapExceeded();
    error InvalidTimeRange();
    error InvalidParams();

    constructor(
        address admin,
        uint8 quorum_,
        uint64 disputeWindow_,
        uint64 operatorEnergyCap_,
        uint64 capPeriod_
    ) EIP712("CDLSTripAttestation", "1") {
        if (quorum_ == 0 || capPeriod_ == 0) revert InvalidParams();
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        quorum = quorum_;
        disputeWindow = disputeWindow_;
        operatorEnergyCap = operatorEnergyCap_;
        capPeriod = capPeriod_;
    }

    /**
     * @notice Submit a trip backed by `quorum` distinct attestor signatures.
     * @param signatures Must be ordered by ascending recovered signer address. This is how
     *                   duplicate-signer attacks are prevented without an O(n^2) scan.
     */
    function submitTrip(
        bytes32 tripId,
        address operator,
        uint64 startTime,
        uint64 endTime,
        uint32 distanceMeters,
        uint64 energyWattHours,
        bytes32 evidenceHash,
        bytes[] calldata signatures
    ) external {
        if (trips[tripId].status != Status.None) revert TripAlreadyExists();
        if (endTime <= startTime || endTime > block.timestamp) revert InvalidTimeRange();
        if (signatures.length < quorum) revert QuorumNotMet();

        bytes32 digest = _hashTypedDataV4(
            keccak256(
                abi.encode(
                    TRIP_TYPEHASH,
                    tripId,
                    operator,
                    startTime,
                    endTime,
                    distanceMeters,
                    energyWattHours,
                    evidenceHash
                )
            )
        );

        address last = address(0);
        for (uint256 i = 0; i < signatures.length; ++i) {
            address signer = ECDSA.recover(digest, signatures[i]);
            if (signer <= last) revert SignaturesNotSorted();
            if (!hasRole(ATTESTOR_ROLE, signer)) revert NotAnAttestor(signer);
            last = signer;
        }

        uint256 periodIndex = block.timestamp / capPeriod;
        uint64 accrued = periodEnergy[operator][periodIndex] + energyWattHours;
        if (accrued > operatorEnergyCap) revert OperatorCapExceeded();
        periodEnergy[operator][periodIndex] = accrued;

        trips[tripId] = Trip({
            operator: operator,
            startTime: startTime,
            endTime: endTime,
            distanceMeters: distanceMeters,
            energyWattHours: energyWattHours,
            evidenceHash: evidenceHash,
            submittedAt: uint64(block.timestamp),
            status: Status.Pending
        });

        emit TripSubmitted(tripId, operator, energyWattHours);
    }

    /// @notice Finalize after the dispute window. Permissionless -- anyone may call.
    function finalizeTrip(bytes32 tripId) external {
        Trip storage t = trips[tripId];
        if (t.status != Status.Pending) revert TripNotPending();
        if (block.timestamp < t.submittedAt + disputeWindow) revert DisputeWindowOpen();

        t.status = Status.Finalized;
        emit TripFinalized(tripId, t.operator, t.energyWattHours);
    }

    /// @notice Void a pending trip. Auditors only, and only inside the dispute window.
    function voidTrip(bytes32 tripId, string calldata reason) external onlyRole(AUDITOR_ROLE) {
        Trip storage t = trips[tripId];
        if (t.status != Status.Pending) revert TripNotPending();

        uint256 periodIndex = t.submittedAt / capPeriod;
        periodEnergy[t.operator][periodIndex] -= t.energyWattHours;

        t.status = Status.Voided;
        emit TripVoided(tripId, reason);
    }

    function setParams(uint8 quorum_, uint64 disputeWindow_, uint64 operatorEnergyCap_)
        external
        onlyRole(GOVERNOR_ROLE)
    {
        if (quorum_ == 0) revert InvalidParams();
        quorum = quorum_;
        disputeWindow = disputeWindow_;
        operatorEnergyCap = operatorEnergyCap_;
        emit ParamsUpdated(quorum_, disputeWindow_, operatorEnergyCap_);
    }
}
