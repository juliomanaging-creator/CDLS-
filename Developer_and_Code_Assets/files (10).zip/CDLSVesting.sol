// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable2Step, Ownable} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/**
 * @title CDLSVesting
 * @notice Per-beneficiary vesting with cliff, linear accrual, and optional revocation.
 *
 * ============================ DEVIATIONS FROM WHITEPAPER v1.0 ============================
 *
 * The whitepaper lists a single global "Vesting Period: 36 months (linear)" with NO CLIFF
 * and NO differentiation between founder, institutional, and treasury allocations. That is
 * a material red flag to any diligence process:
 *
 *   - Founder/team tokens vesting linearly from t=0 means the team can sell from day one.
 *     Standard market practice is a 12-month cliff then 24-36 months linear.
 *   - Institutional tokens purchased under Reg D are subject to Rule 144 holding periods
 *     that operate INDEPENDENTLY of this contract. Contract vesting is not a substitute
 *     for transfer restrictions; you need both.
 *   - Operator reward tokens should generally NOT be locked at all -- the whitepaper's own
 *     thesis is that immediate token rewards give haulers a "liquidity advantage." Locking
 *     them destroys that.
 *
 * This contract therefore supports per-schedule parameters rather than one global setting.
 * Recommended configuration is in docs/DEPLOYMENT_PARAMS.md.
 *
 * REVOCATION WARNING: a revocable schedule means the issuer can claw back unvested tokens.
 * For team grants this is normal. Applying it to INVESTOR allocations would likely be
 * viewed as the issuer retaining control over investor assets -- discuss with counsel
 * before enabling.
 *
 * ========================================================================================
 */
contract CDLSVesting is Ownable2Step, ReentrancyGuard {
    using SafeERC20 for IERC20;

    struct Schedule {
        uint128 total; // total tokens granted
        uint128 released; // tokens already withdrawn
        uint64 start; // accrual start (cliff measured from here)
        uint64 cliff; // seconds after start before ANY tokens vest
        uint64 duration; // total vesting seconds (must be >= cliff)
        bool revocable;
        bool revoked;
    }

    IERC20 public immutable token;

    mapping(address beneficiary => Schedule) public schedules;

    /// @notice Tokens held by this contract that are committed to schedules.
    uint256 public totalCommitted;

    event ScheduleCreated(
        address indexed beneficiary,
        uint256 total,
        uint64 start,
        uint64 cliff,
        uint64 duration,
        bool revocable
    );
    event Released(address indexed beneficiary, uint256 amount);
    event Revoked(address indexed beneficiary, uint256 refunded);

    error ScheduleExists();
    error NoSchedule();
    error NothingToRelease();
    error NotRevocable();
    error AlreadyRevoked();
    error InvalidParams();
    error InsufficientUncommittedBalance();

    constructor(IERC20 token_, address owner_) Ownable(owner_) {
        if (address(token_) == address(0)) revert InvalidParams();
        token = token_;
    }

    /**
     * @notice Create a vesting schedule. Tokens must ALREADY be held by this contract
     *         and uncommitted -- this prevents creating schedules the contract cannot honour.
     */
    function createSchedule(
        address beneficiary,
        uint128 total,
        uint64 start,
        uint64 cliffSeconds,
        uint64 durationSeconds,
        bool revocable
    ) external onlyOwner {
        if (beneficiary == address(0) || total == 0) revert InvalidParams();
        if (durationSeconds == 0 || cliffSeconds > durationSeconds) revert InvalidParams();
        if (schedules[beneficiary].total != 0) revert ScheduleExists();

        uint256 uncommitted = token.balanceOf(address(this)) - totalCommitted;
        if (uncommitted < total) revert InsufficientUncommittedBalance();

        schedules[beneficiary] = Schedule({
            total: total,
            released: 0,
            start: start,
            cliff: cliffSeconds,
            duration: durationSeconds,
            revocable: revocable,
            revoked: false
        });
        totalCommitted += total;

        emit ScheduleCreated(beneficiary, total, start, cliffSeconds, durationSeconds, revocable);
    }

    /// @notice Total vested (released + releasable) at the current timestamp.
    function vestedAmount(address beneficiary) public view returns (uint256) {
        Schedule memory s = schedules[beneficiary];
        if (s.total == 0) return 0;
        if (block.timestamp < uint256(s.start) + s.cliff) return 0;
        if (block.timestamp >= uint256(s.start) + s.duration) return s.total;
        return (uint256(s.total) * (block.timestamp - s.start)) / s.duration;
    }

    function releasable(address beneficiary) public view returns (uint256) {
        return vestedAmount(beneficiary) - schedules[beneficiary].released;
    }

    function release() external nonReentrant {
        Schedule storage s = schedules[msg.sender];
        if (s.total == 0) revert NoSchedule();

        uint256 amount = releasable(msg.sender);
        if (amount == 0) revert NothingToRelease();

        s.released += uint128(amount);
        totalCommitted -= amount;
        token.safeTransfer(msg.sender, amount);

        emit Released(msg.sender, amount);
    }

    /**
     * @notice Revoke a revocable schedule. Already-vested tokens remain claimable by the
     *         beneficiary; only the unvested remainder is returned to the treasury.
     */
    function revoke(address beneficiary, address refundTo) external onlyOwner nonReentrant {
        Schedule storage s = schedules[beneficiary];
        if (s.total == 0) revert NoSchedule();
        if (!s.revocable) revert NotRevocable();
        if (s.revoked) revert AlreadyRevoked();

        uint256 vested = vestedAmount(beneficiary);
        uint256 unvested = uint256(s.total) - vested;

        s.revoked = true;
        s.total = uint128(vested); // schedule now caps at what was already earned
        s.duration = 1;
        s.cliff = 0;
        s.start = uint64(block.timestamp) - 1; // fully vested going forward

        totalCommitted -= unvested;
        if (unvested > 0) token.safeTransfer(refundTo, unvested);

        emit Revoked(beneficiary, unvested);
    }

    /// @notice Recover tokens sent here in excess of what schedules require.
    function sweepUncommitted(address to) external onlyOwner {
        uint256 uncommitted = token.balanceOf(address(this)) - totalCommitted;
        if (uncommitted == 0) revert NothingToRelease();
        token.safeTransfer(to, uncommitted);
    }
}
