# CDLS Contract Package — v2.0

Companion code to **CDLS Clean Freight Platform — Business & Compliance Framework v2.0**.

## What changed

The v1.0 tokenomics model has been withdrawn. There is no CDLS token: no ERC-20, no
vesting, no rewards emissions, no governance token, no buybacks. Operators are paid in
US dollars as vendors under Environmental Attribute Purchase Agreements.

What remains on-chain is an audit trail — the part that was always the real product.

## Active contracts

### `TripAttestationRegistry.sol`
Records verified zero-emission haul events under an M-of-N attestor quorum.

- EIP-712 typed attestations; signatures must be sorted ascending by recovered signer
  (prevents duplicate-signer attacks in O(n) rather than O(n²))
- Each record commits to a hash of independent off-chain evidence — metered charging
  session data, dealer-countersigned delivery documents — not just operator telematics
- Mandatory dispute window before any record finalizes; auditors can void within it
- Per-operator rolling energy caps bound the exposure from a compromised attestor set
- **Attestation never mints anything.** It produces evidence, not value.

Primary quantity recorded is `energyWattHours`, not avoided CO2e. LCFS credits electricity
dispensed, not counterfactual diesel tonnage. This is the correction that matters most.

### `EnvironmentalAttributeRegistry.sol`
Serialized provenance and retirement ledger for LCFS credit batches.

- One external registry serial can be recorded once, ever — double-selling becomes
  structurally impossible rather than merely prohibited
- Each batch commits to a Merkle root over its constituent finalized trip attestations,
  so an accredited verifier can sample any haul and prove inclusion cryptographically
- `disclosureURI` is mandatory on every batch (AB 1305 hook)
- Transfers are custodian-restricted bookkeeping entries mirroring off-chain legal
  transfers. **Never make these permissionless** — a permissionless transfer of a
  value-bearing record pulls the whole architecture back into DFAL scope

## Retired — `_retired/`

Preserved only in case a properly-exempt security token is ever revisited. Do not deploy
as written.

| File | Why retired |
|---|---|
| `CDLSToken.sol` | Investment instrument; satisfied every Howey prong |
| `CDLSVesting.sol` | Only meaningful for a token cap table |
| `EpochRewardsDistributor.sol` | Token emissions replaced by USD accounts payable |

If that path is reconsidered, the token must be treated as a security from the outset:
registered transfer agent, on-chain transfer restrictions enforcing accredited-holder
status and Rule 144 holding periods (ERC-3643 / ERC-1404 style), and no utility fiction.

## Dependencies

OpenZeppelin Contracts v5.x. Solidity ^0.8.24.

```bash
forge install OpenZeppelin/openzeppelin-contracts
```

## Before mainnet

1. Independent security audit by a firm actually under engagement letter. Do not name
   audit firms in any external document before the engagement exists.
2. Full test suite including adversarial cases: duplicate signers, replayed attestations,
   cap-boundary conditions, void-after-finalize, serial collision.
3. Multisig on every privileged role. No EOA holds `DEFAULT_ADMIN_ROLE`.
4. Deploy alongside existing recordkeeping, not as a replacement for it, through at least
   one complete annual verification cycle.
