// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Burnable} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import {ERC20Pausable} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Pausable.sol";
import {ERC20Permit} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";
import {ERC20Votes} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Votes.sol";
import {AccessControlDefaultAdminRules} from
    "@openzeppelin/contracts/access/extensions/AccessControlDefaultAdminRules.sol";
import {Nonces} from "@openzeppelin/contracts/utils/Nonces.sol";

/**
 * @title CDLSToken
 * @notice Fixed-supply governance/utility token for the CDLS network.
 *
 * ============================ DEVIATIONS FROM WHITEPAPER v1.0 ============================
 *
 * 1. NO TRANSFER-FEE BURN. The whitepaper specifies "Burning Mechanism: Enabled
 *    (transaction fees)". A fee-on-transfer ERC-20 is NOT implemented here, deliberately:
 *      - Uniswap v2/v3, most aggregators, and nearly every major CEX either reject or
 *        mis-account fee-on-transfer tokens. Listing risk is severe.
 *      - The whitepaper also designates this token as the payment rail for dealers buying
 *        transport services. A transfer tax means every commercial invoice is
 *        systematically underpaid. These two design goals are mutually exclusive.
 *    Burning is instead exposed as an EXPLICIT action via ERC20Burnable, so the treasury
 *    can burn from revenue on a disclosed schedule.
 *
 * 2. NO MINT FUNCTION AT ALL. Entire supply is minted once in the constructor. This is
 *    the only credible way to honour "Minting Capability: None (fixed supply)". Note this
 *    is INCOMPATIBLE with the whitepaper's "Multi-chain (Ethereum L2 + Solana)" claim --
 *    a canonical fixed supply cannot exist natively on two chains. Use a lock-and-mint
 *    bridge with THIS contract as the canonical asset; the Solana side is a wrapped
 *    representation, not an independent supply. Say so in disclosure documents.
 *
 * 3. FREEZE CAPABILITY INCLUDED. Required in practice for OFAC/sanctions screening and
 *    for a California issuer subject to the Digital Financial Assets Law (Fin. Code
 *    § 3101 et seq., licensing live since 2026-07-01). This is a genuine centralization
 *    vector and directly contradicts the whitepaper's claim that "decentralized governance
 *    ensures no single party controls token value." Pick one and disclose it honestly.
 *
 * 4. ERC20Votes ADDED. The whitepaper promises on-chain 1-token-1-vote governance but the
 *    spec table has no checkpointing mechanism. Without it, governance is snapshot-free
 *    and trivially flash-loan attackable.
 *
 * ========================================================================================
 */
contract CDLSToken is
    ERC20,
    ERC20Burnable,
    ERC20Pausable,
    ERC20Permit,
    ERC20Votes,
    AccessControlDefaultAdminRules
{
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");
    bytes32 public constant COMPLIANCE_ROLE = keccak256("COMPLIANCE_ROLE");

    /// @notice Total fixed supply: 1,000,000,000 CDLS with 18 decimals.
    uint256 public constant TOTAL_SUPPLY = 1_000_000_000e18;

    /// @notice Addresses barred from sending or receiving (sanctions / court order).
    mapping(address account => bool) public frozen;

    event AccountFrozen(address indexed account, string reason);
    event AccountUnfrozen(address indexed account);

    error AccountIsFrozen(address account);
    error ZeroAddress();

    /**
     * @param initialAdmin      Should be a multisig, never an EOA. Holds DEFAULT_ADMIN_ROLE
     *                          subject to a mandatory transfer delay.
     * @param treasury          Receives the full initial supply for onward distribution
     *                          into vesting contracts and the rewards budget.
     * @param adminTransferDelay Seconds of delay on admin handover (suggest >= 3 days).
     */
    constructor(address initialAdmin, address treasury, uint48 adminTransferDelay)
        ERC20("California Dealer Logistics Solutions", "CDLS")
        ERC20Permit("California Dealer Logistics Solutions")
        AccessControlDefaultAdminRules(adminTransferDelay, initialAdmin)
    {
        if (treasury == address(0)) revert ZeroAddress();
        _mint(treasury, TOTAL_SUPPLY);
        // Intentionally no _grantRole for PAUSER/COMPLIANCE here. Admin grants them
        // explicitly post-deploy so the grant is a separate, auditable transaction.
    }

    // ------------------------------------------------------------------ compliance

    function freeze(address account, string calldata reason) external onlyRole(COMPLIANCE_ROLE) {
        if (account == address(0)) revert ZeroAddress();
        frozen[account] = true;
        emit AccountFrozen(account, reason);
    }

    function unfreeze(address account) external onlyRole(COMPLIANCE_ROLE) {
        frozen[account] = false;
        emit AccountUnfrozen(account);
    }

    function pause() external onlyRole(PAUSER_ROLE) {
        _pause();
    }

    function unpause() external onlyRole(PAUSER_ROLE) {
        _unpause();
    }

    // ------------------------------------------------------------------ overrides

    function _update(address from, address to, uint256 value)
        internal
        override(ERC20, ERC20Pausable, ERC20Votes)
    {
        if (frozen[from]) revert AccountIsFrozen(from);
        if (frozen[to]) revert AccountIsFrozen(to);
        super._update(from, to, value);
    }

    function nonces(address owner) public view override(ERC20Permit, Nonces) returns (uint256) {
        return super.nonces(owner);
    }

    /// @dev Timestamp-based checkpoints. Clearer for off-chain governance tooling than
    ///      block numbers, and necessary if this ever deploys to an L2 with variable
    ///      block times.
    function clock() public view override returns (uint48) {
        return uint48(block.timestamp);
    }

    // solhint-disable-next-line func-name-mixedcase
    function CLOCK_MODE() public pure override returns (string memory) {
        return "mode=timestamp";
    }
}
