// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {TripAttestationRegistry} from "../src/TripAttestationRegistry.sol";
import {IAccessControl} from "@openzeppelin/contracts/access/IAccessControl.sol";

contract TripAttestationRegistryTest is Test {
    TripAttestationRegistry reg;

    address admin = address(0xA11CE);
    address auditor = address(0xAD170);
    address governor = address(0x60F);
    address operator = address(0x0FE7A);
    address stranger = address(0x57A);

    // Attestor keypairs. Sorted by address in setUp so signature ordering is deterministic.
    uint256[5] pks;
    address[5] attestors;

    uint8 constant QUORUM = 2;
    uint64 constant DISPUTE_WINDOW = 1 days;
    uint64 constant ENERGY_CAP = 100_000; // Wh per period
    uint64 constant CAP_PERIOD = 1 days;

    bytes32 constant TRIP_TYPEHASH = keccak256(
        "Trip(bytes32 tripId,address operator,uint64 startTime,uint64 endTime,uint32 distanceMeters,uint64 energyWattHours,bytes32 evidenceHash)"
    );
    bytes32 constant DOMAIN_TYPEHASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");

    uint256 nonAttestorPk = 0xBAD;

    function setUp() public {
        vm.warp(1_000_000);

        uint256[5] memory raw = [uint256(0x1001), 0x1002, 0x1003, 0x1004, 0x1005];
        // insertion sort keys by derived address
        for (uint256 i = 0; i < 5; ++i) {
            uint256 k = raw[i];
            uint256 j = i;
            while (j > 0 && vm.addr(pks[j - 1]) > vm.addr(k)) {
                pks[j] = pks[j - 1];
                j--;
            }
            pks[j] = k;
        }
        for (uint256 i = 0; i < 5; ++i) {
            attestors[i] = vm.addr(pks[i]);
        }

        reg = new TripAttestationRegistry(admin, QUORUM, DISPUTE_WINDOW, ENERGY_CAP, CAP_PERIOD);

        vm.startPrank(admin);
        for (uint256 i = 0; i < 5; ++i) {
            reg.grantRole(reg.ATTESTOR_ROLE(), attestors[i]);
        }
        reg.grantRole(reg.AUDITOR_ROLE(), auditor);
        reg.grantRole(reg.GOVERNOR_ROLE(), governor);
        vm.stopPrank();
    }

    // ------------------------------------------------------------------ helpers

    struct Trip {
        bytes32 tripId;
        address operator;
        uint64 startTime;
        uint64 endTime;
        uint32 distanceMeters;
        uint64 energyWattHours;
        bytes32 evidenceHash;
    }

    function _trip(bytes32 id, uint64 wh) internal view returns (Trip memory) {
        return Trip({
            tripId: id,
            operator: operator,
            startTime: uint64(block.timestamp - 3600),
            endTime: uint64(block.timestamp - 60),
            distanceMeters: 41_800,
            energyWattHours: wh,
            evidenceHash: keccak256("charging-session+bol")
        });
    }

    function _digest(Trip memory t) internal view returns (bytes32) {
        bytes32 domainSeparator = keccak256(
            abi.encode(
                DOMAIN_TYPEHASH,
                keccak256(bytes("CDLSTripAttestation")),
                keccak256(bytes("1")),
                block.chainid,
                address(reg)
            )
        );
        bytes32 structHash = keccak256(
            abi.encode(
                TRIP_TYPEHASH,
                t.tripId,
                t.operator,
                t.startTime,
                t.endTime,
                t.distanceMeters,
                t.energyWattHours,
                t.evidenceHash
            )
        );
        return keccak256(abi.encodePacked("\x19\x01", domainSeparator, structHash));
    }

    function _sig(uint256 pk, bytes32 digest) internal pure returns (bytes memory) {
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(pk, digest);
        return abi.encodePacked(r, s, v);
    }

    /// @dev pks[] are already address-sorted, so signing in index order yields a valid array.
    function _sigsFrom(uint256[] memory keys, bytes32 digest) internal pure returns (bytes[] memory out) {
        out = new bytes[](keys.length);
        for (uint256 i = 0; i < keys.length; ++i) {
            out[i] = _sig(keys[i], digest);
        }
    }

    function _quorumSigs(Trip memory t) internal view returns (bytes[] memory) {
        uint256[] memory keys = new uint256[](2);
        keys[0] = pks[0];
        keys[1] = pks[1];
        return _sigsFrom(keys, _digest(t));
    }

    function _submit(Trip memory t, bytes[] memory sigs) internal {
        reg.submitTrip(
            t.tripId,
            t.operator,
            t.startTime,
            t.endTime,
            t.distanceMeters,
            t.energyWattHours,
            t.evidenceHash,
            sigs
        );
    }

    function _submitValid(bytes32 id, uint64 wh) internal returns (Trip memory t) {
        t = _trip(id, wh);
        _submit(t, _quorumSigs(t));
    }

    function _status(bytes32 id) internal view returns (TripAttestationRegistry.Status) {
        (,,,,,,, TripAttestationRegistry.Status s) = reg.trips(id);
        return s;
    }

    // ------------------------------------------------------------------ happy path

    function test_SubmitFinalize_HappyPath() public {
        _submitValid("trip-1", 50_000);
        assertEq(uint8(_status("trip-1")), uint8(TripAttestationRegistry.Status.Pending));

        vm.warp(block.timestamp + DISPUTE_WINDOW + 1);
        reg.finalizeTrip("trip-1");
        assertEq(uint8(_status("trip-1")), uint8(TripAttestationRegistry.Status.Finalized));
    }

    function test_FinalizeIsPermissionless() public {
        _submitValid("trip-1", 10_000);
        vm.warp(block.timestamp + DISPUTE_WINDOW + 1);
        vm.prank(stranger);
        reg.finalizeTrip("trip-1");
        assertEq(uint8(_status("trip-1")), uint8(TripAttestationRegistry.Status.Finalized));
    }

    function test_ExtraSignaturesBeyondQuorumAreAlsoValidated() public {
        Trip memory t = _trip("trip-1", 10_000);
        uint256[] memory keys = new uint256[](4);
        keys[0] = pks[0];
        keys[1] = pks[1];
        keys[2] = pks[2];
        keys[3] = pks[3];
        _submit(t, _sigsFrom(keys, _digest(t)));
        assertEq(uint8(_status("trip-1")), uint8(TripAttestationRegistry.Status.Pending));
    }

    // ------------------------------------------------------------------ signature attacks

    /// @dev A duplicated signer fails the strict-ascending check, which is the intended
    ///      O(n) defence against one attestor satisfying quorum alone.
    function test_RevertWhen_DuplicateSigner() public {
        Trip memory t = _trip("trip-1", 10_000);
        uint256[] memory keys = new uint256[](2);
        keys[0] = pks[0];
        keys[1] = pks[0];
        vm.expectRevert(TripAttestationRegistry.SignaturesNotSorted.selector);
        _submit(t, _sigsFrom(keys, _digest(t)));
    }

    function test_RevertWhen_SignaturesUnsorted() public {
        Trip memory t = _trip("trip-1", 10_000);
        uint256[] memory keys = new uint256[](2);
        keys[0] = pks[1]; // higher address first
        keys[1] = pks[0];
        vm.expectRevert(TripAttestationRegistry.SignaturesNotSorted.selector);
        _submit(t, _sigsFrom(keys, _digest(t)));
    }

    function test_RevertWhen_SignerNotAttestor() public {
        Trip memory t = _trip("trip-1", 10_000);
        bytes32 d = _digest(t);

        address rogue = vm.addr(nonAttestorPk);
        bytes[] memory sigs = new bytes[](2);
        if (rogue < attestors[0]) {
            sigs[0] = _sig(nonAttestorPk, d);
            sigs[1] = _sig(pks[0], d);
        } else {
            sigs[0] = _sig(pks[0], d);
            sigs[1] = _sig(nonAttestorPk, d);
        }
        vm.expectRevert(
            abi.encodeWithSelector(TripAttestationRegistry.NotAnAttestor.selector, rogue)
        );
        _submit(t, sigs);
    }

    function test_RevertWhen_BelowQuorum() public {
        Trip memory t = _trip("trip-1", 10_000);
        uint256[] memory keys = new uint256[](1);
        keys[0] = pks[0];
        vm.expectRevert(TripAttestationRegistry.QuorumNotMet.selector);
        _submit(t, _sigsFrom(keys, _digest(t)));
    }

    /// @dev Signatures are bound to the exact payload. Inflating energy after signing
    ///      recovers a different address, which is not an attestor.
    function test_RevertWhen_PayloadTamperedAfterSigning() public {
        Trip memory signed = _trip("trip-1", 10_000);
        bytes[] memory sigs = _quorumSigs(signed);

        Trip memory tampered = signed;
        tampered.energyWattHours = 90_000; // operator inflates the meter reading

        vm.expectRevert(); // recovered signer is arbitrary; NotAnAttestor with unknown arg
        _submit(tampered, sigs);
    }

    /// @dev Signatures for contract A must not be replayable against contract B.
    function test_RevertWhen_ReplayedAcrossContractInstances() public {
        Trip memory t = _trip("trip-1", 10_000);
        bytes[] memory sigs = _quorumSigs(t);

        TripAttestationRegistry other =
            new TripAttestationRegistry(admin, QUORUM, DISPUTE_WINDOW, ENERGY_CAP, CAP_PERIOD);
        vm.startPrank(admin);
        for (uint256 i = 0; i < 5; ++i) {
            other.grantRole(other.ATTESTOR_ROLE(), attestors[i]);
        }
        vm.stopPrank();

        vm.expectRevert(); // domain separator differs -> different recovered signers
        other.submitTrip(
            t.tripId, t.operator, t.startTime, t.endTime, t.distanceMeters, t.energyWattHours, t.evidenceHash, sigs
        );
    }

    // ------------------------------------------------------------------ replay / state

    function test_RevertWhen_DuplicateTripId() public {
        _submitValid("trip-1", 10_000);
        Trip memory t = _trip("trip-1", 10_000);
        vm.expectRevert(TripAttestationRegistry.TripAlreadyExists.selector);
        _submit(t, _quorumSigs(t));
    }

    function test_RevertWhen_EndBeforeStart() public {
        Trip memory t = _trip("trip-1", 10_000);
        t.endTime = t.startTime - 1;
        vm.expectRevert(TripAttestationRegistry.InvalidTimeRange.selector);
        _submit(t, _quorumSigs(t));
    }

    function test_RevertWhen_EndInFuture() public {
        Trip memory t = _trip("trip-1", 10_000);
        t.endTime = uint64(block.timestamp + 1);
        vm.expectRevert(TripAttestationRegistry.InvalidTimeRange.selector);
        _submit(t, _quorumSigs(t));
    }

    function test_RevertWhen_FinalizeBeforeWindow() public {
        _submitValid("trip-1", 10_000);
        vm.warp(block.timestamp + DISPUTE_WINDOW - 1);
        vm.expectRevert(TripAttestationRegistry.DisputeWindowOpen.selector);
        reg.finalizeTrip("trip-1");
    }

    function test_RevertWhen_FinalizeTwice() public {
        _submitValid("trip-1", 10_000);
        vm.warp(block.timestamp + DISPUTE_WINDOW + 1);
        reg.finalizeTrip("trip-1");
        vm.expectRevert(TripAttestationRegistry.TripNotPending.selector);
        reg.finalizeTrip("trip-1");
    }

    function test_RevertWhen_VoidAfterFinalize() public {
        _submitValid("trip-1", 10_000);
        vm.warp(block.timestamp + DISPUTE_WINDOW + 1);
        reg.finalizeTrip("trip-1");
        vm.prank(auditor);
        vm.expectRevert(TripAttestationRegistry.TripNotPending.selector);
        reg.voidTrip("trip-1", "late dispute");
    }

    function test_RevertWhen_FinalizeUnknownTrip() public {
        vm.expectRevert(TripAttestationRegistry.TripNotPending.selector);
        reg.finalizeTrip("never-existed");
    }

    // ------------------------------------------------------------------ energy caps

    function test_RevertWhen_OperatorCapExceeded() public {
        _submitValid("trip-1", 60_000);
        Trip memory t = _trip("trip-2", 50_000); // 110_000 > 100_000 cap
        vm.expectRevert(TripAttestationRegistry.OperatorCapExceeded.selector);
        _submit(t, _quorumSigs(t));
    }

    function test_CapIsPerOperatorNotGlobal() public {
        _submitValid("trip-1", 90_000);

        Trip memory t = _trip("trip-2", 90_000);
        t.operator = address(0xBEEF); // different operator, own budget
        _submit(t, _quorumSigs(t));
        assertEq(uint8(_status("trip-2")), uint8(TripAttestationRegistry.Status.Pending));
    }

    function test_CapResetsNextPeriod() public {
        _submitValid("trip-1", 90_000);
        vm.warp(block.timestamp + CAP_PERIOD);
        Trip memory t = _trip("trip-2", 90_000);
        _submit(t, _quorumSigs(t));
        assertEq(uint8(_status("trip-2")), uint8(TripAttestationRegistry.Status.Pending));
    }

    function test_Void_ReleasesEnergyCapacity() public {
        _submitValid("trip-1", 90_000);

        vm.prank(auditor);
        reg.voidTrip("trip-1", "spoofed gps");
        assertEq(uint8(_status("trip-1")), uint8(TripAttestationRegistry.Status.Voided));

        // capacity returned: a second 90k trip now fits
        Trip memory t = _trip("trip-2", 90_000);
        _submit(t, _quorumSigs(t));
        assertEq(uint8(_status("trip-2")), uint8(TripAttestationRegistry.Status.Pending));
    }

    function test_RevertWhen_VoidTwice() public {
        _submitValid("trip-1", 10_000);
        vm.startPrank(auditor);
        reg.voidTrip("trip-1", "first");
        vm.expectRevert(TripAttestationRegistry.TripNotPending.selector);
        reg.voidTrip("trip-1", "second");
        vm.stopPrank();
    }

    /// @dev Invariant: accrued energy for an operator can never exceed the cap.
    function testFuzz_EnergyCapNeverExceeded(uint64 a, uint64 b) public {
        a = uint64(bound(a, 1, ENERGY_CAP));
        b = uint64(bound(b, 1, ENERGY_CAP));

        _submitValid("trip-1", a);

        Trip memory t = _trip("trip-2", b);
        if (uint256(a) + b > ENERGY_CAP) {
            vm.expectRevert(TripAttestationRegistry.OperatorCapExceeded.selector);
            _submit(t, _quorumSigs(t));
        } else {
            _submit(t, _quorumSigs(t));
        }
        assertLe(reg.periodEnergy(operator, block.timestamp / CAP_PERIOD), ENERGY_CAP);
    }

    // ------------------------------------------------------------------ access control

    function test_RevertWhen_NonAuditorVoids() public {
        _submitValid("trip-1", 10_000);
        bytes32 role = reg.AUDITOR_ROLE();
        vm.expectRevert(
            abi.encodeWithSelector(
                IAccessControl.AccessControlUnauthorizedAccount.selector, stranger, role
            )
        );
        vm.prank(stranger);
        reg.voidTrip("trip-1", "not allowed");
    }

    function test_RevertWhen_NonGovernorSetsParams() public {
        bytes32 role = reg.GOVERNOR_ROLE();
        vm.expectRevert(
            abi.encodeWithSelector(
                IAccessControl.AccessControlUnauthorizedAccount.selector, stranger, role
            )
        );
        vm.prank(stranger);
        reg.setParams(1, 0, type(uint64).max);
    }

    /// @dev A governor lowering quorum to 1 collapses the multi-party guarantee. Permitted
    ///      by design, but it makes GOVERNOR_ROLE a critical key: multisig + timelock only.
    function test_GovernorCanWeakenQuorum_KeyRiskDocumented() public {
        vm.prank(governor);
        reg.setParams(1, 0, ENERGY_CAP);
        assertEq(reg.quorum(), 1);

        Trip memory t = _trip("trip-1", 10_000);
        uint256[] memory keys = new uint256[](1);
        keys[0] = pks[0];
        _submit(t, _sigsFrom(keys, _digest(t)));

        reg.finalizeTrip("trip-1"); // disputeWindow now 0 -> instant finality
        assertEq(uint8(_status("trip-1")), uint8(TripAttestationRegistry.Status.Finalized));
    }

    function test_RevertWhen_ConstructorQuorumZero() public {
        vm.expectRevert(TripAttestationRegistry.InvalidParams.selector);
        new TripAttestationRegistry(admin, 0, DISPUTE_WINDOW, ENERGY_CAP, CAP_PERIOD);
    }

    function test_RevertWhen_ConstructorCapPeriodZero() public {
        vm.expectRevert(TripAttestationRegistry.InvalidParams.selector);
        new TripAttestationRegistry(admin, QUORUM, DISPUTE_WINDOW, ENERGY_CAP, 0);
    }
}
