// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

/**
 * @title EnvironmentalAttributeRegistry
 * @notice Serialized provenance and retirement ledger for LCFS credit batches.
 *
 * =============================== WHAT REPLACED THE TOKEN ================================
 *
 * v1.0 of this project proposed a 1,000,000,000-supply ERC-20 sold at $0.10 with a
 * projected IRR, revenue-funded buybacks, and a claim of "fractional ownership in verified
 * carbon credits." That instrument has been removed entirely. It satisfied every prong of
 * Howey, it distributed 350M units to unaccredited US persons with no exemption, and it
 * required a California DFAL license the company did not hold.
 *
 * What survives is the part that was always the real product: a tamper-evident audit trail.
 *
 * This registry issues NO transferable, fungible, or appreciating instrument. Records here
 * are administrative entries describing credits that exist in CARB's LRT-CBTS system. They
 * are not securities, not payment instruments, and not digital financial assets held for
 * anyone. Ownership transfers recorded here MIRROR off-chain legal transfers; they do not
 * effect them.
 *
 * ================================== WHY A LEDGER AT ALL =================================
 *
 * Blockchain earns its place here for exactly three reasons, all of them audit-driven:
 *
 *   1. DOUBLE-COUNTING PREVENTION. Each batch is keyed to its external registry serial.
 *      A serial can be recorded once, ever. Selling the same attribute twice becomes
 *      structurally impossible rather than merely prohibited.
 *
 *   2. VERIFIER-READY EVIDENCE CHAIN. Third-party verification of LCFS electricity
 *      pathways became mandatory in 2026. Each batch commits to a Merkle root over its
 *      constituent finalized trip attestations, so a verifier can sample any individual
 *      haul and prove inclusion. This is the cost-reduction that makes the platform
 *      worth paying for.
 *
 *   3. RETIREMENT FINALITY. Retirement is terminal and publicly emitted, producing a
 *      citable certificate for the buyer's own disclosure obligations.
 *
 * ================================ AB 1305 DISCLOSURE HOOK ===============================
 *
 * California's Voluntary Carbon Market Disclosures Act (Health & Safety Code § 44475 et
 * seq.) imposes website disclosure duties with NO revenue threshold, enforceable by the
 * Attorney General, any district attorney, county counsel, or city attorney, at up to
 * $2,500 per day and $500,000 per violation.
 *
 * LCFS credits are compliance instruments, not voluntary carbon offsets, and should never
 * be marketed as offsets. But any accompanying claim of avoided or reduced emissions can
 * pull the company into scope. `disclosureURI` is therefore MANDATORY on every batch and
 * must resolve to the live disclosure page covering that batch. Marketing discipline is a
 * legal control here, not a style preference.
 *
 * ========================================================================================
 */
contract EnvironmentalAttributeRegistry is AccessControl {
    bytes32 public constant ISSUER_ROLE = keccak256("ISSUER_ROLE");
    bytes32 public constant CUSTODIAN_ROLE = keccak256("CUSTODIAN_ROLE");
    bytes32 public constant VERIFIER_ROLE = keccak256("VERIFIER_ROLE");

    enum Status {
        None,
        Issued, // recorded, pending third-party verification
        Verified, // verification statement received
        Transferred, // legal title moved to a counterparty (repeatable)
        Retired, // terminal
        Rejected // terminal: verifier refused the batch, credits backed out of totals
    }

    struct Batch {
        bytes32 externalSerial; // LRT-CBTS / registry serial. Unique, forever.
        uint64 vintageQuarter; // YYYYQ, e.g. 20264
        uint64 creditsMilli; // credits x 1000 (1 credit = 1 tCO2e)
        uint64 energyMegajoules; // metered energy underpinning the batch
        uint32 transferCount; // completed custody hops; packs into the same slot
        bytes32 tripSetRoot; // Merkle root over finalized trip attestation IDs
        bytes32 verificationHash; // hash of the verifier's signed statement
        address holder; // current record holder
        Status status;
    }

    /// @dev Guarantees an external registry serial is recorded at most once.
    mapping(bytes32 externalSerial => bool) public serialUsed;

    mapping(uint256 batchId => Batch) public batches;
    mapping(uint256 batchId => string) public disclosureURI;

    uint256 public nextBatchId = 1;

    /// @notice Running totals for public reporting. Cheap to read, hard to misstate.
    uint64 public totalCreditsIssuedMilli;
    uint64 public totalCreditsRetiredMilli;

    event BatchIssued(
        uint256 indexed batchId,
        bytes32 indexed externalSerial,
        uint64 creditsMilli,
        bytes32 tripSetRoot,
        string disclosureURI
    );
    event BatchVerified(uint256 indexed batchId, address indexed verifier, bytes32 verificationHash);
    event BatchRejected(
        uint256 indexed batchId, address indexed verifier, uint64 creditsMilli, string reason
    );
    event BatchTransferred(
        uint256 indexed batchId, address indexed from, address indexed to, uint32 hop
    );
    event BatchRetired(
        uint256 indexed batchId,
        address indexed beneficiary,
        uint64 creditsMilli,
        string reason
    );
    event DisclosureUpdated(uint256 indexed batchId, string disclosureURI);

    error SerialAlreadyRecorded();
    error UnknownBatch();
    error WrongStatus();
    error NotHolder();
    error MissingDisclosure();
    error InvalidParams();
    error TooManyTransfers();

    constructor(address admin) {
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
    }

    /**
     * @notice Record a newly generated batch. Does not create value; it describes a credit
     *         that exists in the external registry.
     */
    function issueBatch(
        bytes32 externalSerial,
        uint64 vintageQuarter,
        uint64 creditsMilli,
        uint64 energyMegajoules,
        bytes32 tripSetRoot,
        address holder,
        string calldata disclosureURI_
    ) external onlyRole(ISSUER_ROLE) returns (uint256 batchId) {
        if (serialUsed[externalSerial]) revert SerialAlreadyRecorded();
        if (creditsMilli == 0 || holder == address(0)) revert InvalidParams();
        if (tripSetRoot == bytes32(0)) revert InvalidParams();
        if (bytes(disclosureURI_).length == 0) revert MissingDisclosure();

        serialUsed[externalSerial] = true;
        batchId = nextBatchId++;

        batches[batchId] = Batch({
            externalSerial: externalSerial,
            vintageQuarter: vintageQuarter,
            creditsMilli: creditsMilli,
            energyMegajoules: energyMegajoules,
            transferCount: 0,
            tripSetRoot: tripSetRoot,
            verificationHash: bytes32(0),
            holder: holder,
            status: Status.Issued
        });
        disclosureURI[batchId] = disclosureURI_;
        totalCreditsIssuedMilli += creditsMilli;

        emit BatchIssued(batchId, externalSerial, creditsMilli, tripSetRoot, disclosureURI_);
    }

    /// @notice Attach the accredited verifier's signed statement. Required before sale.
    function recordVerification(uint256 batchId, bytes32 verificationHash)
        external
        onlyRole(VERIFIER_ROLE)
    {
        Batch storage b = batches[batchId];
        if (b.status == Status.None) revert UnknownBatch();
        if (b.status != Status.Issued) revert WrongStatus();
        if (verificationHash == bytes32(0)) revert InvalidParams();

        b.verificationHash = verificationHash;
        b.status = Status.Verified;

        emit BatchVerified(batchId, msg.sender, verificationHash);
    }

    /**
     * @notice Back an erroneous or refused batch out of the ledger.
     * @dev Restricted to VERIFIER_ROLE, deliberately. Letting the issuer unilaterally erase
     *      its own entries would gut the audit trail; requiring the independent verifier to
     *      sign off on a correction is the control that makes public totals trustworthy.
     *
     *      Only reachable from Issued. Once a verification statement exists the batch is
     *      part of the record and must be handled by retirement, not deletion.
     *
     *      THE SERIAL IS NOT RELEASED. `serialUsed` stays true forever. Freeing it would
     *      open an issue-reject-reissue loop that defeats the double-count guarantee, which
     *      is the single most important property this contract has. A mistyped serial costs
     *      you nothing — the serial you meant to record is still available. A correctly
     *      typed serial on a bad batch is one you actively want burned.
     */
    function rejectBatch(uint256 batchId, string calldata reason) external onlyRole(VERIFIER_ROLE) {
        Batch storage b = batches[batchId];
        if (b.status == Status.None) revert UnknownBatch();
        if (b.status != Status.Issued) revert WrongStatus();

        b.status = Status.Rejected;
        totalCreditsIssuedMilli -= b.creditsMilli;

        emit BatchRejected(batchId, msg.sender, b.creditsMilli, reason);
    }

    /**
     * @notice Mirror an off-chain legal transfer of the batch. Repeatable.
     * @dev Accepts Verified (first sale) or Transferred (downstream on-sale), because real
     *      credit chains are multi-hop: CDLS to broker to end buyer. Each hop increments
     *      `transferCount` and emits with the hop index, so the full custody chain is
     *      reconstructible from events.
     *
     *      Deliberately restricted to the custodian role. This is a bookkeeping entry, not
     *      a bearer transfer, and must never be made permissionless — permissionless
     *      transfer of a value-bearing record is precisely what would drag this contract
     *      into DFAL scope.
     */
    function recordTransfer(uint256 batchId, address to)
        external
        onlyRole(CUSTODIAN_ROLE)
    {
        Batch storage b = batches[batchId];
        if (b.status == Status.None) revert UnknownBatch();
        if (b.status != Status.Verified && b.status != Status.Transferred) revert WrongStatus();
        if (to == address(0)) revert InvalidParams();
        if (to == b.holder) revert InvalidParams();

        address from = b.holder;
        b.holder = to;
        b.status = Status.Transferred;
        b.transferCount += 1;

        emit BatchTransferred(batchId, from, to, b.transferCount);
    }

    /// @notice Terminal. Emits the public retirement record the buyer cites in disclosures.
    function retireBatch(uint256 batchId, address beneficiary, string calldata reason)
        external
        onlyRole(CUSTODIAN_ROLE)
    {
        Batch storage b = batches[batchId];
        if (b.status == Status.None) revert UnknownBatch();
        if (b.status != Status.Verified && b.status != Status.Transferred) revert WrongStatus();

        b.status = Status.Retired;
        totalCreditsRetiredMilli += b.creditsMilli;

        emit BatchRetired(batchId, beneficiary, b.creditsMilli, reason);
    }

    /// @notice Disclosure pages must stay current; AB 1305 requires annual updates.
    function updateDisclosure(uint256 batchId, string calldata disclosureURI_)
        external
        onlyRole(ISSUER_ROLE)
    {
        if (batches[batchId].status == Status.None) revert UnknownBatch();
        if (bytes(disclosureURI_).length == 0) revert MissingDisclosure();
        disclosureURI[batchId] = disclosureURI_;
        emit DisclosureUpdated(batchId, disclosureURI_);
    }
}
