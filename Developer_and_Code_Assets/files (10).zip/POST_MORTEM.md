# CDLS Tokenomics — Pre-Mortem, Fact Check & Risk Register

**Reviewing:** CDLS Carbon Credit Tokenomics Whitepaper v1.0, January 2026
**Review date:** 6 August 2026
**Method:** Assume the project launched and failed by 2029. Work backwards to the cause.

> This is an engineering and factual review, not legal or investment advice. Several
> findings below concern securities and money-transmission law; those require licensed
> counsel before any action is taken.

---

## 0. Bottom line up front

Three load-bearing assumptions in the whitepaper are factually wrong as of today. One of
them is not fixable by adjusting parameters — it invalidates the core product.

| # | Whitepaper claim | Reality (Aug 2026) | Severity |
|---|---|---|---|
| 1 | ZEV hauling generates saleable CARB carbon credits | No such protocol exists; transport fuel is *inside* the cap | **Fatal as written** |
| 2 | Carbon credits worth $85–$200/t; "$200+ spot" | CCAs settled **$28.81** in May 2026; program price *ceiling* is $102.52 | **Critical** |
| 3 | Advanced Clean Fleets creates $8.5B mandated demand | ACF private/drayage requirements **repealed**, effective 1 Jan 2027 | **Critical** |

The good news: there *is* a real revenue mechanism for ZEV freight in California. It is the
**Low Carbon Fuel Standard (LCFS)**, not the compliance offset program. It is worth roughly
**$4–5 per haul**, not the ~$7.65 implied by the whitepaper, and — critically — it accrues to
whoever owns the charging equipment, not to the hauler. That is a real business. It is not a
$100M fully-diluted token.

---

## 1. Finding 1 — The credit does not exist (fatal)

The whitepaper's central mechanism is: ZEV haul avoids diesel emissions → generates a
carbon credit → credit is sold → proceeds back the token.

Two independent reasons this fails under CARB's compliance offset program:

**(a) There is no protocol.** CARB issues offset credits under exactly six Board-approved
Compliance Offset Protocols: U.S. Forest Projects, Urban Forest, Livestock, Ozone Depleting
Substances, Mine Methane Capture, and Rice Cultivation. There is no transportation
electrification protocol, and none is in the announced development pipeline. A project
without an approved protocol cannot be listed with a registry and cannot receive ARB Offset
Credits. Meeting ISO 14064-2 (which the whitepaper cites) gets you nothing on its own —
it is a quantification standard, not a crediting program.

**(b) Even with a protocol, the sector is capped.** Offset projects must reduce emissions
from **uncapped sources**. On-road transportation fuel has been covered by California
cap-and-trade at the fuel-supplier level since 2015. When a haul switches from diesel to
electric, the fuel supplier already surrenders fewer allowances. Issuing an offset credit
for the same tonne would be double-counting the identical reduction. This is a structural
bar, not a paperwork problem.

The whitepaper's supporting citations are also wrong:

- **"EPA SmartWay protocols"** — SmartWay is a voluntary freight-efficiency benchmarking
  program. It has never been a GHG credit quantification methodology.
- **"Title 17, Section 95970"** — sits in the compliance offset article, i.e. the article
  that (per above) contains no applicable protocol.
- **"15% discount factors for upstream electricity generation"** — an invented adjustment.
  LCFS handles grid carbon intensity directly and explicitly; ad-hoc haircuts are not how
  any registry works.

### What actually works: LCFS

California's LCFS credits low-carbon transportation fuel, including electricity dispensed to
EVs, and explicitly contemplates drayage and medium/heavy-duty electrification. It is a
genuine, live revenue stream. But it is a **completely different instrument** with different
mechanics:

| | Whitepaper model | LCFS reality |
|---|---|---|
| Creditable unit | Avoided diesel tCO2e | **MJ of electricity dispensed** |
| Measurement | GPS trip + counterfactual | Metered energy at registered charging equipment |
| Who earns it | The hauler | The **Fuel Supply Equipment owner**, unless contractually assigned |
| Adjustment | 15% ad-hoc haircut | Energy Economy Ratio (5.0 for heavy-duty BEV) vs declining CI benchmark |
| Verification | "Quarterly third-party audit" | **Mandatory third-party verification for electricity pathways from 2026** |

The "who earns it" row is the commercially dangerous one. If CDLS does not own the chargers,
it has no claim on the credits at all without explicit assignment agreements from every
charging host. The whitepaper contains no such mechanism.

---

## 2. Finding 2 — Price assumption is ~6× too high

The whitepaper uses $170/t as a "conservative" figure and asserts "current $200+ spot prices."

Actual California carbon market, 2026:

| Reference point | 2026 value |
|---|---|
| Auction settlement, May 2026 | **$28.81** |
| Auction reserve (floor) | $27.94 |
| APCR Tier 1 / Tier 2 triggers | $65.31 / $83.92 |
| **Price ceiling** | **$102.52** |

$200/t is not merely high — it is above the program's structural ceiling and therefore
cannot occur. CARB's own Initial Statement of Reasons assumed a weighted average near $68
and the market has come in well below even that.

**Effect on the model:** every revenue figure in Section III is overstated by roughly 5.9×
on price alone. Year 1 credit revenue of $425K becomes ~$72K at real CCA prices — and $0
given Finding 1.

---

## 3. Finding 3 — The demand mandate was repealed

The investment thesis rests on ACF: *"This regulatory certainty eliminates adoption risk."*

Timeline:
- **Jan 2025** — CARB withdrew its Clean Air Act waiver request to EPA for ACF.
- **2025** — Legal settlement with a 17-state coalition led by Nebraska plus trucking
  industry groups; CARB agreed to repeal the High-Priority Fleet and Drayage requirements.
- **Sept 2025** — CARB voted to repeal. Repeal effective **1 January 2027**.
- CARB also agreed not to enforce the 2036 100% ZEV sales mandate absent a federal waiver.

The regulation that was supposed to force independent haulers into ZEVs does not apply to
them. State and local government fleets remain covered; Advanced Clean Trucks still applies
to *manufacturers*, so ZEV trucks will increasingly be what is available for sale. That is a
real but much slower and much weaker tailwind than "regulatory certainty eliminates
adoption risk."

A whitepaper dated January 2026 asserting ACF-driven mandated demand was already twelve
months stale on the day it was written. In a dispute, that is the first exhibit.

---

## 4. Corrected unit economics

Working from the whitepaper's own implied trip profile (45 kg CO2e avoided ≈ 4.4 gal diesel
at Class 8 economy ≈ a **26-mile haul**):

**Assumptions (swap these for your real figures):** BEV Class 8 at 2.0 kWh/mile → 52 kWh
(187 MJ) per haul; 2026 diesel-substitute CI benchmark ≈ 85 gCO2e/MJ; EER 5.0; CA grid CI
≈ 80 gCO2e/MJ; LCFS credit ≈ $70.

```
Credit per haul = (85 × 5.0 − 80) g/MJ × 187 MJ = 64,515 gCO2e = 0.0645 t
Value per haul  = 0.0645 × $70                  = $4.52
```

| Scenario | Value per haul |
|---|---|
| Whitepaper (45 kg @ $170/t) | $7.65 |
| Same method @ real CCA price ($28.81) | $1.30 |
| Same method, offsets unavailable | **$0.00** |
| **Corrected LCFS pathway** | **~$4.52** |

Then subtract: aggregator fees (5–20% is typical), mandatory third-party verification
(a fixed annual cost that is brutal at low volume), and the charging-host revenue share
required to obtain credit assignment. Realistic net to CDLS is plausibly **$2–3 per haul**.

**Year 1 rebuild** (50 operators × ~1,111 hauls each = 55,556 hauls):

| Line | Whitepaper | Corrected |
|---|---|---|
| Credit revenue | $425,000 | ~$251,000 gross / ~$140,000 net |
| Platform fees | $180,000 | unchanged (unverified) |
| **Total** | **$605,000** | **~$320,000** |

At a $100M fully diluted valuation (1B × $0.10), that is **~310× revenue in Year 1**.

---

## 5. Finding 4 — The "backing" claim is off by two orders of magnitude

> *"Each CDLS token represents fractional ownership in verified carbon credits."*

The Carbon Credit Reserve is 250,000,000 tokens = **$25M implied value** at the $0.10 price.
The whitepaper retains 25% of generated credits in treasury.

| Point in time | Credits in reserve | Value @ $70 | Backing ratio |
|---|---|---|---|
| Launch | 0 t | $0 | **0%** |
| End Year 1 | ~897 t | ~$63K | **0.25%** |
| End Year 5 (full plan execution) | ~75,000 t | ~$5.3M | **~21%** |

An asset-backing claim that is 0.25% honoured at launch and never exceeds ~21% even on the
plan's own optimistic ramp is the kind of statement that gets quoted back at you. Either
attach a real, audited, on-chain-verifiable reserve with a published attestation schedule,
or drop the backing language entirely. There is no safe middle.

Note also that "fractional ownership in a pool of appreciating assets managed by the issuer"
is close to a textbook description of a security. See §6.

---

## 6. Securities & licensing exposure

**Not legal advice.** This is the analysis a regulator or opposing counsel would run first.

### Howey walkthrough

| Prong | Assessment |
|---|---|
| Investment of money | Yes — Reg D placement at $0.10 |
| Common enterprise | Yes — pooled treasury, shared credit reserve, pro-rata distributions |
| Expectation of profit | Yes — the document's **first table** is a projected IRR |
| From efforts of others | Yes — CDLS runs the platform, sells credits, executes buybacks, manages treasury |

The whitepaper's own stated mitigations are self-refuting:

- *"Marketing materials emphasize platform functionality over investment returns."* This
  document is subtitled **"Institutional-Grade Digital Asset Framework,"** opens with a
  projected IRR of 18–24%, and closes with a section titled "Investment Thesis."
- *"Decentralized governance ensures no single party controls token value."* Founder (10%) +
  Treasury (10%) + Institutional (20%) = **40% of supply**, under 1-token-1-vote. The issuer
  also controls credit sales, buyback timing, and reserve deployment.
- *"Geographic restrictions prevent sales to US retail investors."* **The 35% Operator
  Rewards allocation is a distribution of tokens to US retail persons.** Reg D covers the
  institutional tranche only. If the token is a security, 350,000,000 tokens are being
  distributed to unaccredited US persons with no identified exemption. This is the single
  largest unaddressed exposure in the document.

### Unsupported projections

The 18–24% IRR appears six times and is never derived. An IRR requires an exit price and a
holding period; neither is stated anywhere. Distributing quantified return projections with
no supporting model, to investors, is an independent liability vector regardless of how the
token is ultimately classified.

### California DFAL — a deadline that has already passed

California's Digital Financial Assets Law (Fin. Code § 3101 et seq.) covers **issuing and
administering** digital financial assets for California residents. DFPI licensing went live
**1 July 2026**. Covered entities needed a license or a complete application on file by that
date to keep serving California residents. Published DFPI expectations include ~$100,000
tangible net worth and a **$500,000 surety bond**, plus custody, disclosure, capital and
liquidity requirements.

A Sacramento-headquartered issuer, minting a token, paying California haulers in it, and
accepting it from California dealers is squarely in scope. **The whitepaper does not mention
DFAL at all.** As of today the deadline is five weeks past. This needs counsel this week,
not this quarter.

Separately: FinCEN MSB registration and state money-transmitter analysis likely apply. The
AML section references *"Currency Transaction Reports"* — CTRs are triggered by physical
currency over $10,000. For a crypto platform the relevant obligations are MSB registration,
SARs, and the Travel Rule. The wording suggests that section was not drafted by a BSA
specialist.

---

## 7. Technical contradictions in the spec

| Spec line | Problem |
|---|---|
| "Minting Capability: None (fixed supply)" **and** "Multi-chain (Ethereum L2 + Solana)" | Mutually exclusive. A canonical fixed supply cannot exist natively on two chains. You need a lock-and-mint bridge with one canonical side and one wrapped side. Say which. |
| "Burning Mechanism: Enabled (transaction fees)" **and** token is the dealer payment rail | A fee-on-transfer ERC-20 means every commercial invoice is systematically underpaid, and is rejected or mis-accounted by most DEXes and CEXes. |
| "Governance: 1 token = 1 vote" | No checkpointing mechanism specified. Without ERC20Votes-style snapshots, governance is flash-loan attackable on day one. |
| "Smart Contract Audit: CertiK / Trail of Bits" | Listed in a *specifications* table as though engaged. If no engagement letter exists, this is a misrepresentation in an investor document. Move it to a roadmap and name only firms actually retained. |
| "60% of secondary market proceeds to token buybacks" | Revenue-funded buybacks materially strengthen Howey prongs 3 and 4, and create a market-support obligation that becomes an unfunded liability precisely when revenue disappoints. |
| "Forward sale contracts locking in floor prices for 70% of projected credits" | You cannot forward-sell an instrument you have no protocol to generate. No counterparty writes floors on unverified future credits from a pre-revenue issuer. |

---

## 8. The fraud vector the whitepaper spends one sentence on

The system **pays operators tokens per verified trip**. That is a direct, unbounded financial
incentive to fabricate trips.

GPS and telematics are software-reported and therefore spoofable — commodity GPS simulators
defeat naive telematics ingestion. The whitepaper's entire answer is *"redundant data
verification across multiple oracle sources."*

Two loss channels, and the second is far worse:

1. **Token loss** — fabricated trips drain the reward pool. Bounded, recoverable, embarrassing.
2. **Fraudulent environmental claims** — if fabricated data flows into credits sold to
   corporate buyers, CDLS has sold environmental attributes that do not exist. That is
   potential wire fraud and CARB enforcement exposure, and it is not recoverable by
   refunding anyone.

`TripAttestationRegistry.sol` in this package addresses this with an M-of-N attestor quorum,
required off-chain evidence hashes from independent parties, a mandatory dispute window
before anything settles, and per-operator rolling energy caps to bound the blast radius of a
compromised attestor set. **Attestation never mints.** Payment is a separate, pre-funded,
post-verification process.

---

## 9. Post-mortem: ranked failure modes

Assume it is 2029 and CDLS failed. Most likely causes, ordered by probability × severity.

**1. Regulatory enforcement before product-market fit (highest).**
Operating without a DFAL license past July 2026, distributing 350M tokens to unaccredited US
persons, and marketing an unsupported IRR. Any one of these draws a DFPI or SEC action. The
IRR-led marketing makes the file look bad before anyone examines the technology. *Kill
condition: cease-and-desist during the Phase 1 raise.*

**2. Credit revenue never materialises.**
The offset protocol doesn't exist and never gets written. LCFS assignment agreements with
charging hosts prove harder than expected. Verification costs eat the margin at low volume.
Revenue arrives at ~30% of plan and the buyback commitment cannot be met. *Kill condition:
Month 18, treasury depleted, token below issue price, operators stop accepting it.*

**3. Operator churn once the mandate is gone.**
With ACF repealed, haulers face no compliance requirement. The value proposition reduces to
"$2–3 per haul in credit revenue, paid in a volatile token." A diesel operator with a paid-off
truck has no reason to switch. Adoption stalls at 30–60 operators. *Kill condition: Phase 2
never starts.*

**4. Attestation fraud.**
A small ring of operators discovers GPS spoofing. Either the reward pool drains, or —
much worse — fabricated tonnes reach a credit buyer. *Kill condition: buyer's auditor finds it.*

**5. Token payment rail rejection.**
Dealers refuse to hold or transact in a volatile token for a routine logistics invoice.
Treasury ends up bearing FX risk on both sides. The "circular utility" that was supposed to
create buy pressure never forms; the only real demand is speculative. *Kill condition: slow
bleed, then delisting.*

**6. Governance capture.**
40% insider supply under 1-token-1-vote with no snapshot mechanism. First contentious vote
(likely on treasury deployment during a drawdown) exposes that governance is decorative.
*Kill condition: reputational, followed by community exit.*

---

## 10. What would actually work

The underlying business is not worthless. It is a different, smaller, less exciting business.

1. **Drop "carbon credit" and say "LCFS credit."** Precision here is free and the current
   language is affirmatively wrong.
2. **Own or contract the charging infrastructure.** Under LCFS the credit follows the
   registered fuel supply equipment. This is the actual moat and the whitepaper misses it
   entirely. An aggregator with signed assignment agreements across many hosts is a real,
   defensible position.
3. **Build the verification and reporting layer first, sell it as software.** Mandatory
   third-party verification from 2026 is a compliance burden every EV fleet in California now
   carries. That is a SaaS business with revenue on day one, no token, and no securities
   exposure. It is also the exact asset you would need before any token could be credible.
4. **If a token still makes sense after (3), make it a payment/rewards instrument only.**
   No IRR. No backing claim. No buybacks. No investment framing. Utility tokens survive
   scrutiny when they are boring.
5. **Rebuild the model at $28–70/credit** and see whether it still clears your hurdle rate.
   If it only works at $170, it does not work.
6. **Get DFAL, securities, and BSA counsel engaged before any further distribution.** The
   July 2026 deadline has passed.

---

## 11. Risk register

Scoring: Likelihood (L) and Impact (I), 1–5. Priority = L × I.

| ID | Risk | L | I | P | Mitigation |
|---|---|---|---|---|---|
| R-01 | No CARB protocol exists for ZEV transport offsets | 5 | 5 | **25** | Re-platform onto LCFS; rewrite all credit language |
| R-02 | Unregistered securities distribution (350M to US retail) | 4 | 5 | **20** | Securities counsel; restructure or restrict operator rewards |
| R-03 | DFAL licensing deadline missed (1 Jul 2026) | 5 | 4 | **20** | File immediately; assess cure options with counsel |
| R-04 | Credit prices ~6× below model | 5 | 4 | **20** | Rebuild model at $28–70; re-underwrite the raise |
| R-05 | ACF repeal removes mandated demand | 5 | 4 | **20** | Reposition on operating economics, not compliance |
| R-06 | Unsupported IRR projections in investor materials | 5 | 4 | **20** | Remove all IRR claims or publish the full model |
| R-07 | Trip attestation fraud → fraudulent credit sales | 3 | 5 | **15** | M-of-N quorum, dispute window, energy caps, independent evidence |
| R-08 | No LCFS credit assignment from charging hosts | 4 | 4 | **16** | Sign assignment agreements before any volume commitment |
| R-09 | Buyback commitment unfunded in a drawdown | 4 | 3 | 12 | Make buybacks discretionary and clearly disclosed as such |
| R-10 | Fee-on-transfer breaks listings and invoicing | 4 | 3 | 12 | Removed in this implementation; keep it removed |
| R-11 | Fixed supply vs multi-chain contradiction | 4 | 2 | 8 | Canonical chain + wrapped bridge; document explicitly |
| R-12 | Governance capture (40% insider, no snapshots) | 3 | 3 | 9 | ERC20Votes added; consider quorum floors and timelock |
| R-13 | Verification cost exceeds credit revenue at low volume | 4 | 3 | 12 | Join an existing aggregator before self-reporting |
| R-14 | Dealer refusal of token-denominated invoicing | 4 | 3 | 12 | Price in USD, settle in token optionally, never mandate |
| R-15 | Naming un-engaged audit firms in investor materials | 3 | 3 | 9 | Retain firms or move to roadmap with clear conditionality |
| R-16 | Admin key compromise (pause + freeze + mint-adjacent roles) | 2 | 5 | 10 | Multisig + timelock; `AccessControlDefaultAdminRules` delay |
| R-17 | Customer concentration (top 20 dealer groups) | 3 | 3 | 9 | Diversify; disclose concentration in offering documents |
