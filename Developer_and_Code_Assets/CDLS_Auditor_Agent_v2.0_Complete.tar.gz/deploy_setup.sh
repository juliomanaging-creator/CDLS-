#!/bin/bash
# CDLS AUDITOR AGENT - DEPLOYMENT SCRIPT
# Version: 2.0

echo "========================================="
echo "CDLS AUDITOR AGENT - DEPLOYMENT"
echo "CalPERS-Grade Institutional Readiness"
echo "========================================="
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 1. Check Python version
echo -n "Checking Python installation... "
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}✗ FAILED${NC}"
    echo "ERROR: Python 3 is required but not installed."
    echo "Please install Python 3.8 or higher."
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
echo -e "${GREEN}✓ Python $PYTHON_VERSION detected${NC}"

# 2. Install dependencies
echo -n "Installing Python dependencies... "
pip3 install -r requirements.txt --quiet --upgrade

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Dependencies installed${NC}"
else
    echo -e "${RED}✗ FAILED${NC}"
    echo "ERROR: Failed to install dependencies"
    exit 1
fi

# 3. Verify .env file
echo -n "Checking configuration file... "
if [ ! -f .env ]; then
    echo -e "${YELLOW}⚠ WARNING${NC}"
    echo "Creating .env from template..."
    cp .env.example .env
    echo -e "${YELLOW}Please edit .env with your actual credentials before running!${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Configuration found${NC}"

# 4. Secure permissions
echo -n "Securing configuration file... "
chmod 600 .env
echo -e "${GREEN}✓ Permissions set${NC}"

# 5. Create directories
echo -n "Creating directory structure... "
mkdir -p logs
mkdir -p dashboard/templates
mkdir -p dashboard/static/css
mkdir -p dashboard/static/js
mkdir -p tests
echo -e "${GREEN}✓ Directories created${NC}"

# 6. Test database connection
echo -n "Testing database connection... "
python3 -c "
import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()

try:
    conn = psycopg2.connect(
        host=os.getenv('DB_HOST'),
        dbname=os.getenv('DB_NAME'),
        user=os.getenv('DB_USER'),
        password=os.getenv('DB_PASS'),
        connect_timeout=5
    )
    conn.close()
    print('✓')
except Exception as e:
    print(f'✗ FAILED: {e}')
    exit(1)
" 2>&1 | tail -1

if [ "${PIPESTATUS[0]}" -ne 0 ]; then
    echo -e "${RED}Database connection failed${NC}"
    echo "Please verify your database credentials in .env"
    exit 1
fi
echo -e "${GREEN}Database connection successful${NC}"

# 7. Schedule cron job
echo ""
echo "Scheduling automated reports..."
SCRIPT_PATH=$(pwd)/auditor_logic.py

# Remove existing cron job if present
crontab -l 2>/dev/null | grep -v "$SCRIPT_PATH" | crontab -

# Add new cron job (Every Friday at 4 PM)
(crontab -l 2>/dev/null; echo "0 16 * * 5 /usr/bin/python3 $SCRIPT_PATH >> $(pwd)/logs/cron.log 2>&1") | crontab -

echo -e "${GREEN}✓ Cron job scheduled${NC}"
echo "  Schedule: Every Friday at 4:00 PM"
echo "  Log file: $(pwd)/logs/cron.log"

# 8. Optional: Start dashboard
echo ""
read -p "Start real-time dashboard? (y/n): " START_DASHBOARD

if [ "$START_DASHBOARD" = "y" ] || [ "$START_DASHBOARD" = "Y" ]; then
    if [ -f "dashboard/app.py" ]; then
        echo "Starting Flask dashboard..."
        cd dashboard
        nohup python3 app.py > ../logs/dashboard.log 2>&1 &
        DASHBOARD_PID=$!
        echo -e "${GREEN}✓ Dashboard started (PID: $DASHBOARD_PID)${NC}"
        echo "  Access at: http://localhost:5000"
        echo "  Log file: logs/dashboard.log"
        cd ..
    else
        echo -e "${YELLOW}⚠ Dashboard files not found, skipping${NC}"
    fi
fi

# 9. Test run
echo ""
read -p "Run test audit now? (y/n): " RUN_TEST

if [ "$RUN_TEST" = "y" ] || [ "$RUN_TEST" = "Y" ]; then
    echo ""
    echo "========================================="
    echo "EXECUTING TEST AUDIT RUN"
    echo "========================================="
    python3 auditor_logic.py
fi

# Final summary
echo ""
echo "========================================="
echo "DEPLOYMENT COMPLETE"
echo "========================================="
echo ""
echo -e "${GREEN}✓ System Ready${NC}"
echo ""
echo "Next Steps:"
echo "1. Check your email for the first audit report"
if [ "$START_DASHBOARD" = "y" ] || [ "$START_DASHBOARD" = "Y" ]; then
    echo "2. Access dashboard at http://localhost:5000"
fi
echo "3. Scheduled reports will run every Friday at 4 PM"
echo "4. View logs in ./logs/ directory"
echo ""
echo "Support:"
echo "  Email: engineering@californiadealerlogistics.com"
echo "  Docs: https://docs.cdls.com/auditor-agent"
echo ""
echo "========================================="
