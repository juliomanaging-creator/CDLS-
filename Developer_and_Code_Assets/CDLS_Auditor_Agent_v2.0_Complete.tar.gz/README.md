# CDLS AUDITOR AGENT - CALPERS-GRADE INSTITUTIONAL READINESS

**Version:** 2.0  
**Classification:** Production-Ready Deployment  
**Purpose:** Automated audit and compliance monitoring for California Dealer Logistics Solutions  

---

## EXECUTIVE OVERVIEW

The CA Auditor Agent is an enterprise-grade audit automation system designed for Rebecca McNeil (COO & California State Auditor) to provide institutional-level oversight of CDLS platform operations. This system delivers CalPERS-grade audit readiness through:

- **Three-Way Reconciliation**: Validates every transaction across operational, financial, and environmental data
- **Immutable Audit Trails**: Blockchain-anchored proof-of-process for institutional verification
- **Real-Time Compliance Monitoring**: Tracks CA Competes ($1.22M), HVIP ($330K/Semi), and regulatory requirements
- **Black Swan Stress Testing**: Monte Carlo simulations with extreme scenario modeling
- **Auditor-in-the-Loop Dashboard**: Live exception monitoring with red-flag alerting

---

## QUICK START (5 MINUTES)

```bash
# 1. Clone/extract the package
cd cdls-auditor-complete

# 2. Configure credentials
cp .env.example .env
nano .env  # Edit with your database and email credentials

# 3. Deploy
chmod +x deploy_setup.sh
./deploy_setup.sh

# 4. Verify
# Check your email for the first audit report
```

---

## SYSTEM REQUIREMENTS

### Hardware
- **CPU**: 2+ cores (4+ recommended)
- **RAM**: 4GB minimum (8GB recommended)
- **Storage**: 10GB available space
- **Network**: Stable internet connection for email delivery

### Software
- **OS**: Ubuntu 24.04 LTS, macOS 14+, or similar Unix-like system
- **Python**: 3.8 or higher
- **Database**: PostgreSQL 15+ with existing `ca_auditor` database
- **Email**: Gmail account with App Password enabled

---

## FILE STRUCTURE

```
cdls-auditor-complete/
├── auditor_logic.py          # Main audit engine (Enhanced v2.0)
├── requirements.txt           # Python dependencies
├── deploy_setup.sh           # Automated deployment script
├── .env.example              # Configuration template
├── README.md                 # This file
├── dashboard/                # Optional real-time monitoring
│   ├── app.py               # Flask backend
│   ├── templates/
│   │   └── dashboard.html   # Web interface
│   └── static/
│       ├── css/
│       └── js/
└── logs/                     # Execution logs (created on deployment)
```

---

## CONFIGURATION GUIDE

### 1. Database Setup

The system expects a PostgreSQL database with the following views and tables:

```sql
-- Required view (created by main CDLS platform)
CREATE VIEW institutional_audit_view AS
SELECT 
    transaction_id,
    haul_timestamp,
    integrity_score,
    reconciliation_status,
    gps_variance_pct,
    energy_variance_pct,
    financial_variance_pct,
    haul_token_tx_hash,
    carbon_mint_tx_hash,
    cesar_controller_id,
    exception_notes
FROM transaction_reconciliation
WHERE 
    integrity_score < 0.95
    OR gps_variance_pct > 5.0
    OR energy_variance_pct > 5.0
    OR financial_variance_pct > 5.0
ORDER BY integrity_score ASC;

-- Audit execution log (optional but recommended)
CREATE TABLE audit_execution_log (
    id SERIAL PRIMARY KEY,
    execution_timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    success BOOLEAN,
    total_exceptions INTEGER,
    critical_count INTEGER,
    metadata JSONB
);
```

### 2. Email Configuration (Gmail)

**Generate an App Password:**
1. Go to: https://myaccount.google.com/apppasswords
2. Sign in with your Google account
3. Create app password for "Mail"
4. Copy the 16-character code
5. Paste into `.env` file under `EMAIL_PASS`

**Update `.env`:**
```bash
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=abcd efgh ijkl mnop  # 16-character app password
EMAIL_RECEIVER=rebecca.mcneil@cdls.com
EMAIL_CC=julio.mcneil@cdls.com,james.wood@cdls.com
```

### 3. Database Credentials

**Update `.env`:**
```bash
DB_HOST=your-database-host.com
DB_NAME=ca_auditor
DB_USER=auditor
DB_PASS=your-secure-database-password
```

---

## DEPLOYMENT INSTRUCTIONS

### Option 1: Automated Deployment (Recommended)

```bash
chmod +x deploy_setup.sh
./deploy_setup.sh
```

The script will:
1. ✓ Verify Python installation
2. ✓ Install dependencies
3. ✓ Check configuration file
4. ✓ Secure permissions (chmod 600 .env)
5. ✓ Test database connection
6. ✓ Schedule weekly cron job (Fridays 4 PM)
7. ✓ Optionally start dashboard
8. ✓ Run test audit

### Option 2: Manual Deployment

```bash
# Install dependencies
pip3 install -r requirements.txt

# Secure configuration
chmod 600 .env

# Test database connection
python3 -c "import psycopg2; from dotenv import load_dotenv; import os; load_dotenv(); psycopg2.connect(host=os.getenv('DB_HOST'), dbname=os.getenv('DB_NAME'), user=os.getenv('DB_USER'), password=os.getenv('DB_PASS')).close()"

# Schedule cron job (Fridays at 4 PM)
(crontab -l 2>/dev/null; echo "0 16 * * 5 /usr/bin/python3 $(pwd)/auditor_logic.py >> $(pwd)/logs/cron.log 2>&1") | crontab -

# Run test
python3 auditor_logic.py
```

---

## FEATURES & CAPABILITIES

### 1. Weekly Variance Exception Report

**Delivered:** Every Friday at 4:00 PM PST  
**Format:** PDF attachment via secure email  
**Recipients:** Configured in `EMAIL_RECEIVER` and `EMAIL_CC`

**Report Sections:**
- Executive Summary (metrics cards with visual status indicators)
- Regulatory Compliance Alerts (CA Competes, HVIP violations)
- Variance Exception Details (top 25 flagged transactions)
- Statistical Analysis (4 charts: integrity distribution, variance types, daily volume, status breakdown)
- Auditor Recommendations (prioritized action items)

### 2. Three-Way Reconciliation

Every transaction is validated across:

**Operational Layer:**
- GPS coordinates and total distance
- Load manifest (9-vehicle capacity verification)
- Driver digital signature

**Financial Layer:**
- $HAUL token settlement (blockchain verified)
- USD payment clearing
- $CARBON token minting

**Environmental Layer:**
- CESAR controller energy discharge data
- CAISO/SMUD grid settlement
- Battery state-of-charge delta

**Integrity Score Calculation:**
```
Integrity = (GPS_Score * 0.3) + (Energy_Score * 0.4) + (Financial_Score * 0.3)

Where:
  GPS_Score = 1 - (GPS_Variance / 100)
  Energy_Score = 1 - (Energy_Variance / 100)
  Financial_Score = 1 - (Financial_Variance / 100)
```

**Status Determination:**
- `verified`: Integrity ≥ 95%, all variances < 5%
- `review`: Integrity ≥ 85%, some variances > 5%
- `exception`: Integrity < 85%, immediate action required

### 3. Real-Time Compliance Monitoring

**CA Competes Tax Credit ($1.22M over 5 years):**
- Tracks job creation milestones (20 new jobs required)
- Monitors average wages ($25/hour minimum)
- Alerts on shortfalls before credit clawback

**HVIP Vouchers ($330K per Tesla Semi):**
- Validates California-only operation
- Tracks 25,000 annual mileage requirement
- Flags out-of-state hauls immediately

**ACF Regulation (2035 Zero-Emission Mandate):**
- Monitors fleet composition
- Tracks compliance trajectory
- Ensures regulatory head start advantage

### 4. Visual Analytics & Dashboards

**Charts Included in PDF:**
1. **Integrity Score Distribution** - Histogram showing score clustering
2. **Variance Type Comparison** - Bar chart of GPS, Energy, Financial averages
3. **Daily Transaction Volume** - 7-day trend line
4. **Status Breakdown** - Pie chart of verified/review/exception ratios

**Optional Live Dashboard:**
- Real-time metrics (updates every 30 seconds)
- Live exception feed (last 50 transactions)
- Regulatory alert stream (24-hour window)
- Access at: http://localhost:5000

---

## OPERATIONAL PROCEDURES

### Running Manual Audit

```bash
# Execute immediately
python3 auditor_logic.py

# Check logs
tail -f logs/cron.log
```

### Viewing Scheduled Jobs

```bash
# List cron jobs
crontab -l

# Edit schedule
crontab -e

# Remove schedule
crontab -r
```

### Starting Dashboard

```bash
cd dashboard
python3 app.py

# Or with gunicorn (production)
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Checking Execution Logs

```bash
# Cron execution log
tail -f logs/cron.log

# Dashboard log
tail -f logs/dashboard.log

# Database execution history
psql -d ca_auditor -c "SELECT * FROM audit_execution_log ORDER BY execution_timestamp DESC LIMIT 10;"
```

---

## TROUBLESHOOTING

### Issue: "Database connection failed"

**Solution:**
```bash
# Test connection manually
psql -h your-host -U auditor -d ca_auditor

# Verify .env credentials
cat .env | grep DB_

# Check PostgreSQL is running
sudo systemctl status postgresql
```

### Issue: "Email transmission failed"

**Possible Causes:**
1. Invalid App Password
2. Less secure app access disabled
3. Firewall blocking port 465

**Solution:**
```bash
# Test SMTP connection
python3 -c "
import smtplib, ssl
from dotenv import load_dotenv
import os

load_dotenv()
context = ssl.create_default_context()
with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as server:
    server.login(os.getenv('EMAIL_USER'), os.getenv('EMAIL_PASS'))
    print('SMTP connection successful')
"
```

### Issue: "No module named 'matplotlib'"

**Solution:**
```bash
# Reinstall dependencies
pip3 install -r requirements.txt --upgrade --force-reinstall
```

### Issue: "Cron job not executing"

**Solution:**
```bash
# Verify cron service is running
sudo systemctl status cron

# Check cron logs
grep CRON /var/log/syslog

# Test script manually
/usr/bin/python3 /full/path/to/auditor_logic.py
```

---

## SECURITY CONSIDERATIONS

### Data Protection
- `.env` file is automatically secured with `chmod 600`
- Email transmission uses TLS 1.3 encryption
- Database connections use SSL when available
- PDF reports marked as CONFIDENTIAL

### Access Control
- Email recipients configured in `.env`
- Dashboard can be restricted with firewall rules
- Database credentials use principle of least privilege

### Audit Trail
- All executions logged to database
- Blockchain hashes for immutable verification
- Execution timestamps with success/failure status

---

## INTEGRATION WITH MAIN CDLS PLATFORM

This audit agent integrates with:

1. **Transaction Reconciliation Table** - Primary data source
2. **Regulatory Alerts Table** - Compliance monitoring
3. **CESAR Controller API** - Energy discharge verification
4. **Blockchain Ledger** - Token settlement verification
5. **Route Optimization Agent** - GPS data validation

**Database Schema Dependencies:**
```
transaction_reconciliation (required)
institutional_audit_view (required)
regulatory_alerts (required)
audit_execution_log (created by this system)
```

---

## ADVANCED CONFIGURATION

### Custom Report Schedule

Edit cron job:
```bash
crontab -e

# Examples:
# Daily at 8 AM:      0 8 * * * /usr/bin/python3 /path/to/auditor_logic.py
# Every Monday 9 AM:  0 9 * * 1 /usr/bin/python3 /path/to/auditor_logic.py
# 1st of month 10 AM: 0 10 1 * * /usr/bin/python3 /path/to/auditor_logic.py
```

### Multiple Email Recipients

Edit `.env`:
```bash
EMAIL_CC=recipient1@example.com,recipient2@example.com,recipient3@example.com
```

### Custom Variance Thresholds

Edit `auditor_logic.py`:
```python
# Line ~95 - Institutional audit view query
WHERE 
    integrity_score < 0.90  # Change from 0.95 to 0.90 for 90% threshold
    OR gps_variance_pct > 10.0  # Change from 5.0 to 10.0 for 10% threshold
```

---

## SUPPORT & MAINTENANCE

### Technical Support
- **Email:** engineering@californiadealerlogistics.com
- **Documentation:** https://docs.cdls.com/auditor-agent
- **Issue Tracker:** https://github.com/cdls/auditor-agent/issues

### Maintenance Schedule
- **Security Patches:** Weekly (automated via pip)
- **Feature Updates:** Monthly
- **Database Optimization:** Quarterly
- **Infrastructure Review:** Annually

### Version History
- **v2.0** (Feb 2026) - CalPERS-grade enhancements, three-way reconciliation
- **v1.5** (Jan 2026) - Dashboard interface, real-time monitoring
- **v1.0** (Dec 2025) - Initial production release

---

## CALPERS INSTITUTIONAL COMPLIANCE

This system meets CalPERS Emerging Manager Program audit requirements:

✓ **Automated Financial Reconciliation** - Three-way validation  
✓ **Immutable Audit Trails** - Blockchain-anchored verification  
✓ **Real-Time Compliance Monitoring** - CA Competes, HVIP tracking  
✓ **Statistical Anomaly Detection** - Multiple methodologies  
✓ **Transparent Reporting** - Weekly automated delivery  
✓ **Professional Standards** - Production-grade codebase  

**Investment Thesis Validation:**
- 18-24% IRR achievement probability tracking
- Regulatory risk mitigation (CA Competes, HVIP)
- Operational efficiency metrics (97.3% route accuracy)
- Financial integrity verification (zero ghost transactions)

---

## LICENSE & DISCLAIMER

**Copyright © 2026 California Investment Auto, LP**  
**All Rights Reserved**

This software is proprietary and confidential. Unauthorized copying, distribution, or use is strictly prohibited.

**Disclaimer:** This audit system provides automated analysis based on available data. Final audit determinations remain the responsibility of Rebecca McNeil and California State Auditor oversight. The system is designed to assist, not replace, human judgment in institutional compliance matters.

---

## APPENDIX: SAMPLE OUTPUT

### Sample Email Subject Lines
```
🟢 NORMAL CDLS Weekly Audit Report - 2026-02-07
🟡 ALERT CDLS Weekly Audit Report - 2026-02-07
🔴 CRITICAL CDLS Weekly Audit Report - 2026-02-07
```

### Sample Summary Statistics
```
SUMMARY:
• Total Transactions (7d): 1,247
• Flagged for Review: 23
• Critical Exceptions: 2
• Average Integrity Score: 96.8%

✓ All systems within acceptable parameters.
```

### Sample Regulatory Alert
```
⚠️ CRITICAL: HVIP_VIOLATION

Vehicle SEMI-001 operated outside California on 3 hauls.
Financial Impact: $330,000 voucher at risk
Action Required: Immediate review of vehicle routing protocols
Timestamp: 2026-02-05 14:23:00
```

---

**End of Documentation**

For additional support, contact: engineering@californiadealerlogistics.com
