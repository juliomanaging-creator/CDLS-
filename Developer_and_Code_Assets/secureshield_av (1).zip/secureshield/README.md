# SecureShield AV
**Personal antivirus for Windows 10/11 — no subscription, no cloud.**

---

## What's in this folder

| File | Purpose |
|---|---|
| `app.py` | Main program — scanner + web dashboard |
| `setup.bat` | One-time installer (run first, as admin) |
| `scan_history.db` | Auto-created — stores all scan results |
| `quarantine/` | Auto-created — threats moved here |
| `secureshield.log` | Auto-created — full activity log |

---

## First-Time Setup (10-15 minutes)

### Step 1 — Run setup.bat
Right-click `setup.bat` → **Run as administrator**

This will:
- Install Python packages (Flask, Watchdog)
- Download & install ClamAV (free AV engine, 8M+ signatures)
- Update virus definitions
- Enable Wake-on-LAN in Windows
- Add a firewall rule for the dashboard (port 5000)
- Create a startup shortcut so it runs on every boot

### Step 2 — Enable Wake-on-LAN in BIOS
This is required to power the laptop on remotely.
1. Restart laptop
2. Enter BIOS (press **Del**, **F2**, or **F10** right when it starts)
3. Go to **Power Management** (or Advanced)
4. Find **Wake on LAN** / **Wake on Magic Packet** → set to **Enabled**
5. Save and exit (usually F10)

### Step 3 — Install Tailscale (remote phone access)
Tailscale creates a private, encrypted tunnel so your phone can reach your laptop from anywhere — no port forwarding needed.

1. Download on laptop: https://tailscale.com/download/windows
2. Download on phone: search "Tailscale" in App Store or Google Play
3. Sign in with the **same Google/GitHub account** on both devices
4. Find your laptop's Tailscale IP at: https://login.tailscale.com/admin/machines
   - It looks like: `100.x.x.x`
   - Save this IP — you'll use it to access the dashboard from your phone

### Step 4 — Start the dashboard
Open a Command Prompt in this folder and run:
```
python app.py
```
Open your browser to: **http://localhost:5000**

From your phone (on Tailscale): **http://100.x.x.x:5000**

---

## Daily Use

### Scanning
- **Quick Scan buttons** — scans Downloads, Desktop, or Documents
- **Custom Path** — type any file or folder path
- Real-time results appear in the dashboard

### Real-time Monitor
- Click **Enable** under "Real-time Monitor"
- Watchdog watches Downloads, Desktop, and Documents
- Any new `.exe`, `.dll`, `.bat`, etc. gets scanned immediately
- Threats are quarantined automatically

### Update Virus Definitions
Run this monthly (or whenever you want fresh signatures):
```
"C:\Program Files\ClamAV\freshclam.exe"
```

---

## Wake Laptop Remotely

1. Install **WolOn** on your phone (iOS or Android) — it's free
2. Add a new device with:
   - **MAC address**: shown at end of setup.bat output
   - **Broadcast address**: your home network broadcast (e.g. 192.168.1.255)
   - **Port**: 9
3. Tap to wake — laptop powers on in ~30 seconds
4. Wait ~60 seconds, then open the dashboard in your browser via Tailscale IP

> **Note**: Wake-on-LAN only works when the laptop is connected to power and on your home network (WiFi or Ethernet). Ethernet is more reliable for WoL.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "clamscan missing" error | Re-run setup.bat or install ClamAV manually from clamav.net |
| Dashboard won't load from phone | Make sure Tailscale is connected on both devices |
| Real-time monitor not working | Run `pip install watchdog` in Command Prompt |
| Wake-on-LAN not working | Check BIOS setting; use Ethernet instead of WiFi |
| Definitions outdated | Run `freshclam.exe` in ClamAV folder |

---

## Keeping Definitions Fresh (Scheduled Task)
To auto-update definitions weekly, open Task Scheduler and create a task:
- **Program**: `C:\Program Files\ClamAV\freshclam.exe`
- **Schedule**: Weekly, Sunday 3:00 AM
- **Run whether user is logged in or not**: Yes
