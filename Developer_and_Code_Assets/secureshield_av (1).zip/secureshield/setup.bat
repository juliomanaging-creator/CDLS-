@echo off
setlocal EnableDelayedExpansion
title SecureShield AV — Setup
color 0A

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║    SecureShield AV — Windows Setup       ║
echo  ║    No subscription. No cloud. Yours.     ║
echo  ╚══════════════════════════════════════════╝
echo.

:: ─── Check Admin ─────────────────────────────────────────────────────────────
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] Run this script as Administrator.
    echo      Right-click setup.bat → "Run as administrator"
    pause
    exit /b 1
)
echo  [OK] Running as Administrator

:: ─── Check Python ────────────────────────────────────────────────────────────
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [!] Python not found.
    echo      Install Python 3.10+ from: https://www.python.org/downloads/
    echo      IMPORTANT: Check "Add Python to PATH" during install.
    echo.
    pause
    exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do echo  [OK] Python %%v found

:: ─── Install Python Dependencies ─────────────────────────────────────────────
echo.
echo  [..] Installing Python packages (flask, watchdog)...
python -m pip install flask watchdog --quiet --upgrade
if %errorlevel% neq 0 (
    echo  [!] pip install failed. Check your internet connection.
    pause
    exit /b 1
)
echo  [OK] flask + watchdog installed

:: ─── ClamAV Installation ─────────────────────────────────────────────────────
echo.
echo  ─── ClamAV Antivirus Engine ─────────────────────
if exist "C:\Program Files\ClamAV\clamscan.exe" (
    echo  [OK] ClamAV already installed at C:\Program Files\ClamAV\
    goto :update_defs
)

echo  [..] Downloading ClamAV for Windows...
set CLAM_URL=https://github.com/Cisco-Talos/clamav/releases/download/clamav-1.4.2/ClamAV-1.4.2.win.x64.msi
set CLAM_MSI=%TEMP%\clamav_installer.msi

powershell -NoProfile -Command ^
  "Write-Host '  Downloading...'; ^
   [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; ^
   Invoke-WebRequest -Uri '%CLAM_URL%' -OutFile '%CLAM_MSI%' -UseBasicParsing" 2>nul

if not exist "%CLAM_MSI%" (
    echo.
    echo  [!] Download failed. Please install ClamAV manually:
    echo      https://www.clamav.net/downloads
    echo      Install to: C:\Program Files\ClamAV\
    echo.
    goto :post_clam
)

echo  [..] Installing ClamAV (silent install)...
msiexec /i "%CLAM_MSI%" /quiet /norestart INSTALLDIR="C:\Program Files\ClamAV"
timeout /t 5 /nobreak >nul
if exist "C:\Program Files\ClamAV\clamscan.exe" (
    echo  [OK] ClamAV installed successfully
) else (
    echo  [!] ClamAV install may have failed — check C:\Program Files\ClamAV\
)

:update_defs
echo.
echo  [..] Updating ClamAV virus definitions (may take 1-2 min)...
"C:\Program Files\ClamAV\freshclam.exe" --quiet
if %errorlevel% equ 0 (
    echo  [OK] Virus definitions updated
) else (
    echo  [~] Definition update returned non-zero (may still work). Check manually with:
    echo      freshclam
)

:post_clam

:: ─── Wake-on-LAN ──────────────────────────────────────────────────────────────
echo.
echo  ─── Wake-on-LAN Setup ───────────────────────────
echo  [..] Enabling Wake-on-LAN for all active network adapters...
powershell -NoProfile -Command ^
  "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | ForEach-Object { ^
     try { ^
       Set-NetAdapterAdvancedProperty -Name $_.Name ^
         -DisplayName 'Wake on Magic Packet' ^
         -DisplayValue 'Enabled' -ErrorAction Stop; ^
       Write-Host ('  [OK] WoL enabled: ' + $_.Name) ^
     } catch { Write-Host ('  [~] Skipped: ' + $_.Name + ' — ' + $_.Exception.Message) } ^
   }"

echo.
echo  [!] BIOS step required (Windows alone is not enough):
echo      1. Restart your laptop
echo      2. Enter BIOS (usually Del, F2, or F10 during boot)
echo      3. Find: Power Management → Wake on LAN → Set to Enabled
echo      4. Save and exit

:: ─── Firewall Rule ────────────────────────────────────────────────────────────
echo.
echo  ─── Firewall Rule ───────────────────────────────
echo  [..] Adding firewall exception for port 5000 (dashboard)...
netsh advfirewall firewall delete rule name="SecureShieldAV" >nul 2>&1
netsh advfirewall firewall add rule ^
  name="SecureShieldAV" ^
  dir=in ^
  action=allow ^
  protocol=tcp ^
  localport=5000 ^
  description="SecureShield AV Dashboard" ^
  >nul 2>&1
echo  [OK] Firewall rule added — port 5000 open on local network

:: ─── Startup Shortcut ────────────────────────────────────────────────────────
echo.
echo  ─── Auto-Start on Boot ──────────────────────────
set SCRIPT_DIR=%~dp0
set STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup

echo  [..] Creating startup shortcut in: %STARTUP_DIR%
(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo sLink = oWS.SpecialFolders^("Startup"^) ^& "\SecureShieldAV.lnk"
echo Set oLink = oWS.CreateShortcut^(sLink^)
echo oLink.TargetPath = "pythonw.exe"
echo oLink.Arguments = """%SCRIPT_DIR%app.py"""
echo oLink.WorkingDirectory = "%SCRIPT_DIR%"
echo oLink.Description = "SecureShield AV Dashboard"
echo oLink.WindowStyle = 7
echo oLink.Save
) > "%TEMP%\ss_shortcut.vbs"

cscript //nologo "%TEMP%\ss_shortcut.vbs"
if exist "%STARTUP_DIR%\SecureShieldAV.lnk" (
    echo  [OK] Startup shortcut created — app launches silently on every boot
) else (
    echo  [!] Shortcut creation may have failed — you can start manually with: python app.py
)

:: ─── Quick Summary ────────────────────────────────────────────────────────────
echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║   SETUP COMPLETE — Next Steps                        ║
echo  ╠══════════════════════════════════════════════════════╣
echo  ║                                                      ║
echo  ║  1. GET YOUR TAILSCALE IP (remote access from phone) ║
echo  ║     → Install Tailscale on this laptop:              ║
echo  ║       https://tailscale.com/download                 ║
echo  ║     → Install Tailscale app on your phone            ║
echo  ║     → Sign in with the same account on both          ║
echo  ║     → Find your laptop IP at:                        ║
echo  ║       https://login.tailscale.com/admin/machines     ║
echo  ║                                                      ║
echo  ║  2. START THE DASHBOARD (first time)                 ║
echo  ║     → python app.py                                  ║
echo  ║     → Open in browser: http://localhost:5000         ║
echo  ║                                                      ║
echo  ║  3. ACCESS FROM PHONE (after Tailscale setup)        ║
echo  ║     → http://[your-tailscale-ip]:5000                ║
echo  ║     → Works from ANYWHERE, even on LTE               ║
echo  ║                                                      ║
echo  ║  4. WAKE LAPTOP FROM PHONE                           ║
echo  ║     → Install "WolOn" app (Android/iOS)              ║
echo  ║     → Or use any Wake-on-LAN app                     ║
echo  ║     → Enter your laptop MAC address (shown below)    ║
echo  ║                                                      ║
echo  ╚══════════════════════════════════════════════════════╝
echo.
echo  Your network adapter MAC address(es):
powershell -NoProfile -Command ^
  "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | ^
   Select-Object Name, MacAddress | Format-Table -AutoSize"
echo.
echo  Copy the MAC address into your WolOn app.
echo  (Use the Ethernet or WiFi adapter — NOT Bluetooth or VPN)
echo.
pause
