#!/usr/bin/env python3
"""
SecureShield AV — Personal Antivirus Suite
Windows 10/11 | Flask Phone Dashboard | ClamAV Engine | Watchdog Monitor
Author: Built for Julio | No subscription, no cloud, no tracking.
"""

import os
import sys
import json
import shutil
import logging
import sqlite3
import subprocess
import threading
from pathlib import Path
from datetime import datetime
from flask import Flask, jsonify, request

# ─── Configuration ────────────────────────────────────────────────────────────
BASE_DIR    = Path(__file__).parent
DB_PATH     = BASE_DIR / "scan_history.db"
QUARANTINE  = BASE_DIR / "quarantine"
LOG_FILE    = BASE_DIR / "secureshield.log"

# ClamAV path — setup.bat installs it here
CLAMSCAN    = r"C:\Program Files\ClamAV\clamscan.exe"

# Directories watched in real-time
WATCH_DIRS  = [
    os.path.expanduser("~/Downloads"),
    os.path.expanduser("~/Desktop"),
    os.path.expanduser("~/Documents"),
]

# ─── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ]
)
log = logging.getLogger("SecureShield")

# ─── App & State ──────────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.urandom(24)

state = {
    "status": "idle",         # idle | scanning | monitoring
    "current_file": "",
    "threats_found": 0,
    "last_scan": None,
    "monitor_active": False,
}
_observer = None


# ─── Database ─────────────────────────────────────────────────────────────────
def init_db():
    QUARANTINE.mkdir(exist_ok=True)
    with sqlite3.connect(DB_PATH) as c:
        c.executescript("""
            CREATE TABLE IF NOT EXISTS scans (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_type    TEXT,
                target       TEXT,
                started_at   TEXT,
                finished_at  TEXT,
                files_scanned INTEGER DEFAULT 0,
                threats_found INTEGER DEFAULT 0,
                status        TEXT
            );
            CREATE TABLE IF NOT EXISTS threats (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id      INTEGER REFERENCES scans(id),
                file_path    TEXT,
                threat_name  TEXT,
                action_taken TEXT,
                detected_at  TEXT
            );
        """)


def db_get(sql, params=()):
    with sqlite3.connect(DB_PATH) as c:
        c.row_factory = sqlite3.Row
        return [dict(r) for r in c.execute(sql, params).fetchall()]


def db_run(sql, params=()):
    with sqlite3.connect(DB_PATH) as c:
        cur = c.execute(sql, params)
        c.commit()
        return cur.lastrowid


# ─── Scanner Core ─────────────────────────────────────────────────────────────
def _clamscan_worker(target: str, scan_id: int):
    """Runs ClamAV as a subprocess; logs results to DB. Runs in a thread."""
    global state
    state["status"] = "scanning"
    state["current_file"] = target
    state["threats_found"] = 0

    threats, files_scanned = [], 0

    try:
        proc = subprocess.Popen(
            [CLAMSCAN, "--recursive", "--infected", "--no-summary", target],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

        for line in proc.stdout:
            line = line.strip()
            if not line:
                continue
            files_scanned += 1
            state["current_file"] = line[:100]

            if "FOUND" in line:
                # ClamAV format: /path/to/file: ThreatName FOUND
                parts = line.split(":", 1)
                fpath = parts[0].strip()
                tname = parts[1].replace(" FOUND", "").strip() if len(parts) > 1 else "Unknown"
                threats.append((fpath, tname))
                state["threats_found"] += 1
                log.warning(f"THREAT: {fpath} — {tname}")
                _quarantine(fpath, scan_id)

        proc.wait()
        finish_status = "completed"

    except FileNotFoundError:
        log.error(f"ClamAV not found at: {CLAMSCAN} — run setup.bat first.")
        finish_status = "error: clamscan missing"
    except Exception as e:
        log.error(f"Scan error: {e}")
        finish_status = f"error: {str(e)[:80]}"

    # Persist results
    db_run(
        """UPDATE scans SET finished_at=?, files_scanned=?, threats_found=?, status=?
           WHERE id=?""",
        (datetime.now().isoformat(), files_scanned, len(threats), finish_status, scan_id),
    )
    for fpath, tname in threats:
        db_run(
            """INSERT INTO threats (scan_id, file_path, threat_name, action_taken, detected_at)
               VALUES (?, ?, ?, 'quarantined', ?)""",
            (scan_id, fpath, tname, datetime.now().isoformat()),
        )

    state["status"] = "monitoring" if state["monitor_active"] else "idle"
    state["last_scan"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    log.info(f"Scan done — files: {files_scanned}, threats: {len(threats)}")


def _quarantine(file_path: str, scan_id: int):
    try:
        src = Path(file_path)
        if not src.exists():
            return
        dst = QUARANTINE / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{src.name}"
        shutil.move(str(src), str(dst))
        log.info(f"Quarantined: {src.name} → quarantine/")
    except Exception as e:
        log.error(f"Quarantine failed for {file_path}: {e}")


def launch_scan(target: str, scan_type: str = "manual") -> int:
    """Insert a scan record and kick off a background thread."""
    scan_id = db_run(
        "INSERT INTO scans (scan_type, target, started_at, status) VALUES (?, ?, ?, 'running')",
        (scan_type, target, datetime.now().isoformat()),
    )
    t = threading.Thread(target=_clamscan_worker, args=(target, scan_id), daemon=True)
    t.start()
    return scan_id


# ─── Real-time File Monitor ───────────────────────────────────────────────────
RISKY_EXTS = {".exe", ".dll", ".bat", ".ps1", ".vbs", ".js", ".msi", ".scr", ".hta", ".cmd"}

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler

    class _ThreatHandler(FileSystemEventHandler):
        def on_created(self, event):
            if not event.is_directory:
                log.info(f"New file: {event.src_path}")
                launch_scan(event.src_path, "realtime:created")

        def on_modified(self, event):
            if not event.is_directory:
                if Path(event.src_path).suffix.lower() in RISKY_EXTS:
                    log.info(f"Risky modification: {event.src_path}")
                    launch_scan(event.src_path, "realtime:modified")

    _WATCHDOG_OK = True
except ImportError:
    _WATCHDOG_OK = False
    log.warning("watchdog not installed — real-time monitoring unavailable (pip install watchdog)")


def start_monitor() -> bool:
    global _observer
    if not _WATCHDOG_OK:
        return False
    if _observer and _observer.is_alive():
        return True
    _observer = Observer()
    handler = _ThreatHandler()
    for d in WATCH_DIRS:
        if os.path.isdir(d):
            _observer.schedule(handler, d, recursive=True)
            log.info(f"Watching: {d}")
    _observer.start()
    state["monitor_active"] = True
    state["status"] = "monitoring"
    return True


def stop_monitor():
    global _observer
    if _observer and _observer.is_alive():
        _observer.stop()
        _observer.join()
    state["monitor_active"] = False
    state["status"] = "idle"


# ─── Dashboard HTML ───────────────────────────────────────────────────────────
DOWNLOADS = os.path.expanduser("~/Downloads").replace("\\", "\\\\")
DESKTOP   = os.path.expanduser("~/Desktop").replace("\\", "\\\\")
DOCUMENTS = os.path.expanduser("~/Documents").replace("\\", "\\\\")

DASHBOARD = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SecureShield AV</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Exo+2:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
:root {{
  --bg:#08090c; --panel:#101318; --border:#1a2030;
  --accent:#00d4ff; --green:#00ff88; --red:#ff3b3b; --warn:#ffb800;
  --text:#bcd0e4; --muted:#4a5568;
  --mono:'Share Tech Mono',monospace; --body:'Exo 2',sans-serif;
}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:var(--bg);color:var(--text);font-family:var(--body);min-height:100vh;
  background-image:radial-gradient(ellipse 60% 40% at 15% 15%,rgba(0,212,255,.05) 0%,transparent 100%),
                   radial-gradient(ellipse 50% 50% at 85% 85%,rgba(0,255,136,.04) 0%,transparent 100%);}}
/* ── Header ── */
header{{display:flex;align-items:center;justify-content:space-between;
  padding:14px 20px;border-bottom:1px solid var(--border);
  background:rgba(8,9,12,.92);backdrop-filter:blur(12px);position:sticky;top:0;z-index:100}}
.logo{{font-family:var(--mono);font-size:1rem;color:var(--accent);letter-spacing:3px;
  display:flex;align-items:center;gap:10px}}
.logo span{{font-size:1.3rem;display:inline-block;animation:spin 10s linear infinite}}
@keyframes spin{{to{{transform:rotate(360deg)}}}}
.pill{{font-family:var(--mono);font-size:.65rem;padding:4px 12px;border-radius:20px;
  letter-spacing:1px;text-transform:uppercase;border:1px solid;transition:all .3s}}
.pill.idle{{color:var(--green);border-color:var(--green);background:rgba(0,255,136,.07)}}
.pill.scanning{{color:var(--warn);border-color:var(--warn);background:rgba(255,184,0,.07);animation:blink 1s ease infinite}}
.pill.monitoring{{color:var(--accent);border-color:var(--accent);background:rgba(0,212,255,.07)}}
@keyframes blink{{50%{{opacity:.4}}}}
/* ── Layout ── */
main{{padding:18px;max-width:860px;margin:0 auto}}
.row2{{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px}}
@media(max-width:520px){{.row2{{grid-template-columns:1fr}}}}
/* ── Cards ── */
.card{{background:var(--panel);border:1px solid var(--border);border-radius:10px;
  padding:18px;position:relative;overflow:hidden}}
.card::before{{content:'';position:absolute;top:0;left:0;right:0;height:2px;
  background:linear-gradient(90deg,transparent,var(--accent),transparent);opacity:.4}}
.card.green::before{{background:linear-gradient(90deg,transparent,var(--green),transparent)}}
.cap{{font-family:var(--mono);font-size:.6rem;letter-spacing:2px;text-transform:uppercase;
  color:var(--muted);margin-bottom:10px}}
.big{{font-size:2.2rem;font-weight:700;font-family:var(--mono);color:var(--accent);line-height:1}}
.big.r{{color:var(--red)}} .big.g{{color:var(--green)}}
.sub{{font-size:.75rem;color:var(--muted);margin-top:4px}}
/* ── Section headers ── */
.sh{{font-family:var(--mono);font-size:.6rem;letter-spacing:2px;text-transform:uppercase;
  color:var(--muted);margin:16px 0 8px;display:flex;align-items:center;gap:8px}}
.sh::after{{content:'';flex:1;height:1px;background:var(--border)}}
/* ── Buttons ── */
.btn-row{{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}}
button{{font-family:var(--body);font-size:.82rem;font-weight:600;padding:9px 16px;
  border-radius:7px;border:none;cursor:pointer;transition:all .2s;
  display:flex;align-items:center;gap:6px}}
.ba{{background:var(--accent);color:#000}} .ba:hover{{filter:brightness(1.15);transform:translateY(-1px);box-shadow:0 4px 18px rgba(0,212,255,.25)}}
.bg{{background:var(--green);color:#000}} .bg:hover{{filter:brightness(1.1);transform:translateY(-1px)}}
.bo{{background:transparent;color:var(--text);border:1px solid var(--border)}} .bo:hover{{border-color:var(--accent);color:var(--accent)}}
.br{{background:transparent;color:var(--red);border:1px solid var(--red)}} .br:hover{{background:rgba(255,59,59,.08)}}
/* ── Input ── */
input[type=text]{{width:100%;padding:9px 13px;background:rgba(0,0,0,.4);
  border:1px solid var(--border);border-radius:7px;color:var(--text);
  font-family:var(--mono);font-size:.82rem;margin-top:10px;outline:none;
  transition:border-color .2s}}
input[type=text]:focus{{border-color:var(--accent)}}
/* ── Progress ── */
.prog-wrap{{margin-top:14px;display:none}}
.prog-bar{{height:3px;background:var(--border);border-radius:3px;overflow:hidden}}
.prog-fill{{height:100%;width:0%;background:linear-gradient(90deg,var(--accent),var(--green));border-radius:3px;transition:width .6s}}
.prog-file{{font-family:var(--mono);font-size:.68rem;color:var(--muted);margin-top:6px;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}
/* ── Monitor toggle ── */
.mon-row{{display:flex;align-items:center;justify-content:space-between;
  padding-top:12px;margin-top:12px;border-top:1px solid var(--border)}}
.mon-info .lbl{{font-size:.85rem}} .mon-info .desc{{font-size:.7rem;color:var(--muted);margin-top:2px}}
/* ── Table ── */
table{{width:100%;border-collapse:collapse;font-size:.8rem}}
th{{font-family:var(--mono);font-size:.58rem;letter-spacing:1.5px;text-transform:uppercase;
  color:var(--muted);padding:7px 10px;border-bottom:1px solid var(--border);text-align:left}}
td{{padding:9px 10px;border-bottom:1px solid rgba(26,32,48,.5);vertical-align:top;word-break:break-all}}
tr:hover td{{background:rgba(0,212,255,.025)}}
.tag{{display:inline-block;font-family:var(--mono);font-size:.6rem;padding:2px 7px;border-radius:4px;
  text-transform:uppercase;letter-spacing:.8px}}
.ta{{background:rgba(0,212,255,.1);color:var(--accent)}}
.tg{{background:rgba(0,255,136,.1);color:var(--green)}}
.tr{{background:rgba(255,59,59,.12);color:var(--red)}}
.tw{{background:rgba(255,184,0,.1);color:var(--warn)}}
.empty{{text-align:center;padding:28px;color:var(--muted);font-family:var(--mono);font-size:.75rem}}
/* ── Toast ── */
#toast{{position:fixed;bottom:18px;right:18px;padding:10px 18px;border-radius:8px;
  font-family:var(--mono);font-size:.75rem;background:var(--panel);
  border:1px solid var(--accent);color:var(--accent);z-index:999;
  opacity:0;transform:translateY(14px);transition:all .3s;pointer-events:none}}
#toast.show{{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>

<header>
  <div class="logo"><span>⬡</span> SECURESHIELD AV</div>
  <div class="pill idle" id="pill">IDLE</div>
</header>

<main>
  <!-- Stats -->
  <div class="row2">
    <div class="card">
      <div class="cap">Last Scan Completed</div>
      <div class="big g" id="lastScan">—</div>
      <div class="sub" id="lastScanSub">No scan yet</div>
    </div>
    <div class="card">
      <div class="cap">Total Threats Found</div>
      <div class="big" id="threatBig">0</div>
      <div class="sub" id="threatSub">System clear</div>
    </div>
  </div>

  <!-- Scan Controls -->
  <div class="sh">Scan Controls</div>
  <div class="card green">
    <div class="cap">Quick Scan — High Risk Folders</div>
    <div class="btn-row">
      <button class="ba" onclick="scan('{DOWNLOADS}')">⬇ Downloads</button>
      <button class="ba" onclick="scan('{DESKTOP}')">🖥 Desktop</button>
      <button class="ba" onclick="scan('{DOCUMENTS}')">📁 Documents</button>
    </div>

    <div class="cap" style="margin-top:16px">Custom Path Scan</div>
    <input type="text" id="cpath" placeholder="C:\\Users\\Julio\\Downloads\\suspicious.exe">
    <div class="btn-row">
      <button class="bo" onclick="scanCustom()">▶ Scan This Path</button>
    </div>

    <div class="prog-wrap" id="progWrap">
      <div class="prog-bar"><div class="prog-fill" id="progFill"></div></div>
      <div class="prog-file" id="progFile">Initializing scanner…</div>
    </div>

    <div class="mon-row">
      <div class="mon-info">
        <div class="lbl">Real-time Monitor</div>
        <div class="desc">Watches Downloads · Desktop · Documents for new threats</div>
      </div>
      <button class="bg" id="monBtn" onclick="toggleMonitor()">▶ Enable</button>
    </div>
  </div>

  <!-- Scan History -->
  <div class="sh">Scan History</div>
  <div class="card">
    <table>
      <thead><tr><th>Type</th><th>Target</th><th>Started</th><th>Files</th><th>Threats</th><th>Status</th></tr></thead>
      <tbody id="histBody"><tr><td colspan="6"><div class="empty">No scans yet — run a scan above.</div></td></tr></tbody>
    </table>
  </div>

  <!-- Threat Log -->
  <div class="sh">Threat Log</div>
  <div class="card">
    <table>
      <thead><tr><th>File</th><th>Threat Name</th><th>Action</th><th>When</th></tr></thead>
      <tbody id="tBody"><tr><td colspan="4"><div class="empty">No threats detected — system clean ✓</div></td></tr></tbody>
    </table>
  </div>

  <!-- Quarantine -->
  <div class="sh">Quarantine</div>
  <div class="card" id="qCard">
    <div class="empty">Quarantine folder is empty ✓</div>
  </div>
</main>

<div id="toast"></div>

<script>
function toast(msg, ms=3200) {{
  const t=document.getElementById('toast');
  t.textContent=msg; t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),ms);
}}
function pill(s) {{
  const p=document.getElementById('pill');
  p.className='pill '+s; p.textContent=s.toUpperCase();
}}

async function scan(path) {{
  if(!path){{toast('⚠ No path');return;}}
  pill('scanning');
  document.getElementById('progWrap').style.display='block';
  document.getElementById('progFill').style.width='8%';
  toast('▶ Scan started…');
  const r=await fetch('/api/scan',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{path}})}});
  const d=await r.json();
  if(d.error){{toast('Error: '+d.error);return;}}
  poll();
}}
function scanCustom(){{scan(document.getElementById('cpath').value.trim());}}

function poll() {{
  const iv=setInterval(async()=>{{
    const d=await(await fetch('/api/status')).json();
    document.getElementById('progFile').textContent=d.current_file||'Scanning…';
    document.getElementById('threatBig').textContent=d.threats_found;
    if(d.threats_found>0){{
      document.getElementById('threatBig').className='big r';
      document.getElementById('threatSub').textContent='Quarantined automatically';
    }}
    if(d.status==='scanning'){{document.getElementById('progFill').style.width='55%';}}
    else{{
      document.getElementById('progFill').style.width='100%';
      pill(d.monitor_active?'monitoring':'idle');
      document.getElementById('lastScan').textContent=d.last_scan||'—';
      toast('✓ Scan complete — threats: '+d.threats_found);
      clearInterval(iv);
      setTimeout(()=>{{document.getElementById('progWrap').style.display='none';}},2200);
      loadHistory(); loadThreats();
    }}
  }},1600);
}}

async function toggleMonitor() {{
  const d=await(await fetch('/api/monitor/toggle',{{method:'POST'}})).json();
  const b=document.getElementById('monBtn');
  if(d.active){{b.textContent='⏹ Disable';b.className='br';pill('monitoring');toast('🔍 Real-time monitor ON');}}
  else{{b.textContent='▶ Enable';b.className='bg';pill('idle');toast('Monitor stopped');}}
}}

async function loadHistory() {{
  const data=await(await fetch('/api/history')).json();
  const tb=document.getElementById('histBody');
  if(!data.length){{tb.innerHTML='<tr><td colspan="6"><div class="empty">No scans yet.</div></td></tr>';return;}}
  tb.innerHTML=data.map(s=>`
    <tr>
      <td><span class="tag ta">${{s.scan_type}}</span></td>
      <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.72rem" title="${{s.target}}">${{s.target}}</td>
      <td style="font-size:.7rem;color:var(--muted);white-space:nowrap">${{(s.started_at||'').substring(0,16)}}</td>
      <td>${{s.files_scanned}}</td>
      <td>${{s.threats_found>0?`<span class="tag tr">${{s.threats_found}}</span>`:'<span class="tag tg">0</span>'}}</td>
      <td><span class="tag ${{s.status==='completed'?'tg':s.status==='running'?'tw':'tr'}}">${{s.status}}</span></td>
    </tr>`).join('');
}}

async function loadThreats() {{
  const data=await(await fetch('/api/threats')).json();
  const tb=document.getElementById('tBody');
  if(!data.length){{tb.innerHTML='<tr><td colspan="4"><div class="empty">No threats — system clean ✓</div></td></tr>';return;}}
  tb.innerHTML=data.map(t=>`
    <tr>
      <td style="font-size:.7rem;font-family:var(--mono)">${{t.file_path}}</td>
      <td><span class="tag tr">${{t.threat_name}}</span></td>
      <td><span class="tag tw">${{t.action_taken}}</span></td>
      <td style="font-size:.7rem;color:var(--muted);white-space:nowrap">${{(t.detected_at||'').substring(0,16)}}</td>
    </tr>`).join('');
}}

loadHistory(); loadThreats();
</script>
</body>
</html>"""


# ─── API Routes ───────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return DASHBOARD

@app.route("/api/status")
def api_status():
    return jsonify(state)

@app.route("/api/scan", methods=["POST"])
def api_scan():
    body = request.get_json(silent=True) or {}
    path = body.get("path", "").strip()
    if not path:
        return jsonify({"error": "No path provided"}), 400
    if state["status"] == "scanning":
        return jsonify({"error": "Scan already in progress"}), 409
    scan_id = launch_scan(path)
    return jsonify({"scan_id": scan_id, "message": "Scan launched"})

@app.route("/api/monitor/toggle", methods=["POST"])
def api_monitor_toggle():
    if state["monitor_active"]:
        stop_monitor()
    else:
        start_monitor()
    return jsonify({"active": state["monitor_active"]})

@app.route("/api/history")
def api_history():
    rows = db_get("SELECT * FROM scans ORDER BY started_at DESC LIMIT 25")
    return jsonify(rows)

@app.route("/api/threats")
def api_threats():
    rows = db_get("SELECT * FROM threats ORDER BY detected_at DESC LIMIT 50")
    return jsonify(rows)

@app.route("/api/quarantine")
def api_quarantine():
    files = [f.name for f in QUARANTINE.iterdir() if QUARANTINE.exists()]
    return jsonify(files)


# ─── Entry Point ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    log.info("=" * 55)
    log.info("  SecureShield AV  |  http://0.0.0.0:5000")
    log.info(f"  ClamAV path : {CLAMSCAN}")
    log.info(f"  Quarantine  : {QUARANTINE}")
    log.info(f"  DB          : {DB_PATH}")
    log.info("=" * 55)
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
