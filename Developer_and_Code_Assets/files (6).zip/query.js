/**
 * routes/query.js
 * ================
 * Demonstrates wiring statuteCrosscheckMiddleware into the actual CASAER
 * routes that generate LLM guidance text -- POST /api/query and
 * POST /api/chat per Section 10.3 of the CASAER IT documentation.
 *
 * This is a minimal stand-in for the real Ollama-calling route handler
 * (the source doc's Section 6.2 step 4-5: "Express -> Ollama API
 * (localhost:11434)" / "Ollama returns structured guidance"). The mock
 * `callOllama()` below stands in for that real call so this file is
 * runnable and testable without a live Ollama instance.
 */

'use strict';

const express = require('express');
const path = require('path');
const { statuteCrosscheckMiddleware } = require('../middleware/statuteCrosscheck');

const router = express.Router();

const DB_PATH = path.join(__dirname, '..', 'data', 'statute_lookup.sqlite');

// Attach the crosscheck middleware ONLY to routes that return LLM guidance
// text -- not to /api/analyze/* (R engine routes) or /api/reports/* (export
// routes), which don't generate free-text statute citations.
const crosscheck = statuteCrosscheckMiddleware({
  dbPath: DB_PATH,
  textField: 'guidance',
  blockOnFlag: false, // annotate + flag for human review, don't hard-block
});

/**
 * Stand-in for the real Express -> Ollama call (source doc Section 6.2).
 * In production this is an HTTP call to http://ollama:11434/api/generate.
 */
async function callOllama(prompt) {
  // Simulated response: deliberately includes a fabricated citation
  // (Gov. Code 99999) to exercise the crosscheck end-to-end, exactly like
  // statute_pipeline/test_pipeline.py did on the Python side.
  return {
    guidance:
      `Based on your query, the relevant enforcement pathway is Financial Fraud & ` +
      `Misappropriation, governed by Gov. Code 8546-8546.7 and Penal Code 424, 504. ` +
      `Additionally, this case may also implicate Gov. Code 99999, which establishes ` +
      `expedited whistleblower review timelines.`,
    modelVersion: 'llama3.2:3b',
  };
}

// POST /api/query -- per CASAER API doc Section 10.3
router.post('/api/query', crosscheck, async (req, res, next) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'MISSING_PROMPT' });
    }
    const ollamaResult = await callOllama(prompt);
    // res.json is the wrapped version from the middleware above --
    // the crosscheck runs automatically on this call.
    res.json({
      guidance: ollamaResult.guidance,
      modelVersion: ollamaResult.modelVersion,
    });
  } catch (err) {
    next(err);
  }
});

// POST /api/chat -- multi-turn variant, same crosscheck applies
router.post('/api/chat', crosscheck, async (req, res, next) => {
  try {
    const { messages } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'MISSING_MESSAGES' });
    }
    const lastPrompt = messages[messages.length - 1]?.content ?? '';
    const ollamaResult = await callOllama(lastPrompt);
    res.json({
      guidance: ollamaResult.guidance,
      modelVersion: ollamaResult.modelVersion,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
