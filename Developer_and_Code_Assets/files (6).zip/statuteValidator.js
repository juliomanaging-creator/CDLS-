/**
 * lib/statuteValidator.js
 * ========================
 * JS port of statute_validator.py, so the cross-check runs in-process inside
 * the Express API server instead of shelling out to Python per-request.
 *
 * Reads the SAME SQLite file produced by ingest_statutes.py (the Python
 * ingestion tool stays Python since the leginfo bulk-database parsing logic
 * is more naturally a one-off batch job; this module is the hot path that
 * runs on every request, so it's a thin, fast JS reader against that DB).
 */

'use strict';

const Database = require('better-sqlite3');

// Same alias table as statute_validator.py -- keep these in sync if either
// file changes. (Consider moving to a shared JSON config if this grows.)
const CODE_ALIASES = {
  'gov. code': 'Government Code',
  'gov code': 'Government Code',
  'government code': 'Government Code',
  'penal code': 'Penal Code',
  'pub. contract code': 'Public Contract Code',
  'pub contract code': 'Public Contract Code',
  'public contract code': 'Public Contract Code',
  'civil code': 'Civil Code',
  'rev. & tax code': 'Revenue and Taxation Code',
  'rev & tax code': 'Revenue and Taxation Code',
  'revenue & taxation code': 'Revenue and Taxation Code',
  'revenue and taxation code': 'Revenue and Taxation Code',
  'health & safety code': 'Health and Safety Code',
  'health and safety code': 'Health and Safety Code',
  'welf. & inst. code': 'Welfare and Institutions Code',
  'welf & inst code': 'Welfare and Institutions Code',
  'welfare & institutions code': 'Welfare and Institutions Code',
  'welfare and institutions code': 'Welfare and Institutions Code',
};

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Build the citation regex by anchoring on known code-name aliases (longest
// first), same fix as the Python version -- a generic greedy character
// class swallows surrounding prose ("governed by Gov. Code") instead of
// just the code name.
function buildCitationPattern() {
  const aliases = Object.keys(CODE_ALIASES).sort((a, b) => b.length - a.length);
  const alternation = aliases.map(escapeRegex).join('|');
  return new RegExp(
    `(${alternation})\\s+(\\d+(?:\\.\\d+)?)(?:\\s*-\\s*(\\d+(?:\\.\\d+)?))?`,
    'gi'
  );
}

const CITATION_PATTERN = buildCitationPattern();

function normalizeCode(rawCode) {
  const key = rawCode.trim().toLowerCase().replace(/\s+/g, ' ');
  return CODE_ALIASES[key] || rawCode.trim();
}

function extractCitations(text) {
  const results = [];
  let match;
  const pattern = new RegExp(CITATION_PATTERN); // fresh instance (global state)
  while ((match = pattern.exec(text)) !== null) {
    const [raw, rawCode, start, end] = match;
    results.push({
      rawText: raw.trim(),
      code: normalizeCode(rawCode),
      sectionStart: start,
      sectionEnd: end || start,
    });
  }
  return results;
}

class StatuteValidator {
  /**
   * @param {string} dbPath - path to the SQLite file built by ingest_statutes.py
   */
  constructor(dbPath) {
    this.db = new Database(dbPath, { readonly: true, fileMustExist: true });
    this._byCodeStmt = this.db.prepare(
      'SELECT code, section, title, active FROM statute_lookup WHERE code = ?'
    );
  }

  _sectionSortKey(section) {
    const n = parseFloat(section);
    return Number.isNaN(n) ? section : n;
  }

  checkCitation(citation) {
    const rows = this._byCodeStmt.all(citation.code);
    const startKey = this._sectionSortKey(citation.sectionStart);
    const endKey = this._sectionSortKey(citation.sectionEnd);

    const matches = rows.filter((row) => {
      if (!row.active) return false;
      const secKey = this._sectionSortKey(row.section);
      if (typeof secKey === 'number' && typeof startKey === 'number' && typeof endKey === 'number') {
        return secKey >= startKey && secKey <= endKey;
      }
      return row.section === citation.sectionStart || row.section === citation.sectionEnd;
    });

    return {
      ...citation,
      resolved: matches.length > 0,
      matchedRows: matches,
    };
  }

  /**
   * Main entry point. Call on every piece of LLM-generated text before it
   * reaches the client.
   * @param {string} llmOutput
   * @returns {{citationsFound:number, citationsResolved:number, flagged:Array, safeToDisplay:boolean}}
   */
  validateResponseText(llmOutput) {
    const citations = extractCitations(llmOutput);
    const checked = citations.map((c) => this.checkCitation(c));
    const flagged = checked.filter((c) => !c.resolved);

    return {
      citationsFound: checked.length,
      citationsResolved: checked.length - flagged.length,
      flagged: flagged.map((c) => ({
        rawText: c.rawText,
        code: c.code,
        sectionStart: c.sectionStart,
        sectionEnd: c.sectionEnd,
        reason: 'No matching active section found in statute_lookup table.',
      })),
      safeToDisplay: flagged.length === 0,
    };
  }

  close() {
    this.db.close();
  }
}

module.exports = { StatuteValidator, extractCitations, normalizeCode, CODE_ALIASES };
