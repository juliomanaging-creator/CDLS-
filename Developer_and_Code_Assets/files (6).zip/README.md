# CASAER Express Middleware: Statute Citation Cross-Check

Implements the integration point recommended in `CASAER_Technical_Audit.md` Section 8
and `statute_pipeline/README.md` — wires the statute cross-check into the actual
Express layer described in the CASAER IT documentation (Section 7.3 "Output Filtering").

## What's here

| File | Purpose |
|---|---|
| `lib/statuteValidator.js` | JS port of the Python `statute_validator.py` logic — runs in-process so the check happens on the request path with no subprocess/network hop. Reads the same SQLite schema produced by `ingest_statutes.py`. |
| `middleware/statuteCrosscheck.js` | The actual Express middleware. Wraps `res.json` so any outgoing response containing LLM-generated guidance text gets scanned before it reaches the client. |
| `routes/query.js` | Shows the middleware attached to the real CASAER routes that generate guidance — `POST /api/query` and `POST /api/chat` (per source doc Section 10.3) — with a mock Ollama call standing in for the real one. |
| `app.js` | Minimal runnable app wiring it together. |
| `test/blockingModeServer.js` | Exercises the alternate hard-block mode and the all-clean (no false positives) case. |
| `data/statute_lookup.sqlite` | Same placeholder seed data used in the Python pipeline — **not verified against the real bulk database.** |

## Verified behavior (actually run, not just described)

Started the Express server and hit the real route three ways:

1. **Default mode (`blockOnFlag: false`)** — `POST /api/query` with a mock Ollama response containing one fabricated citation (`Gov. Code 99999`):
   - Real citations (`Gov. Code 8546-8546.7`, `Penal Code 424`) resolved cleanly, no noise.
   - Fabricated citation was annotated in-place in the response text with a visible `⚠ UNVERIFIED CITATION` marker.
   - `citationCheck` metadata block attached with `safeToDisplay: false`.
   - `requiresHumanReview: true` set automatically.

2. **Hard-block mode (`blockOnFlag: true`)** — same kind of fabricated citation, different route:
   - Response correctly replaced with HTTP **422** and a structured `UNVERIFIED_STATUTE_CITATION` error instead of passing anything to the client.

3. **All-clean case** — a response where every citation is real:
   - Passed through with `citationCheck.safeToDisplay: true`, `requiresHumanReview: false`, and the original text completely unmodified. Confirms the middleware doesn't introduce false positives or unnecessary noise on correct output.

## Design decisions worth flagging for the State Auditor's office

- **Default is annotate-and-flag, not hard-block.** Rationale carried over from the audit doc: blocking entirely on any single flagged citation risks making the tool unusable if the lookup table is incomplete (e.g., a real but newly-amended section not yet re-ingested). The `blockOnFlag: true` switch is there if the office decides the stricter policy is worth the usability tradeoff — this is a policy call, not a technical one, and should be made explicitly rather than left as a default.
- **Fail-closed on validator errors.** If the cross-check itself throws (e.g., DB file missing/corrupted), the middleware does NOT silently pass the original response through — it marks the whole response `requiresHumanReview: true` with a `CROSSCHECK_UNAVAILABLE` flag. A broken validator should never look like a clean validator.
- **Every check is logged** (`logCitationCheck`), as a placeholder for the real `audit_trail` hash-chain insert described in Section 9.2 of the CASAER IT doc. This needs to be wired to the actual PostgreSQL audit trail in production, not left as a `console.log`.
- **Scope is intentionally narrow** — only attached to `/api/query` and `/api/chat`, not the R-analytics or report-export routes, since those don't generate free-text statute citations.

## Before this goes to production

Same caveats as the Python pipeline, since they share the same underlying (placeholder) data:
1. Swap `data/statute_lookup.sqlite` for the one built from the real `leginfo.public.ca.gov` bulk database (`ingest_statutes.py --mode=ftp`, run from inside CASAER's actual network).
2. Replace the mock `callOllama()` in `routes/query.js` with the real HTTP call to `http://ollama:11434/api/generate`.
3. Replace `logCitationCheck()`'s console output with a real parameterized `audit_trail` INSERT including the SHA-256 hash chain.
4. Get an explicit policy decision on `blockOnFlag` from the State Auditor's office rather than shipping with the default silently chosen.
