/**
 * middleware/statuteCrosscheck.js
 * ================================
 * Integration point for CASAER_Technical_Audit.md Section 8 / Section 7.3 of
 * the CASAER IT doc ("Output Filtering: Post-generation scanning for PII,
 * off-topic content, hallucinated statutes").
 *
 * WHERE THIS RUNS: as response middleware on every route that returns
 * Ollama-generated guidance text -- per the CASAER API doc (Section 10.3),
 * that's POST /api/query and POST /api/chat. It does NOT need to run on
 * the R-analytics or report-export routes, which don't generate free-text
 * legal guidance.
 *
 * HOW IT WORKS: wraps res.json so that, for routes this middleware is
 * attached to, any outgoing JSON body containing a `guidance` (or
 * configurable) text field gets scanned. If a citation in that text fails
 * to resolve against the statute lookup table, the response is NOT blocked
 * by default (see annotatedOnly option) -- instead each flagged citation is
 * annotated in-place and a `citationCheck` metadata block is attached, so
 * the auditor sees an explicit "UNVERIFIED" marker rather than either (a) a
 * silently wrong citation or (b) a fully blocked, unusable response.
 *
 * This default favors visibility-with-warning over hard-blocking, per the
 * audit recommendation in statute_pipeline/README.md ("recommend the latter
 * with strong visual distinction... blocking entirely... may make the tool
 * unusable"). Pass `{ blockOnFlag: true }` to switch to hard-block behavior
 * if that's the policy decision the State Auditor's office wants instead.
 */

'use strict';

const { StatuteValidator } = require('../lib/statuteValidator');

/**
 * @param {object} options
 * @param {string} options.dbPath - path to statute_lookup.sqlite
 * @param {string} [options.textField='guidance'] - which field in the JSON
 *        response body holds the LLM-generated text to scan
 * @param {boolean} [options.blockOnFlag=false] - if true, respond 422 instead
 *        of passing through an annotated response when any citation is flagged
 */
function statuteCrosscheckMiddleware(options) {
  const { dbPath, textField = 'guidance', blockOnFlag = false } = options;
  const validator = new StatuteValidator(dbPath);

  return function (req, res, next) {
    const originalJson = res.json.bind(res);

    res.json = function (body) {
      try {
        if (body && typeof body[textField] === 'string') {
          const result = validator.validateResponseText(body[textField]);

          // Audit trail: every check result gets logged regardless of outcome
          // (this satisfies the immutable audit_trail requirement in Section
          // 9.2 of the CASAER IT doc -- wire this to the real audit_trail
          // insert in production rather than console.log).
          logCitationCheck(req, result);

          if (!result.safeToDisplay) {
            if (blockOnFlag) {
              return res.status(422).json({
                error: 'UNVERIFIED_STATUTE_CITATION',
                message:
                  'One or more statute citations in the generated guidance could not be ' +
                  'verified against the current California statute lookup table. ' +
                  'This response has been withheld. Contact a Senior Auditor for manual review.',
                citationCheck: result,
              });
            }

            // Default: annotate in place, pass through with a visible warning.
            body[textField] = annotateFlaggedCitations(body[textField], result.flagged);
            body.citationCheck = result;
            body.requiresHumanReview = true;
          } else {
            body.citationCheck = result;
            body.requiresHumanReview = false;
          }
        }
      } catch (err) {
        // Fail closed on validator errors -- never let a crash in the
        // cross-check silently skip verification. Flag for manual review
        // rather than passing the original (unchecked) body through.
        req.app?.locals?.logger?.error?.('statute crosscheck failed', err) ||
          console.error('statute crosscheck failed', err);
        body.citationCheck = {
          error: 'CROSSCHECK_UNAVAILABLE',
          message: 'Statute cross-check could not run; treat all citations in this response as unverified.',
        };
        body.requiresHumanReview = true;
      }

      return originalJson(body);
    };

    next();
  };
}

function annotateFlaggedCitations(text, flagged) {
  let annotated = text;
  for (const f of flagged) {
    if (annotated.includes(f.rawText)) {
      annotated = annotated.replace(
        f.rawText,
        `${f.rawText} [⚠ UNVERIFIED CITATION — not found in current statute lookup table]`
      );
    }
  }
  return annotated;
}

function logCitationCheck(req, result) {
  // Placeholder for the real audit_trail insert (Section 9.2 hash-chain).
  // In production this should be a parameterized INSERT into audit_trail
  // with the SHA-256 chain calculation, not a console.log.
  console.log(
    JSON.stringify({
      event: 'statute_citation_check',
      userId: req.user?.id ?? 'unknown',
      sessionId: req.body?.sessionId ?? null,
      citationsFound: result.citationsFound,
      citationsResolved: result.citationsResolved,
      flaggedCount: result.flagged?.length ?? 0,
      timestamp: new Date().toISOString(),
    })
  );
}

module.exports = { statuteCrosscheckMiddleware };
