# CASAER — Technical & Code Audit Documentation
## CA State Auditing Enforcement Reports System

**Document status:** Draft v0.1 — independent audit, separate from Project Caesar (CDLS)
**Source reviewed:** CASAER IT Documentation Package v3.0 (Feb 2026), as submitted
**Prepared for:** Audit trail / due-diligence record

---

## 0. Preliminary Note on Source Document Status

Classification marking removed from this audit's working copy pending clarification of who issued it and whether this package is entitled to carry it — see Revision Log.

This audit treats the source document **as a vendor-submitted technical specification under review**, not as verified fact. Its content and framing (ROI tables, "what we deliver" packaging, "Zero new staff needed. Zero recurring costs." messaging, a "Value Analysis" section) read as vendor/sales material, which doesn't disqualify the technical claims but means they need independent verification rather than pass-through acceptance. Status as of this revision:

| Claim category | Status |
|---|---|
| Cited CA State Auditor fraud statistics | **Verified — see Section 7** (mostly confirmed against primary sources; one figure needs page-level citation) |
| Security/compliance framework alignment (NIST 800-53, NIST AI 100-1, FedRAMP, CIS Docker Benchmark) | **Still self-asserted — see Section 8** (cannot be verified from documentation alone) |
| Performance benchmarks (Section 19 of source doc) | **Still self-asserted — see Section 8** (vendor-reported, no independent test results provided) |
| Whether CASAER is an authorized/deployed state system | Still unverified — outside this audit's scope; flag for legal/procurement review |

---

## 1. Scope

**In scope:** the five-layer architecture (React/Tailwind presentation, Node.js/Express API, Ollama/llama3.2:3b AI layer, R/Rserve analytics, PostgreSQL/Redis data layer), security controls (SC1–SC10), network/data flow, authentication/RBAC, deployment models (Docker, standalone, offline HTML), data retention/DR, performance claims, monitoring, and testing/QA as described in the submitted v3.0 documentation.

**Out of scope:** legal authority for an AI system to operate within the State Auditor's statutory mandate (Gov. Code 8546.7) — that's a legal/policy review, not a technical audit; procurement/vendor-vetting process.

---

## 2. Audit Methodology

Same structure as Project Caesar, for consistency across audit trails:

| Field | Description |
|---|---|
| **Component** | What's being reviewed |
| **Claimed in doc** | What v3.0 asserts |
| **Audit method** | Code review, config review, pen test, independent verification, etc. |
| **Status** | Not started / In progress / Complete |
| **Findings** | Issues identified, including unverifiable claims |
| **Severity** | Critical / High / Medium / Low |
| **Remediation / Verification needed** | Action or evidence required |
| **Sign-off** | Reviewer + date |

---

## 3. Audit Checklist by Component

### 3.1 Architecture & Deployment Claims
- [ ] Verify "zero cloud dependency / fully air-gapped" claim — confirm via actual network capture/firewall log review, not documentation assertion alone (Section 6 claims "Block all outbound" but this needs live verification)
- [ ] Verify Docker image provenance — confirm the six pre-built images (`casaer/*:3.0`) come from a reviewable, signed build pipeline, not an opaque third-party binary drop
- [ ] Confirm SHA-256 checksums in `casaer-checksums.sha256` are independently regenerated and compared, not just trusted from the delivery media
- [ ] Standalone/offline-HTML deployment — confirm the "no npm install required, node_modules included" claim doesn't mean unscanned, unpinned dependencies are silently bundled

### 3.2 AI/LLM Component (Ollama / llama3.2:3b)
- [ ] Verify the system prompt constraints described in 7.2 ("NEVER fabricate statute numbers," "ALWAYS cite specific statutes") are actually enforced server-side, not just instructed and hoped-for — LLMs can still hallucinate statute citations even when instructed not to; this is the single highest-risk component given the use case (legal/audit guidance)
- [ ] Test prompt-injection defenses (Section 7.3) against actual adversarial inputs, not just the documented filter list
- [ ] Output filtering for hallucinated statutes — confirm there's an automated cross-check against an actual statute database, not just LLM self-restraint
- [ ] Confirm "Known Limitations" Section 23 disclosure ("LLM may occasionally generate imprecise statute references") is surfaced to end users in the actual UI, not just buried in IT documentation

### 3.3 R Statistical Engine
- [ ] Verify Benford's Law implementation against published ACFE reference datasets (doc claims this in 21.1 — confirm test results exist and are reviewable, not just asserted)
- [ ] Confirm statistical methodology review (chi-square/MAD thresholds, anomaly detection sensitivity) by someone other than the system's own developers — methodology errors here directly produce false fraud accusations or missed fraud, both high-stakes for a state audit tool
- [ ] Monte Carlo simulation — verify parameter assumptions and convergence are documented per-use, not just "available"

### 3.4 Security Architecture
- [ ] Independently verify each control in the Security Controls Matrix (SC1–SC10) — documentation claiming AES-256, TLS 1.3, RBAC, etc. is not the same as a third-party security assessment confirming correct implementation
- [ ] Confirm "non-root containers, read-only filesystem, no privileged capabilities" (SC7) via actual `docker inspect` output, not just the claim
- [ ] Confirm Trivy vulnerability scanning (Section 5.4) results are available for review, with actual CVE remediation history — not just "scans are performed"
- [ ] Penetration test — confirm one has actually been performed by an independent party; Section 21 lists OWASP ZAP as a tool used but doesn't show findings/results in this package

### 3.5 Database & Audit Trail
- [ ] Verify the SHA-256 hash-chain audit trail (Section 9.2) actually detects tampering — run the verification query against a deliberately modified record to confirm `chain_valid` flips to false
- [ ] Confirm 7-year retention is actually enforced (automated, not manual/optional)
- [ ] Confirm `audit_trail` table itself cannot be modified by any role, including Admin, without breaking the hash chain (an Admin who can edit `prev_hash` undermines the entire tamper-evidence claim)

### 3.6 Authentication & Authorization
- [ ] Confirm SAML/LDAP integration has actually been tested against the state's real Active Directory/IdP, not just configured in theory
- [ ] Verify RBAC role boundaries (Admin/Senior Auditor/Auditor/Viewer) are enforced server-side on every endpoint listed in Section 10, not just in the UI
- [ ] Confirm bcrypt cost factor 12 and JWT secret length (256-bit minimum) are actually set in production config, not left at insecure defaults
- [ ] MFA exemption for Viewer role (Section 11.3) — flag as a policy decision worth re-examining given Viewer role includes "Legislature staff, oversight committees" who may handle sensitive findings

### 3.7 Performance Claims
- [ ] Re-run the benchmarks in Section 19 independently — vendor-reported benchmarks (e.g., "<2 seconds" LLM response, "50+ simultaneous users") should be verified under realistic concurrent load, not accepted from the documentation as-is

### 3.8 Disaster Recovery
- [ ] Confirm the quarterly DR test (Section 18) has an actual documented history of past test results — the doc describes the *policy* for DR testing, not evidence that it's been executed

### 3.9 Compliance Claims
- [ ] NIST 800-53 / NIST AI 100-1 / FedRAMP / CIS Docker Benchmark alignment — confirm these are independently assessed (e.g., via a recognized assessor) rather than self-declared "alignment" in vendor documentation. "Alignment" is not the same as "certified" or "authorized"

---

## 7. Verification: Cited CA State Auditor Fraud Statistics

Checked against primary sources at auditor.ca.gov as of this revision:

| Claim in CASAER doc | Verification result | Source |
|---|---|---|
| EDD fraud losses (2024): $513M estimated | **NOT supported by the cited source as written.** Pulled the primary PDF directly: page 12 of Report 2025-601 (Dec 2025) states fraud "was more than $500 million in 2024 alone" — no $513M figure appears anywhere in the report text. This specific number should be re-sourced or revised to match the report's actual language before any further use. | Report 2025-601 (Dec 2025), p.12 |
| Improper payments (2023–2024): $1.5B across state programs | **Confirmed**, p.12: "approximately $1.5 billion" in improper EDD payments over CY 2023–2024. Note: the doc's framing ("across state programs") is broader than the report's actual scope (EDD specifically) — worth correcting in any reuse. | Report 2025-601, p.12 |
| EDD potentially fraudulent payments: $10.4B pandemic-era | **Confirmed exactly.** Report states EDD "paid about $10.4 billion for claims... that it has since determined may be fraudulent," March–December 2020. | Report 2020-628.2 (Jan 2021) |
| Whistleblower cases per cycle: 2,636 received | **Confirmed exactly.** | State Auditor Investigations Unit I2025-1 (Dec 2025) |
| Cases fully investigated: 72 of 2,636 (2.7% throughput) | **Confirmed.** Report states "72 out of the 2,636 cases, or three percent" — the report itself rounds to 3%; the doc's 2.7% is the more precise unrounded figure (72/2636 = 2.732%) and is accurate. | I2025-1 |
| CalFresh at-risk funds: $2.5B in benefits requiring oversight | **Confirmed, with a caveat.** Page 7 of Report 2025-601 states "the State's total estimated additional costs would therefore be nearly $2.5 billion annually" — matches. However, the report's own earlier summary (p.5–6) separately states "about $2 billion annually" for what reads as the same claim — an inconsistency in the primary source itself, not introduced by the CASAER doc. Cite page 7's $2.5B figure, not the earlier summary's $2B figure, going forward. | Report 2025-601, p.5–7 |

**Bottom line:** five of six figures check out, one (4) at full precision down to the page. The $513M figure does not appear in the source as cited and should be corrected or re-sourced — this is the one finding that should actually change the CASAER document, not just get an audit footnote.

---

## 8. Statute Database for Automated Cross-Checking (Section 3.2 follow-up)

The system's highest-risk component — an LLM generating California statute citations for audit enforcement guidance — needs a hard, automated cross-check against an authoritative source, not just prompt-level instruction. Options, in order of recommendation:

1. **California Legislative Information bulk database (recommended primary source)** — `leginfo.legislature.ca.gov` is the official, public-domain (Gov. Code §10248.5) source for current CA codes and statutes. There is no modern public REST API, but the Legislative Counsel publishes a relational bulk database via anonymous FTP (`ftp://leginfo.public.ca.gov/pub`), containing the full structured text of all 29 California Codes plus statutes and bill history. This is the authoritative dataset to ingest into a local lookup table that CASAER's output-filtering layer (Section 7.3 of the source doc) checks every generated citation against — verify the section number actually exists in current code text before any citation reaches a user, rather than relying on the LLM's self-restraint.
2. **`leginfo.legislature.ca.gov` Code Search / CodesTextSearch pages** — usable for spot-checking individual citations during testing, but not suited to bulk automated cross-checking (no stable API contract; scraping is fragile).
3. **Third-party structured wrappers** (e.g., the open-source `california-laws-api` project, which ingests the same official FTP dump into a queryable index) — useful as an implementation reference, but for a state audit tool CASAER should build its own ingest pipeline directly from the official FTP source rather than depend on an unmaintained third-party project.
4. **Commercial options (Westlaw/Lexis/Deering's APIs)** — more complete (annotations, case law, legislative history) but introduce licensing cost and a live external dependency, which conflicts with CASAER's stated air-gapped design goal. Only worth considering if the air-gap requirement is relaxed.

**Recommended implementation:** CASAER should periodically (e.g., on each "Major Update" cycle per Section 22.1 of the source doc) pull the official bulk database from `leginfo.public.ca.gov`, build a local, versioned statute-lookup table inside the air-gapped environment, and run every LLM-generated citation through an exact-match (or fuzzy-match-with-flag) check against that table before output reaches an auditor. Any citation that doesn't resolve should be flagged, not silently passed through — this turns "ALWAYS cite... NEVER fabricate" from a prompt instruction into an enforced control.

**Status: prototype built and tested.** See `statute_pipeline/` (companion deliverable). Ingestion script, citation extractor/validator, and a test harness are working — verified against simulated LLM output combining CASAER's own real pathway citations with one deliberately fabricated section number; the pipeline correctly resolved the real citations and flagged the fabricated one. The lookup table currently uses placeholder seed data (outbound FTP to leginfo.public.ca.gov is blocked from the sandbox this was built in); swapping in the real bulk database is a one-command step (`ingest_statutes.py --mode=ftp`) to run from inside CASAER's actual network. See `statute_pipeline/README.md` for the pre-production checklist.

**Express integration: also built and tested.** See `casaer_middleware/` (second companion deliverable) — a JS port of the validator wired into actual Express middleware, attached to the real `POST /api/query` and `POST /api/chat` routes per Section 10.3 of the CASAER IT doc. Ran a live server and confirmed three behaviors end-to-end: (1) default mode annotates fabricated citations in-place with a visible warning and flags for human review without touching real citations; (2) hard-block mode returns HTTP 422 with a structured error instead of passing anything through; (3) an all-clean response (every citation real) passes through with zero false positives. See `casaer_middleware/README.md` for the policy decision this raises (annotate-and-warn vs. hard-block) that the State Auditor's office should make explicitly before production.

---

## 9. Compliance & Performance Claims — Verification Status

**Compliance claims (NIST 800-53, NIST AI 100-1, FedRAMP, CIS Docker Benchmark, CCPA/CPRA, California SAM 5300-5399):** Cannot be verified from the IT documentation package alone. "Alignment" claims in vendor documentation are self-declared by definition. Actual verification requires one of:
- A third-party security assessment report (none was included in the submitted package)
- Direct technical access (config files, container images, code) to confirm controls match the matrix in Section 5.2 of the source doc
- For FedRAMP specifically: FedRAMP authorization is a formal process with a public Marketplace listing (marketplace.fedramp.gov) — worth checking whether CASAER or its vendor appears there at all, since "applicable controls for on-prem equivalent security posture" in the source doc is notably vaguer than an actual authorization claim would be

**Performance claims (Section 19 benchmarks — sub-2-second LLM response, 50+ concurrent users, etc.):** Also unverifiable from documentation. These are vendor-reported single-test results under specified hardware (RTX 3060, Xeon E-2388G) and should be re-run independently under the State Auditor's actual target hardware and realistic concurrent load before being relied on for capacity planning.

**Status:** both items move from "documentation review" to "requires hands-on technical audit" — they're blocked on getting actual system access or third-party assessment reports, not something further desk review of the PDF can resolve. Recommend this as the next concrete milestone.

---

## 4. Highest-Priority Risk Areas (flagged for early attention)

1. **LLM-generated legal citations in a state enforcement context** — a hallucinated statute number used in an actual hearing or report would be a serious failure mode; this needs the strongest verification before any production use, regardless of what the system prompt claims.
2. **Self-reported security/compliance posture** — every security and compliance claim in this package is vendor-asserted; none should be treated as audited fact until independently confirmed.
3. **Classification marking legitimacy** — "FOR OFFICIAL USE ONLY" on a document that reads as sales material should be clarified with whoever issued/received it before this package is treated as an official record.

---

## 5. Open Items / Not Yet Auditable

- No actual codebase, container images, or running deployment have been reviewed — this audit is against the *documentation only* at this stage.
- No independent penetration test results, DR test logs, or compliance assessment reports were included in the submitted package.
- The accuracy of cited CA State Auditor fraud statistics has not been cross-checked against the original published reports (auditor.ca.gov/reports/2025-601, 2020-628.2, I2025-1) as part of this technical audit — recommend a separate fact-check pass before these figures are cited externally.

---

## 6. Revision Log

| Version | Date | Change |
|---|---|---|
| v0.1 | Draft | Initial audit framework for CASAER established, separate from Project Caesar/CDLS |
| v0.2 | Draft | Removed "FOR OFFICIAL USE ONLY" marking from working copy pending clarification of issuing authority; verified cited fraud statistics against primary CA State Auditor reports (Section 7); identified recommended statute database for automated citation cross-checking (Section 8); confirmed compliance and performance claims remain unverifiable from documentation alone and require hands-on technical audit (Section 9) |
| v0.3 | Draft | Built and tested working prototype of the statute cross-check pipeline (see companion `statute_pipeline/` deliverable); pulled exact page citations from primary PDF for the two previously-unconfirmed fraud figures — CalFresh $2.5B confirmed (p.7) with a noted inconsistency against the report's own earlier $2B figure (p.5-6); EDD $513M found **unsupported** by the cited source, which states only "more than $500 million" (p.12) |
| v0.4 | Draft | Built and live-tested the actual Express middleware integration point (see companion `casaer_middleware/` deliverable), wired into the real `/api/query` and `/api/chat` routes; verified annotate-mode, hard-block mode, and the all-clean/no-false-positive case by running a real server and hitting it with curl |
