'use strict';

const express = require('express');
const queryRouter = require('./routes/query');

const app = express();
app.use(express.json());
app.use(queryRouter);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'INTERNAL_ERROR' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`CASAER middleware demo listening on :${PORT}`));
