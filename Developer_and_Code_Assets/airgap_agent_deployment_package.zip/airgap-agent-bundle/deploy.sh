#!/bin/bash
set -e

echo "--------------------------------------------------"
echo "🚀 Airgap Agent Deployment Engine Initializing..."
echo "--------------------------------------------------"

echo "📦 [1/4] Loading container image archives into local Docker daemon..."
if [ -f "./ollama_image.tar" ]; then
    docker load -i ./ollama_image.tar
fi
if [ -f "./agent_image.tar" ]; then
    docker load -i ./agent_image.tar
fi

mkdir -p $(pwd)/models

echo "🧠 [2/4] Starting isolated Ollama LLM service..."
if [ "$(docker ps -aq -f name=ollama-server)" ]; then
    docker rm -f ollama-server
fi

docker run -d \
  --name ollama-server \
  --restart always \
  -v $(pwd)/models:/root/.ollama \
  -p 11434:11434 \
  ollama/ollama:latest

echo "⏳ [3/4] Waiting for LLM engine initialization..."
until curl -s http://127.0.0.1:11434/api/tags > /dev/null; do
    sleep 2
    echo -n "."
done
echo ""
echo "✅ LLM Engine Online."

echo "🤖 [4/4] Launching Portable Airgap Agent Terminal..."
docker run -it \
  --rm \
  --name airgap-agent-cli \
  --network="host" \
  my-airgap-agent:v1

echo "--------------------------------------------------"
echo "✅ Deployment Session Ended Cleanly."
echo "--------------------------------------------------"
