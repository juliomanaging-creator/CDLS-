# Portable Air-Gapped Agent Deployment Bundle

This project provides a completely self-contained deployment package for running an autonomous AI agent in air-gapped environments without external internet connectivity.

## File Hierarchy
```text
airgap-agent-bundle/
├── agent.py            # Main interactive agent logic
├── Dockerfile          # Agent container build file
├── requirements.txt    # Python dependencies
├── deploy.sh           # Linux / macOS launcher script
├── deploy.bat          # Windows launcher script
├── build_package.sh    # Pre-deployment image generator script
└── models/             # Local GGUF model storage directory
```

## Quick Start Instructions

### Step 1: Pre-Build (On Internet-Connected Machine)
Run the builder script to pull the Docker base layers and LLM weights:
```bash
chmod +x build_package.sh
./build_package.sh
```
This will produce `ollama_image.tar` and `agent_image.tar` in your directory.

### Step 2: Deployment (On Air-Gapped Target Laptop)
Copy the entire folder (including the generated `.tar` files) to a USB drive or local disk on the target machine.

* **Linux / macOS:**
  ```bash
  chmod +x deploy.sh
  ./deploy.sh
  ```
* **Windows:**
  Double-click `deploy.bat` or run it via Command Prompt.
