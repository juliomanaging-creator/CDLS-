@echo off
TITLE Airgap Agent Windows Deployment Script
echo ==================================================
echo   Airgap Autonomous Agent Windows Deployment
echo ==================================================

echo [1/4] Loading Docker image archives...
if exist ollama_image.tar docker load -i ollama_image.tar
if exist agent_image.tar docker load -i agent_image.tar

echo [2/4] Launching Ollama LLM Container...
docker stop ollama-server >nul 2>&1
docker rm ollama-server >nul 2>&1
docker run -d --name ollama-server -v %cd%\models:/root/.ollama -p 11434:11434 ollama/ollama:latest

echo [3/4] Waiting for engine warmup (10s)...
timeout /t 10 /nobreak >nul

echo [4/4] Starting Agent Interface...
docker run -it --rm --name airgap-agent-cli --network="host" my-airgap-agent:v1

pause
