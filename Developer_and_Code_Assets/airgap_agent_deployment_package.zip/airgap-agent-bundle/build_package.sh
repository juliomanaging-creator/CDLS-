#!/bin/bash
# Run this on an internet-connected build host to generate the .tar files
set -e

echo "🛠️ Pulling LLM Engine and pre-loading Phi-3 model..."
docker pull ollama/ollama:latest

docker run -d --name temp-ollama -p 11434:11434 ollama/ollama:latest
sleep 5
docker exec temp-ollama ollama pull phi3:mini
docker stop temp-ollama && docker rm temp-ollama

echo "📦 Exporting image archives for air-gapped deployment..."
docker save ollama/ollama:latest -o ollama_image.tar

docker build -t my-airgap-agent:v1 .
docker save my-airgap-agent:v1 -o agent_image.tar

echo "✅ Package built! Transfer this directory to your USB/target drive."
