import requests
import json
import sys
import time

class PortableAirgapAgent:
    def __init__(self, base_url="http://127.0.0.1:11434", model="phi3:mini"):
        self.base_url = base_url
        self.model = model
        self.history = []

    def verify_engine(self):
        """Check if local LLM server is reachable before executing calls."""
        try:
            res = requests.get(f"{self.base_url}/api/tags", timeout=3)
            return res.status_code == 200
        except Exception:
            return False

    def chat(self, prompt, system_prompt="You are a helpful offline assistant."):
        if not prompt.strip():
            return "Prompt cannot be empty."

        url = f"{self.base_url}/api/chat"
        
        # Build message history for conversational context
        messages = [{"role": "system", "content": system_prompt}]
        for user_msg, assistant_msg in self.history:
            messages.append({"role": "user", "content": user_msg})
            messages.append({"role": "assistant", "content": assistant_msg})
        messages.append({"role": "user", "content": prompt})

        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": 0.3,
                "top_p": 0.9
            }
        }

        try:
            response = requests.post(url, json=payload, timeout=60)
            if response.status_code == 200:
                answer = response.json().get("message", {}).get("content", "No response.")
                self.history.append((prompt, answer))
                return answer
            else:
                return f"[Error] Engine returned HTTP {response.status_code}: {response.text}"
        except requests.exceptions.ConnectionError:
            return "[Error] Cannot reach LLM Engine. Verify Ollama container is running on 11434."
        except Exception as e:
            return f"[Error] Execution failure: {str(e)}"

if __name__ == "__main__":
    agent = PortableAirgapAgent()
    print("==================================================")
    print("   AIR-GAPPED AUTONOMOUS AGENT INTERFACE READY   ")
    print("==================================================")
    
    if not agent.verify_engine():
        print("[Warning] Ollama host is not responding. Please launch LLM server first.")
        
    while True:
        try:
            user_input = input("\nUser > ")
            if user_input.lower() in ['exit', 'quit']:
                print("Shutting down session.")
                break
            print("\nAgent > ", end="", flush=True)
            reply = agent.chat(user_input)
            print(reply)
        except KeyboardInterrupt:
            print("\nSession interrupted.")
            sys.exit(0)
