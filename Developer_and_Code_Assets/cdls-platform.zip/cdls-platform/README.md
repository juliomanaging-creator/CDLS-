# CA Dealer Logistics Syndicate (CDLS) Platform

A comprehensive enterprise sales enablement platform designed for the California dealer logistics industry, combining digital deal rooms, engagement analytics, ROI calculators, stakeholder mapping, and mutual action plans.

## 🎯 Platform Overview

The CDLS Platform enables California auto dealers to:
- **Raise capital** from institutional investors (CalPERS, sovereign wealth funds)
- **Demonstrate ROI** through interactive calculators showing $400-600/vehicle savings
- **Track engagement** across all stakeholder interactions
- **Manage deals** with collaborative action plans
- **Build relationships** with visual stakeholder mapping

## 🏗️ Architecture

```
cdls-platform/
├── backend/                 # Node.js/Express API
│   ├── src/
│   │   ├── config/          # Environment configuration
│   │   ├── middleware/      # Security middleware
│   │   ├── modules/         # Feature modules
│   │   │   ├── dealRooms.js
│   │   │   ├── engagementAnalytics.js
│   │   │   ├── roiCalculators.js
│   │   │   ├── stakeholderMapping.js
│   │   │   └── mutualActionPlans.js
│   │   ├── utils/           # Database utilities
│   │   └── app.js           # Application entry
│   └── package.json
├── frontend/                # React/Vite SPA
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── hooks/           # Custom hooks
│   │   ├── services/        # API client
│   │   └── utils/           # Utilities
│   └── package.json
├── database/
│   └── migrations/          # SQL migrations
├── SECURITY.md              # Security documentation
└── README.md
```

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL 14+
- AWS S3 bucket (for documents)

### Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env with your configuration

# Run database migrations
npm run migrate

# Start development server
npm run dev
```

### Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

## 📦 Core Modules

### 1. Digital Deal Rooms
Secure, branded portals for investor relationships.

**Features:**
- Document library with version control
- Role-based access (owner, admin, contributor, viewer)
- Secure share links with expiration and passwords
- Audit trail for all activities

**API Endpoints:**
```
POST   /api/v1/deal-rooms           # Create deal room
GET    /api/v1/deal-rooms           # List deal rooms
GET    /api/v1/deal-rooms/:id       # Get deal room details
PATCH  /api/v1/deal-rooms/:id       # Update deal room
DELETE /api/v1/deal-rooms/:id       # Delete deal room
```

### 2. Engagement Analytics
Track the "95% blindspot" between meetings.

**Features:**
- Real-time event tracking
- Document heatmaps
- Engagement scoring (0-100)
- Stakeholder activity alerts
- Champion/Blocker identification

**Key Metrics:**
- Document views and time spent
- Page scroll depth
- Calculator usage
- Share and download counts

### 3. Interactive ROI Calculators
Demonstrate value with data-driven projections.

**Built-in Templates:**
- **Fleet Economics** - Diesel vs EV cost comparison
- **Syndicate Savings** - Third-party hauler vs syndicate costs
- **EV Transition** - CARB compliance ROI

**Features:**
- Scenario comparison
- Shareable calculations
- Secure calculation engine (no eval/code injection)

### 4. Stakeholder Mapping
Visualize and manage deal participants.

**Features:**
- Visual org charts
- Influence/Sentiment matrix
- Relationship mapping
- Interaction logging
- Champion identification (+68% stakeholder involvement)

### 5. Mutual Action Plans
Collaborative deal timelines with both parties.

**Features:**
- Milestone tracking
- Task dependencies
- Owner assignment (seller/buyer)
- Progress analytics
- Shareable with buyers

## 🔐 Security

See [SECURITY.md](./SECURITY.md) for comprehensive security documentation.

### Key Security Features
- JWT authentication with refresh tokens
- Role-based access control (RBAC)
- Input validation (Joi schemas)
- SQL injection prevention (parameterized queries)
- XSS protection (sanitization + CSP)
- Rate limiting (tiered by endpoint)
- Audit logging
- Encrypted document storage (S3 + AES-256)

## 🧪 Testing

```bash
# Backend tests
cd backend
npm test              # Run all tests
npm run test:watch    # Watch mode
npm run test:coverage # Coverage report

# Frontend tests
cd frontend
npm test
npm run test:coverage
```

## 📊 Database Schema

Key entities:
- `organizations` - Dealers, investors, partners
- `users` - Platform users with roles
- `deal_rooms` - Deal containers
- `documents` - Uploaded files
- `engagement_events` - Analytics data
- `stakeholders` - Deal participants
- `action_plans` - Deal milestones and tasks

See `database/migrations/001_initial_schema.sql` for complete schema.

## 🔧 Configuration

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `NODE_ENV` | Environment (development/staging/production) | Yes |
| `DATABASE_URL` | PostgreSQL connection string | Yes |
| `JWT_SECRET` | JWT signing secret (32+ chars) | Yes |
| `AWS_ACCESS_KEY_ID` | AWS credentials | Yes |
| `AWS_SECRET_ACCESS_KEY` | AWS credentials | Yes |
| `AWS_S3_BUCKET` | S3 bucket for documents | Yes |
| `CORS_ORIGINS` | Allowed origins (comma-separated) | Yes |

## 📈 Industry Context

### Target Market
- California new car dealers (1,200+)
- Average fleet: 50-200 vehicles per dealership
- Current logistics spend: $1.05/mile (third-party)

### Value Proposition
- 25-35% cost reduction vs third-party haulers
- CARB 2024/2035 compliance pathway
- Technology-enabled investor engagement
- Data-driven ROI demonstration

### Key Stakeholders
- **Brian Maas** - CNCDA President (12+ years)
- **Tony Callaway** - South Bay Auto Auction VP
- **Chuck Tapp** - America's Auto Auction CEO

## 🗺️ Roadmap

### Phase 1 (Months 1-4)
- [x] Digital deal rooms
- [x] Basic ROI calculator
- [x] Engagement tracking

### Phase 2 (Months 5-8)
- [x] Stakeholder mapping
- [x] AI engagement signals
- [x] Mutual action plans

### Phase 3 (Months 9-12)
- [ ] Fleet management integration
- [ ] Auction APIs
- [ ] Mobile application

## 📝 License

Proprietary - All rights reserved.

## 👥 Team

CDLS Platform Team

---

*For support, please contact the development team.*
