# CDLS Platform - Setup Guide & Next Steps

## 📋 Quick Checklist

Before running the platform, you need:

- [ ] Node.js 18+ installed
- [ ] PostgreSQL 14+ installed and running
- [ ] AWS account with S3 bucket (or use local storage for dev)
- [ ] Git for version control

---

## 🚀 Step-by-Step Setup

### Step 1: Download the Project Files

Export the project from Claude to your local machine:

```bash
# Create project directory
mkdir -p ~/projects/cdls-platform
cd ~/projects/cdls-platform

# Copy all files from the Claude session or download the zip
```

**Project structure you should have:**
```
cdls-platform/
├── backend/
│   ├── src/
│   │   ├── app.js
│   │   ├── config/
│   │   ├── middleware/
│   │   ├── modules/
│   │   └── utils/
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── hooks/
│   │   └── services/
│   └── package.json
├── database/
│   ├── migrations/
│   └── seeds/
├── docker-compose.yml
├── README.md
├── SECURITY.md
└── SETUP_GUIDE.md (this file)
```

---

### Step 2: Set Up PostgreSQL Database

**Option A: Using Docker (Recommended for development)**

```bash
# Start PostgreSQL with Docker
docker run --name cdls-postgres \
  -e POSTGRES_USER=cdls_user \
  -e POSTGRES_PASSWORD=cdls_password \
  -e POSTGRES_DB=cdls_platform \
  -p 5432:5432 \
  -d postgres:14

# Verify it's running
docker ps
```

**Option B: Local PostgreSQL Installation**

```bash
# macOS with Homebrew
brew install postgresql@14
brew services start postgresql@14

# Create database and user
psql postgres
CREATE USER cdls_user WITH PASSWORD 'cdls_password';
CREATE DATABASE cdls_platform OWNER cdls_user;
GRANT ALL PRIVILEGES ON DATABASE cdls_platform TO cdls_user;
\q
```

**Option C: Use docker-compose (includes all services)**

```bash
cd cdls-platform
docker-compose up -d postgres
```

---

### Step 3: Configure Environment Variables

```bash
cd backend

# Copy the example file
cp .env.example .env

# Edit with your settings
nano .env  # or use your preferred editor
```

**Minimum required changes in `.env`:**

```bash
# Database - update with your credentials
DATABASE_URL=postgresql://cdls_user:cdls_password@localhost:5432/cdls_platform

# Generate new secrets (run these commands and paste results)
# JWT_SECRET:
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# REFRESH_TOKEN_SECRET:
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# ENCRYPTION_KEY (exactly 32 chars):
node -e "console.log(require('crypto').randomBytes(16).toString('hex'))"
```

---

### Step 4: Install Dependencies

```bash
# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install
```

---

### Step 5: Run Database Migrations

```bash
cd backend

# Run the migration
psql -U cdls_user -d cdls_platform -f ../database/migrations/001_initial_schema.sql

# Or if you have node-pg-migrate configured:
npm run migrate
```

**Verify migration:**
```bash
psql -U cdls_user -d cdls_platform -c "\dt"
# Should show: organizations, users, deal_rooms, documents, etc.
```

---

### Step 6: Seed Sample Data (Optional)

```bash
cd backend
npm run seed

# Or manually:
psql -U cdls_user -d cdls_platform -f ../database/seeds/001_sample_data.sql
```

---

### Step 7: Start the Application

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev

# Should see:
# ╔════════════════════════════════════════════════════════════╗
# ║           CDLS Platform API Server Started                 ║
# ╠════════════════════════════════════════════════════════════╣
# ║  Environment: development                                  ║
# ║  Port: 3001                                                ║
# ╚════════════════════════════════════════════════════════════╝
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev

# Should see:
# VITE v5.x.x ready in xxx ms
# ➜ Local: http://localhost:5173/
```

---

### Step 8: Test the API

```bash
# Health check
curl http://localhost:3001/health

# Expected response:
# {"status":"healthy","timestamp":"...","version":"1.0.0"}

# Ready check (verifies database)
curl http://localhost:3001/ready

# Expected response:
# {"status":"ready","database":"connected","timestamp":"..."}
```

---

## 🔧 Updating Existing Files

If you have existing files from a previous session, here's how to merge:

### Backend Files to Update/Add

| File | Action | Description |
|------|--------|-------------|
| `src/modules/mutualActionPlans.js` | **NEW** | Module 5 - Action Plans |
| `src/modules/dealRooms.js` | Verify | Digital Deal Rooms |
| `src/modules/engagementAnalytics.js` | Verify | Engagement tracking |
| `src/modules/roiCalculators.js` | Verify | ROI calculations |
| `src/modules/stakeholderMapping.js` | Verify | Stakeholder management |
| `src/middleware/security.js` | Verify | Security middleware |
| `src/config/index.js` | Verify | Configuration |
| `src/utils/database.js` | Verify | Database utilities |
| `src/app.js` | Verify | Main application |

### Frontend Files to Update/Add

| File | Action | Description |
|------|--------|-------------|
| `src/components/DealRoom.jsx` | **NEW** | Deal room UI |
| `src/components/StakeholderMap.jsx` | **NEW** | Stakeholder visualization |
| `src/components/MutualActionPlan.jsx` | **NEW** | Action plan UI |
| `src/components/EngagementDashboard.jsx` | Verify | Analytics dashboard |
| `src/components/ROICalculator.jsx` | Verify | Calculator UI |
| `src/services/api.js` | Verify | API client |
| `src/hooks/useAuth.jsx` | Verify | Auth hook |

### Merge Strategy

```bash
# 1. Backup your existing project
cp -r cdls-platform cdls-platform-backup

# 2. Compare files
diff -r cdls-platform-backup/backend/src cdls-platform/backend/src

# 3. Copy new files
cp cdls-platform/backend/src/modules/mutualActionPlans.js \
   cdls-platform-backup/backend/src/modules/

cp cdls-platform/frontend/src/components/*.jsx \
   cdls-platform-backup/frontend/src/components/
```

---

## 🐳 Docker Deployment (Production-Ready)

```bash
# Build and run all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

The `docker-compose.yml` includes:
- PostgreSQL database
- Backend API
- Frontend (Nginx)
- Redis (for sessions/caching)

---

## ✅ Verification Checklist

After setup, verify each component:

### Database
```bash
psql -U cdls_user -d cdls_platform -c "SELECT COUNT(*) FROM organizations;"
```

### Backend API
```bash
# Health
curl http://localhost:3001/health

# API endpoints (will return 401 without auth)
curl http://localhost:3001/api/v1/deal-rooms
```

### Frontend
- Open http://localhost:5173
- Should see the login page or dashboard

---

## 🔒 Security Reminders

Before going to production:

1. **Change all secrets** in `.env`
2. **Enable HTTPS** (use nginx or load balancer)
3. **Restrict CORS** to your domain only
4. **Enable database SSL** (`DB_SSL=true`)
5. **Set up AWS IAM roles** instead of access keys
6. **Review SECURITY.md** for full checklist

---

## 🐛 Common Issues

### Port Already in Use
```bash
# Find process using port 3001
lsof -i :3001
kill -9 <PID>
```

### Database Connection Failed
```bash
# Check PostgreSQL is running
pg_isready -h localhost -p 5432

# Check connection string
psql "postgresql://cdls_user:cdls_password@localhost:5432/cdls_platform"
```

### Module Not Found
```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### CORS Errors
- Verify `CORS_ORIGINS` in `.env` includes your frontend URL
- Check browser console for specific origin errors

---

## 📞 Next Development Steps

1. **Add Authentication UI** - Login/Register pages
2. **Connect Frontend to API** - Wire up all components
3. **Add Tests** - Unit and integration tests
4. **Set Up CI/CD** - GitHub Actions or similar
5. **Deploy to Staging** - AWS, GCP, or Heroku

---

## 📁 File Download

To download all project files from this session:

1. Use the **Present Files** feature in Claude
2. Or copy files individually using the file viewer
3. Or request a zip archive

Need help with any specific step? Just ask!
