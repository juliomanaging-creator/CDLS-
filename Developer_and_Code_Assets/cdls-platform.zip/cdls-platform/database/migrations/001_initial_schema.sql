-- CDLS Platform Database Schema
-- Security Review: UUID primary keys, proper indexing, audit trails, RLS-ready

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- CORE TABLES
-- ============================================

-- Organizations (Dealers, Investors, Partners)
CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL CHECK (type IN ('dealer', 'investor', 'partner', 'internal')),
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
    settings JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID,
    
    CONSTRAINT org_name_not_empty CHECK (LENGTH(TRIM(name)) > 0)
);

CREATE INDEX idx_organizations_type ON organizations(type);
CREATE INDEX idx_organizations_status ON organizations(status);

-- Users
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    role VARCHAR(50) NOT NULL DEFAULT 'member' CHECK (role IN ('admin', 'manager', 'member', 'viewer')),
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'pending')),
    last_login_at TIMESTAMP WITH TIME ZONE,
    failed_login_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMP WITH TIME ZONE,
    mfa_enabled BOOLEAN DEFAULT FALSE,
    mfa_secret VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT email_format CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
    CONSTRAINT unique_email UNIQUE (email)
);

CREATE INDEX idx_users_org_id ON users(org_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- ============================================
-- MODULE 1: DIGITAL DEAL ROOMS
-- ============================================

CREATE TABLE deal_rooms (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    investor_org_id UUID REFERENCES organizations(id),
    stage VARCHAR(50) NOT NULL DEFAULT 'prospect' 
        CHECK (stage IN ('prospect', 'qualification', 'due_diligence', 'negotiation', 'closing', 'closed_won', 'closed_lost')),
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived', 'deleted')),
    branding JSONB DEFAULT '{}',
    settings JSONB DEFAULT '{}',
    deal_value DECIMAL(15, 2),
    expected_close_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    
    CONSTRAINT deal_room_name_not_empty CHECK (LENGTH(TRIM(name)) > 0)
);

CREATE INDEX idx_deal_rooms_org_id ON deal_rooms(org_id);
CREATE INDEX idx_deal_rooms_stage ON deal_rooms(stage);
CREATE INDEX idx_deal_rooms_status ON deal_rooms(status);
CREATE INDEX idx_deal_rooms_investor ON deal_rooms(investor_org_id);

-- Deal Room Members (Access Control)
CREATE TABLE deal_room_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    deal_room_id UUID NOT NULL REFERENCES deal_rooms(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role VARCHAR(50) NOT NULL DEFAULT 'viewer' CHECK (role IN ('owner', 'admin', 'contributor', 'viewer')),
    permissions JSONB DEFAULT '{"view": true, "upload": false, "delete": false, "invite": false}',
    invited_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    accepted_at TIMESTAMP WITH TIME ZONE,
    invited_by UUID REFERENCES users(id),
    
    CONSTRAINT unique_deal_room_member UNIQUE (deal_room_id, user_id)
);

CREATE INDEX idx_deal_room_members_room ON deal_room_members(deal_room_id);
CREATE INDEX idx_deal_room_members_user ON deal_room_members(user_id);

-- Documents
CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    deal_room_id UUID NOT NULL REFERENCES deal_rooms(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    file_size BIGINT NOT NULL,
    s3_key VARCHAR(500) NOT NULL,
    s3_bucket VARCHAR(100) NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    folder_path VARCHAR(500) DEFAULT '/',
    description TEXT,
    is_confidential BOOLEAN DEFAULT FALSE,
    watermark_enabled BOOLEAN DEFAULT FALSE,
    download_count INTEGER DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived', 'deleted')),
    checksum VARCHAR(64), -- SHA-256 hash for integrity verification
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    uploaded_by UUID REFERENCES users(id),
    
    CONSTRAINT document_name_not_empty CHECK (LENGTH(TRIM(name)) > 0),
    CONSTRAINT file_size_positive CHECK (file_size > 0)
);

CREATE INDEX idx_documents_deal_room ON documents(deal_room_id);
CREATE INDEX idx_documents_folder ON documents(folder_path);
CREATE INDEX idx_documents_type ON documents(file_type);

-- Document Versions (for version history)
CREATE TABLE document_versions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    version_number INTEGER NOT NULL,
    s3_key VARCHAR(500) NOT NULL,
    file_size BIGINT NOT NULL,
    checksum VARCHAR(64),
    change_summary TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    
    CONSTRAINT unique_doc_version UNIQUE (document_id, version_number)
);

CREATE INDEX idx_doc_versions_document ON document_versions(document_id);

-- Share Links (secure document sharing)
CREATE TABLE share_links (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    deal_room_id UUID REFERENCES deal_rooms(id) ON DELETE CASCADE,
    token VARCHAR(64) NOT NULL UNIQUE,
    password_hash VARCHAR(255),
    expires_at TIMESTAMP WITH TIME ZONE,
    max_views INTEGER,
    view_count INTEGER DEFAULT 0,
    allow_download BOOLEAN DEFAULT TRUE,
    recipient_email VARCHAR(255),
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'expired', 'revoked')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    
    CONSTRAINT share_link_target CHECK (document_id IS NOT NULL OR deal_room_id IS NOT NULL)
);

CREATE INDEX idx_share_links_token ON share_links(token);
CREATE INDEX idx_share_links_document ON share_links(document_id);

-- ============================================
-- MODULE 2: ENGAGEMENT ANALYTICS
-- ============================================

CREATE TABLE engagement_events (
    id BIGSERIAL PRIMARY KEY,
    deal_room_id UUID NOT NULL REFERENCES deal_rooms(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    session_id VARCHAR(64),
    event_type VARCHAR(50) NOT NULL 
        CHECK (event_type IN ('page_view', 'document_view', 'document_download', 'time_spent', 
                              'scroll_depth', 'section_view', 'calculator_use', 'share', 'comment')),
    entity_type VARCHAR(50) CHECK (entity_type IN ('deal_room', 'document', 'section', 'calculator', 'page')),
    entity_id UUID,
    metadata JSONB DEFAULT '{}',
    duration_seconds INTEGER,
    scroll_percentage INTEGER CHECK (scroll_percentage BETWEEN 0 AND 100),
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Partition by month for performance
CREATE INDEX idx_engagement_events_deal_room ON engagement_events(deal_room_id);
CREATE INDEX idx_engagement_events_user ON engagement_events(user_id);
CREATE INDEX idx_engagement_events_type ON engagement_events(event_type);
CREATE INDEX idx_engagement_events_created ON engagement_events(created_at);
CREATE INDEX idx_engagement_events_session ON engagement_events(session_id);

-- Engagement Scores (computed daily)
CREATE TABLE engagement_scores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    deal_room_id UUID NOT NULL REFERENCES deal_rooms(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    score_date DATE NOT NULL DEFAULT CURRENT_DATE,
    overall_score INTEGER NOT NULL CHECK (overall_score BETWEEN 0 AND 100),
    view_score INTEGER DEFAULT 0,
    time_score INTEGER DEFAULT 0,
    interaction_score INTEGER DEFAULT 0,
    recency_score INTEGER DEFAULT 0,
    trend VARCHAR(20) CHECK (trend IN ('rising', 'stable', 'declining')),
    details JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_daily_score UNIQUE (deal_room_id, user_id, score_date)
);

CREATE INDEX idx_engagement_scores_deal_room ON engagement_scores(deal_room_id);
CREATE INDEX idx_engagement_scores_date ON engagement_scores(score_date);

-- Document Heatmaps
CREATE TABLE document_heatmaps (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    page_number INTEGER NOT NULL,
    section_id VARCHAR(100),
    view_count INTEGER DEFAULT 0,
    total_time_seconds INTEGER DEFAULT 0,
    avg_scroll_depth INTEGER DEFAULT 0,
    heatmap_data JSONB DEFAULT '{}',
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_heatmap_period UNIQUE (document_id, page_number, period_start)
);

CREATE INDEX idx_heatmaps_document ON document_heatmaps(document_id);

-- Engagement Alerts
CREATE TABLE engagement_alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    deal_room_id UUID NOT NULL REFERENCES deal_rooms(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    alert_type VARCHAR(50) NOT NULL 
        CHECK (alert_type IN ('high_engagement', 'engagement_spike', 'key_document_viewed', 
                              'repeat_visitor', 'engagement_drop', 'new_stakeholder')),
    severity VARCHAR(20) DEFAULT 'info' CHECK (severity IN ('info', 'warning', 'critical')),
    title VARCHAR(255) NOT NULL,
    message TEXT,
    metadata JSONB DEFAULT '{}',
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_alerts_deal_room ON engagement_alerts(deal_room_id);
CREATE INDEX idx_alerts_unread ON engagement_alerts(is_read) WHERE is_read = FALSE;

-- ============================================
-- MODULE 3: ROI CALCULATORS
-- ============================================

CREATE TABLE calculator_templates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL CHECK (type IN ('fleet_economics', 'ev_transition', 'syndicate_savings', 'custom')),
    version INTEGER NOT NULL DEFAULT 1,
    input_schema JSONB NOT NULL,
    calculation_logic JSONB NOT NULL,
    output_schema JSONB NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_public BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE INDEX idx_calc_templates_org ON calculator_templates(org_id);
CREATE INDEX idx_calc_templates_type ON calculator_templates(type);

CREATE TABLE calculator_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    template_id UUID NOT NULL REFERENCES calculator_templates(id) ON DELETE CASCADE,
    deal_room_id UUID REFERENCES deal_rooms(id) ON DELETE SET NULL,
    user_id UUID REFERENCES users(id),
    session_name VARCHAR(255),
    inputs JSONB NOT NULL DEFAULT '{}',
    outputs JSONB DEFAULT '{}',
    is_shared BOOLEAN DEFAULT FALSE,
    share_token UUID,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_calc_sessions_template ON calculator_sessions(template_id);
CREATE INDEX idx_calc_sessions_deal_room ON calculator_sessions(deal_room_id);
CREATE INDEX idx_calc_sessions_share_token ON calculator_sessions(share_token);

CREATE TABLE calculator_scenarios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id UUID NOT NULL REFERENCES calculator_sessions(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    inputs JSONB NOT NULL,
    outputs JSONB NOT NULL,
    is_baseline BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE INDEX idx_calc_scenarios_session ON calculator_scenarios(session_id);

-- ============================================
-- MODULE 4: STAKEHOLDER MAPPING
-- ============================================

CREATE TABLE stakeholders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    deal_room_id UUID NOT NULL REFERENCES deal_rooms(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    external_contact_id UUID,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(50),
    title VARCHAR(200),
    department VARCHAR(200),
    company VARCHAR(255),
    role_type VARCHAR(50) CHECK (role_type IN ('decision_maker', 'influencer', 'champion', 'blocker', 'end_user', 'unknown')),
    influence_level INTEGER CHECK (influence_level BETWEEN 1 AND 5),
    engagement_level INTEGER CHECK (engagement_level BETWEEN 1 AND 5),
    sentiment VARCHAR(20) CHECK (sentiment IN ('positive', 'neutral', 'negative', 'unknown')),
    linkedin_url VARCHAR(500),
    notes TEXT,
    avatar_url VARCHAR(500),
    is_primary_contact BOOLEAN DEFAULT FALSE,
    last_contact_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE INDEX idx_stakeholders_deal_room ON stakeholders(deal_room_id);
CREATE INDEX idx_stakeholders_role_type ON stakeholders(role_type);
CREATE INDEX idx_stakeholders_email ON stakeholders(email);

-- Stakeholder Relationships (org chart connections)
CREATE TABLE stakeholder_relationships (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    deal_room_id UUID NOT NULL REFERENCES deal_rooms(id) ON DELETE CASCADE,
    from_stakeholder_id UUID NOT NULL REFERENCES stakeholders(id) ON DELETE CASCADE,
    to_stakeholder_id UUID NOT NULL REFERENCES stakeholders(id) ON DELETE CASCADE,
    relationship_type VARCHAR(50) NOT NULL 
        CHECK (relationship_type IN ('reports_to', 'manages', 'collaborates', 'influences', 'advises')),
    strength INTEGER CHECK (strength BETWEEN 1 AND 5),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT no_self_relationship CHECK (from_stakeholder_id != to_stakeholder_id),
    CONSTRAINT unique_relationship UNIQUE (from_stakeholder_id, to_stakeholder_id, relationship_type)
);

CREATE INDEX idx_stakeholder_rels_from ON stakeholder_relationships(from_stakeholder_id);
CREATE INDEX idx_stakeholder_rels_to ON stakeholder_relationships(to_stakeholder_id);

-- Stakeholder Interactions
CREATE TABLE stakeholder_interactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    stakeholder_id UUID NOT NULL REFERENCES stakeholders(id) ON DELETE CASCADE,
    deal_room_id UUID NOT NULL REFERENCES deal_rooms(id) ON DELETE CASCADE,
    interaction_type VARCHAR(50) NOT NULL 
        CHECK (interaction_type IN ('email', 'call', 'meeting', 'document_view', 'calculator_use', 'comment', 'other')),
    subject VARCHAR(255),
    summary TEXT,
    sentiment VARCHAR(20) CHECK (sentiment IN ('positive', 'neutral', 'negative')),
    outcome VARCHAR(100),
    next_steps TEXT,
    interaction_date TIMESTAMP WITH TIME ZONE NOT NULL,
    duration_minutes INTEGER,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE INDEX idx_stakeholder_interactions_stakeholder ON stakeholder_interactions(stakeholder_id);
CREATE INDEX idx_stakeholder_interactions_date ON stakeholder_interactions(interaction_date);

-- ============================================
-- MODULE 5: MUTUAL ACTION PLANS
-- ============================================

CREATE TABLE action_plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    deal_room_id UUID NOT NULL REFERENCES deal_rooms(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('draft', 'active', 'completed', 'cancelled')),
    target_close_date DATE,
    actual_close_date DATE,
    progress_percentage INTEGER DEFAULT 0 CHECK (progress_percentage BETWEEN 0 AND 100),
    is_shared_with_buyer BOOLEAN DEFAULT FALSE,
    shared_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE INDEX idx_action_plans_deal_room ON action_plans(deal_room_id);
CREATE INDEX idx_action_plans_status ON action_plans(status);

-- Milestones
CREATE TABLE milestones (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action_plan_id UUID NOT NULL REFERENCES action_plans(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    sequence_order INTEGER NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending' 
        CHECK (status IN ('pending', 'in_progress', 'completed', 'blocked', 'skipped')),
    due_date DATE,
    completed_date DATE,
    owner_type VARCHAR(20) CHECK (owner_type IN ('seller', 'buyer', 'both')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_milestones_action_plan ON milestones(action_plan_id);
CREATE INDEX idx_milestones_status ON milestones(status);

-- Action Items (tasks within milestones)
CREATE TABLE action_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    milestone_id UUID NOT NULL REFERENCES milestones(id) ON DELETE CASCADE,
    action_plan_id UUID NOT NULL REFERENCES action_plans(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'pending' 
        CHECK (status IN ('pending', 'in_progress', 'completed', 'blocked', 'cancelled')),
    priority VARCHAR(20) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
    owner_type VARCHAR(20) CHECK (owner_type IN ('seller', 'buyer')),
    assigned_to UUID REFERENCES users(id),
    stakeholder_id UUID REFERENCES stakeholders(id),
    due_date DATE,
    completed_date DATE,
    completed_by UUID REFERENCES users(id),
    sequence_order INTEGER NOT NULL,
    dependencies JSONB DEFAULT '[]',
    attachments JSONB DEFAULT '[]',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE INDEX idx_action_items_milestone ON action_items(milestone_id);
CREATE INDEX idx_action_items_assigned ON action_items(assigned_to);
CREATE INDEX idx_action_items_status ON action_items(status);
CREATE INDEX idx_action_items_due_date ON action_items(due_date);

-- Action Item Comments
CREATE TABLE action_item_comments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action_item_id UUID NOT NULL REFERENCES action_items(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id),
    content TEXT NOT NULL,
    is_internal BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_comments_action_item ON action_item_comments(action_item_id);

-- ============================================
-- AUDIT TRAIL
-- ============================================

CREATE TABLE audit_logs (
    id BIGSERIAL PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    org_id UUID REFERENCES organizations(id),
    action VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    request_id VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at);

-- ============================================
-- TRIGGERS FOR UPDATED_AT
-- ============================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_organizations_updated_at BEFORE UPDATE ON organizations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_deal_rooms_updated_at BEFORE UPDATE ON deal_rooms FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_stakeholders_updated_at BEFORE UPDATE ON stakeholders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_action_plans_updated_at BEFORE UPDATE ON action_plans FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_milestones_updated_at BEFORE UPDATE ON milestones FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_action_items_updated_at BEFORE UPDATE ON action_items FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
