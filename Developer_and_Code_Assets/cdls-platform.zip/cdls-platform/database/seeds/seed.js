/**
 * CDLS Platform - Database Seed Data
 * Run with: npm run seed
 */

const { Pool } = require('pg');
const crypto = require('crypto');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Helper to hash passwords (matching the app's method)
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

async function seed() {
  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');
    
    console.log('🌱 Starting database seed...\n');

    // =========================================
    // 1. CREATE ORGANIZATIONS
    // =========================================
    console.log('Creating organizations...');
    
    const orgs = await client.query(`
      INSERT INTO organizations (name, type, website, address, city, state, zip_code) VALUES
      ('CA Dealer Logistics Syndicate', 'dealer_group', 'https://cdls-platform.com', '1234 Auto Row', 'Sacramento', 'CA', '95814'),
      ('South Bay Auto Auction', 'auction', 'https://southbayauto.com', '5678 Auction Blvd', 'San Jose', 'CA', '95112'),
      ('CalPERS Investment Fund', 'investor', 'https://calpers.ca.gov', '400 Q Street', 'Sacramento', 'CA', '95811'),
      ('Sierra Nevada Dealership Group', 'dealer_group', NULL, '900 Auto Plaza', 'Reno', 'NV', '89501'),
      ('Pacific Coast Fleet Services', 'logistics', NULL, '2000 Harbor Dr', 'Long Beach', 'CA', '90802')
      RETURNING id, name
    `);
    
    const orgMap = {};
    orgs.rows.forEach(org => {
      orgMap[org.name] = org.id;
    });
    console.log(`  ✓ Created ${orgs.rows.length} organizations\n`);

    // =========================================
    // 2. CREATE USERS
    // =========================================
    console.log('Creating users...');
    
    const defaultPassword = hashPassword('Demo123!@#');
    
    const users = await client.query(`
      INSERT INTO users (org_id, email, password_hash, first_name, last_name, role, is_active) VALUES
      ($1, 'admin@cdls-platform.com', $7, 'System', 'Admin', 'admin', true),
      ($1, 'brian.maas@cncda.org', $7, 'Brian', 'Maas', 'admin', true),
      ($2, 'tony.callaway@southbayauto.com', $7, 'Tony', 'Callaway', 'manager', true),
      ($3, 'investments@calpers.ca.gov', $7, 'Investment', 'Team', 'viewer', true),
      ($4, 'deals@sierranevada.com', $7, 'Deal', 'Manager', 'member', true),
      ($5, 'ops@pacificfleet.com', $7, 'Operations', 'Lead', 'member', true)
      RETURNING id, email, org_id
    `, [
      orgMap['CA Dealer Logistics Syndicate'],
      orgMap['South Bay Auto Auction'],
      orgMap['CalPERS Investment Fund'],
      orgMap['Sierra Nevada Dealership Group'],
      orgMap['Pacific Coast Fleet Services'],
      orgMap['CA Dealer Logistics Syndicate'],
      defaultPassword
    ]);
    
    const userMap = {};
    users.rows.forEach(user => {
      userMap[user.email] = user.id;
    });
    console.log(`  ✓ Created ${users.rows.length} users\n`);

    // =========================================
    // 3. CREATE DEAL ROOMS
    // =========================================
    console.log('Creating deal rooms...');
    
    const dealRooms = await client.query(`
      INSERT INTO deal_rooms (
        org_id, name, description, stage, deal_value, 
        primary_contact_name, primary_contact_email, created_by
      ) VALUES
      ($1, 'CalPERS Series A Investment', 
       'Initial investment round for CDLS fleet syndication platform. Target: $50M for Phase 1 expansion.',
       'due_diligence', 50000000, 'Investment Committee', 'investments@calpers.ca.gov', $2),
      ($1, 'South Bay Auction Partnership', 
       'Strategic partnership for auction logistics and fleet management integration.',
       'negotiation', 15000000, 'Tony Callaway', 'tony.callaway@southbayauto.com', $2),
      ($1, 'Sierra Nevada Fleet Services', 
       'Regional expansion opportunity with Sierra Nevada dealer group.',
       'qualification', 8000000, 'Regional Manager', 'deals@sierranevada.com', $2),
      ($1, 'Pacific Coast Logistics Integration', 
       'Technology integration for existing fleet services provider.',
       'prospect', 5000000, 'Operations Lead', 'ops@pacificfleet.com', $2)
      RETURNING id, name
    `, [
      orgMap['CA Dealer Logistics Syndicate'],
      userMap['brian.maas@cncda.org']
    ]);
    
    const dealRoomMap = {};
    dealRooms.rows.forEach(dr => {
      dealRoomMap[dr.name] = dr.id;
    });
    console.log(`  ✓ Created ${dealRooms.rows.length} deal rooms\n`);

    // =========================================
    // 4. ADD DEAL ROOM MEMBERS
    // =========================================
    console.log('Adding deal room members...');
    
    await client.query(`
      INSERT INTO deal_room_members (deal_room_id, user_id, role, permissions) VALUES
      ($1, $5, 'owner', '{"view": true, "edit": true, "delete": true, "invite": true, "admin": true}'),
      ($1, $6, 'viewer', '{"view": true, "edit": false, "delete": false, "invite": false, "admin": false}'),
      ($2, $5, 'owner', '{"view": true, "edit": true, "delete": true, "invite": true, "admin": true}'),
      ($2, $7, 'contributor', '{"view": true, "edit": true, "delete": false, "invite": false, "admin": false}'),
      ($3, $5, 'owner', '{"view": true, "edit": true, "delete": true, "invite": true, "admin": true}'),
      ($4, $5, 'owner', '{"view": true, "edit": true, "delete": true, "invite": true, "admin": true}')
    `, [
      dealRoomMap['CalPERS Series A Investment'],
      dealRoomMap['South Bay Auction Partnership'],
      dealRoomMap['Sierra Nevada Fleet Services'],
      dealRoomMap['Pacific Coast Logistics Integration'],
      userMap['brian.maas@cncda.org'],
      userMap['investments@calpers.ca.gov'],
      userMap['tony.callaway@southbayauto.com']
    ]);
    console.log(`  ✓ Added deal room members\n`);

    // =========================================
    // 5. CREATE CALCULATOR TEMPLATES
    // =========================================
    console.log('Creating calculator templates...');
    
    await client.query(`
      INSERT INTO calculator_templates (org_id, name, description, category, input_schema, output_schema, calculation_logic, is_public, created_by) VALUES
      ($1, 'Fleet Economics Calculator', 
       'Compare diesel vs electric vehicle fleet costs over time',
       'fleet_economics',
       '{"fleetSize": {"type": "number", "label": "Fleet Size", "min": 1, "max": 10000}, "routeDistance": {"type": "number", "label": "Avg Route Distance (miles)", "min": 1, "max": 5000}, "tripsPerMonth": {"type": "number", "label": "Trips per Month", "min": 1, "max": 1000}, "dieselPrice": {"type": "number", "label": "Diesel Price ($/gal)", "min": 2, "max": 20}, "electricityPrice": {"type": "number", "label": "Electricity Price ($/kWh)", "min": 0.05, "max": 0.50}, "dieselMPG": {"type": "number", "label": "Diesel MPG", "min": 5, "max": 50}, "evKwhPerMile": {"type": "number", "label": "EV kWh/mile", "min": 0.1, "max": 2}, "projectionYears": {"type": "number", "label": "Projection Years", "min": 1, "max": 20}}',
       '{"annualDieselCost": {"type": "currency", "label": "Annual Diesel Cost"}, "annualEVCost": {"type": "currency", "label": "Annual EV Cost"}, "annualSavings": {"type": "currency", "label": "Annual Savings"}, "totalSavings": {"type": "currency", "label": "Total Savings"}, "co2Reduction": {"type": "number", "label": "CO2 Reduction (tons)"}}',
       '{"annualDieselCost": {"operation": "multiply", "operands": [{"operation": "divide", "operands": [{"operation": "multiply", "operands": ["fleetSize", "routeDistance", "tripsPerMonth", 12]}, "dieselMPG"]}, "dieselPrice"]}, "annualEVCost": {"operation": "multiply", "operands": ["fleetSize", "routeDistance", "tripsPerMonth", 12, "evKwhPerMile", "electricityPrice"]}, "annualSavings": {"operation": "subtract", "operands": ["annualDieselCost", "annualEVCost"]}, "totalSavings": {"operation": "multiply", "operands": ["annualSavings", "projectionYears"]}, "co2Reduction": {"operation": "multiply", "operands": [{"operation": "divide", "operands": [{"operation": "multiply", "operands": ["fleetSize", "routeDistance", "tripsPerMonth", 12]}, "dieselMPG"]}, 0.01018, "projectionYears"]}}',
       true, $2),
      ($1, 'Syndicate Savings Calculator',
       'Compare third-party hauler costs vs syndicate membership',
       'syndicate_savings',
       '{"fleetSize": {"type": "number", "label": "Fleet Size", "min": 1, "max": 10000}, "avgHaulDistance": {"type": "number", "label": "Avg Haul Distance (miles)", "min": 1, "max": 3000}, "haulsPerMonth": {"type": "number", "label": "Hauls per Month", "min": 1, "max": 500}, "currentRatePerMile": {"type": "number", "label": "Current Rate ($/mile)", "min": 0.50, "max": 3.00}, "syndicateSavingsPercent": {"type": "number", "label": "Syndicate Savings %", "min": 10, "max": 50}, "projectionYears": {"type": "number", "label": "Projection Years", "min": 1, "max": 10}}',
       '{"currentAnnualCost": {"type": "currency", "label": "Current Annual Cost"}, "syndicateAnnualCost": {"type": "currency", "label": "Syndicate Annual Cost"}, "annualSavings": {"type": "currency", "label": "Annual Savings"}, "totalSavings": {"type": "currency", "label": "Total Savings"}, "savingsPerHaul": {"type": "currency", "label": "Savings per Haul"}}',
       '{"currentAnnualCost": {"operation": "multiply", "operands": ["fleetSize", "avgHaulDistance", "haulsPerMonth", 12, "currentRatePerMile"]}, "syndicateAnnualCost": {"operation": "multiply", "operands": ["currentAnnualCost", {"operation": "subtract", "operands": [1, {"operation": "divide", "operands": ["syndicateSavingsPercent", 100]}]}]}, "annualSavings": {"operation": "subtract", "operands": ["currentAnnualCost", "syndicateAnnualCost"]}, "totalSavings": {"operation": "multiply", "operands": ["annualSavings", "projectionYears"]}, "savingsPerHaul": {"operation": "divide", "operands": ["annualSavings", {"operation": "multiply", "operands": ["fleetSize", "haulsPerMonth", 12]}]}}',
       true, $2)
    `, [
      orgMap['CA Dealer Logistics Syndicate'],
      userMap['brian.maas@cncda.org']
    ]);
    console.log(`  ✓ Created calculator templates\n`);

    // =========================================
    // 6. CREATE STAKEHOLDERS
    // =========================================
    console.log('Creating stakeholders...');
    
    const calpersDealRoom = dealRoomMap['CalPERS Series A Investment'];
    
    await client.query(`
      INSERT INTO stakeholders (
        deal_room_id, first_name, last_name, email, title, company,
        role_type, influence_level, engagement_level, sentiment, notes
      ) VALUES
      ($1, 'Marcie', 'Frost', 'mfrost@calpers.ca.gov', 'Chief Executive Officer', 'CalPERS',
       'decision_maker', 5, 2, 'neutral', 'Final approval authority. Focused on ESG initiatives.'),
      ($1, 'Nicole', 'Musicco', 'nmusicco@calpers.ca.gov', 'Chief Investment Officer', 'CalPERS',
       'decision_maker', 5, 3, 'positive', 'Strong advocate for infrastructure investments.'),
      ($1, 'Dan', 'Bienvenue', 'dbienvenue@calpers.ca.gov', 'Deputy CIO', 'CalPERS',
       'influencer', 4, 4, 'positive', 'Day-to-day contact. Very engaged with materials.'),
      ($1, 'Michael', 'Chen', 'mchen@calpers.ca.gov', 'Senior Investment Analyst', 'CalPERS',
       'champion', 4, 5, 'positive', 'Our internal champion. Presenting to committee next month.'),
      ($1, 'Sarah', 'Williams', 'swilliams@calpers.ca.gov', 'Risk Assessment Director', 'CalPERS',
       'blocker', 3, 3, 'negative', 'Concerned about fleet transition timeline. Needs more data on EV reliability.'),
      ($1, 'Robert', 'Taylor', 'rtaylor@calpers.ca.gov', 'Legal Counsel', 'CalPERS',
       'influencer', 3, 2, 'neutral', 'Reviewing partnership structure.')
    `, [calpersDealRoom]);
    console.log(`  ✓ Created stakeholders\n`);

    // =========================================
    // 7. CREATE ACTION PLAN
    // =========================================
    console.log('Creating action plan...');
    
    const actionPlan = await client.query(`
      INSERT INTO action_plans (
        deal_room_id, name, description, status, target_close_date, created_by
      ) VALUES (
        $1, 'CalPERS Series A Close Plan',
        'Mutual action plan to close Series A investment by Q2 2025',
        'active', '2025-06-30',
        $2
      ) RETURNING id
    `, [calpersDealRoom, userMap['brian.maas@cncda.org']]);
    
    const planId = actionPlan.rows[0].id;

    // Create milestones
    const milestones = await client.query(`
      INSERT INTO milestones (action_plan_id, name, description, sequence_order, status, due_date, owner_type) VALUES
      ($1, 'Initial Due Diligence', 'Complete financial and operational review', 0, 'completed', '2025-01-15', 'buyer'),
      ($1, 'Technical Assessment', 'Fleet technology and EV transition evaluation', 1, 'in_progress', '2025-02-28', 'both'),
      ($1, 'Legal Review', 'Partnership agreement and compliance review', 2, 'pending', '2025-03-31', 'both'),
      ($1, 'Investment Committee', 'Present to CalPERS investment committee', 3, 'pending', '2025-04-30', 'buyer'),
      ($1, 'Final Negotiation', 'Term sheet and final terms', 4, 'pending', '2025-05-31', 'both'),
      ($1, 'Close', 'Execute agreements and fund', 5, 'pending', '2025-06-30', 'both')
      RETURNING id, name, sequence_order
    `, [planId]);

    const milestoneMap = {};
    milestones.rows.forEach(m => {
      milestoneMap[m.sequence_order] = m.id;
    });

    // Create action items
    await client.query(`
      INSERT INTO action_items (
        milestone_id, action_plan_id, title, description, status, priority, 
        owner_type, sequence_order, created_by
      ) VALUES
      ($1, $7, 'Submit audited financials', 'Provide 3 years of audited financial statements', 'completed', 'high', 'seller', 0, $8),
      ($1, $7, 'Fleet inventory analysis', 'Complete inventory of current fleet assets', 'completed', 'high', 'seller', 1, $8),
      ($1, $7, 'Review financial package', 'CalPERS team to review submitted materials', 'completed', 'high', 'buyer', 2, $8),
      ($2, $7, 'EV transition roadmap', 'Develop detailed CARB compliance timeline', 'in_progress', 'critical', 'seller', 0, $8),
      ($2, $7, 'Technology demo', 'Schedule platform demonstration for tech team', 'in_progress', 'high', 'seller', 1, $8),
      ($2, $7, 'Site visits', 'Arrange visits to 3 dealer locations', 'pending', 'medium', 'both', 2, $8),
      ($3, $7, 'Draft partnership agreement', 'Legal team to draft initial agreement', 'pending', 'high', 'buyer', 0, $8),
      ($3, $7, 'CDLS legal review', 'Review and markup partnership terms', 'pending', 'high', 'seller', 1, $8),
      ($4, $7, 'Prepare investment memo', 'Create committee presentation materials', 'pending', 'critical', 'buyer', 0, $8),
      ($4, $7, 'Support materials', 'Provide any additional data requested', 'pending', 'high', 'seller', 1, $8),
      ($5, $7, 'Negotiate final terms', 'Finalize valuation and terms', 'pending', 'critical', 'both', 0, $8),
      ($6, $7, 'Execute agreements', 'Sign all closing documents', 'pending', 'critical', 'both', 0, $8),
      ($6, $7, 'Wire funds', 'Complete fund transfer', 'pending', 'critical', 'buyer', 1, $8)
    `, [
      milestoneMap[0], milestoneMap[1], milestoneMap[2], 
      milestoneMap[3], milestoneMap[4], milestoneMap[5],
      planId, userMap['brian.maas@cncda.org']
    ]);
    console.log(`  ✓ Created action plan with milestones and tasks\n`);

    // =========================================
    // 8. CREATE SAMPLE ENGAGEMENT EVENTS
    // =========================================
    console.log('Creating sample engagement events...');
    
    await client.query(`
      INSERT INTO engagement_events (
        deal_room_id, user_id, event_type, event_data, ip_address, user_agent
      ) VALUES
      ($1, $2, 'page_view', '{"page": "overview"}', '192.168.1.xxx', 'Chrome/120'),
      ($1, $2, 'document_view', '{"documentId": "sample-1", "documentName": "Investment Overview"}', '192.168.1.xxx', 'Chrome/120'),
      ($1, $2, 'time_spent', '{"page": "overview", "seconds": 245}', '192.168.1.xxx', 'Chrome/120'),
      ($1, $2, 'calculator_use', '{"templateId": "fleet-economics", "inputs": {"fleetSize": 100}}', '192.168.1.xxx', 'Chrome/120'),
      ($1, $2, 'document_view', '{"documentId": "sample-2", "documentName": "Fleet Projections"}', '192.168.1.xxx', 'Chrome/120'),
      ($1, $2, 'page_view', '{"page": "documents"}', '192.168.1.xxx', 'Chrome/120'),
      ($1, $2, 'time_spent', '{"page": "documents", "seconds": 180}', '192.168.1.xxx', 'Chrome/120')
    `, [
      calpersDealRoom,
      userMap['investments@calpers.ca.gov']
    ]);
    console.log(`  ✓ Created engagement events\n`);

    await client.query('COMMIT');
    
    console.log('========================================');
    console.log('✅ Database seeding completed successfully!');
    console.log('========================================\n');
    console.log('Test Accounts:');
    console.log('  Email: admin@cdls-platform.com');
    console.log('  Email: brian.maas@cncda.org');
    console.log('  Password: Demo123!@#\n');

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Seeding failed:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

// Run if called directly
if (require.main === module) {
  seed().catch(console.error);
}

module.exports = seed;
