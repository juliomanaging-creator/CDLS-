/**
 * CDLS Platform - Frontend API Service
 * Security Review: Token handling, request sanitization, secure storage
 */

// Secure token storage using memory (not localStorage for sensitive tokens)
let accessToken = null;
let refreshToken = null;

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Token refresh state to prevent multiple simultaneous refreshes
let isRefreshing = false;
let refreshSubscribers = [];

const subscribeTokenRefresh = (callback) => {
  refreshSubscribers.push(callback);
};

const onTokenRefreshed = (token) => {
  refreshSubscribers.forEach((callback) => callback(token));
  refreshSubscribers = [];
};

/**
 * Sanitize user input before sending to API
 * @param {any} data - Data to sanitize
 * @returns {any} Sanitized data
 */
const sanitizeInput = (data) => {
  if (typeof data === 'string') {
    // Remove potential XSS vectors
    return data
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/javascript:/gi, '')
      .replace(/on\w+=/gi, '')
      .trim();
  }
  if (Array.isArray(data)) {
    return data.map(sanitizeInput);
  }
  if (data && typeof data === 'object') {
    const sanitized = {};
    for (const [key, value] of Object.entries(data)) {
      // Prevent prototype pollution
      if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
        continue;
      }
      sanitized[key] = sanitizeInput(value);
    }
    return sanitized;
  }
  return data;
};

/**
 * Set authentication tokens
 * @param {string} access - Access token
 * @param {string} refresh - Refresh token
 */
export const setTokens = (access, refresh) => {
  accessToken = access;
  refreshToken = refresh;
  
  // Store refresh token in httpOnly cookie via API call
  // Access token stays in memory only
  if (refresh) {
    sessionStorage.setItem('hasSession', 'true');
  }
};

/**
 * Clear authentication tokens
 */
export const clearTokens = () => {
  accessToken = null;
  refreshToken = null;
  sessionStorage.removeItem('hasSession');
};

/**
 * Check if user has an active session
 * @returns {boolean}
 */
export const hasActiveSession = () => {
  return !!accessToken || sessionStorage.getItem('hasSession') === 'true';
};

/**
 * Refresh the access token
 * @returns {Promise<string>} New access token
 */
const refreshAccessToken = async () => {
  if (!refreshToken) {
    throw new Error('No refresh token available');
  }

  const response = await fetch(`${API_BASE_URL}/auth/refresh`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ refreshToken }),
    credentials: 'include',
  });

  if (!response.ok) {
    clearTokens();
    throw new Error('Token refresh failed');
  }

  const data = await response.json();
  setTokens(data.accessToken, data.refreshToken);
  return data.accessToken;
};

/**
 * Make an authenticated API request
 * @param {string} endpoint - API endpoint
 * @param {Object} options - Fetch options
 * @returns {Promise<any>} Response data
 */
export const apiRequest = async (endpoint, options = {}) => {
  const url = `${API_BASE_URL}${endpoint}`;
  
  // Sanitize request body
  if (options.body && typeof options.body === 'object') {
    options.body = JSON.stringify(sanitizeInput(options.body));
  }

  const headers = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  // Add auth header if we have a token
  if (accessToken) {
    headers['Authorization'] = `Bearer ${accessToken}`;
  }

  // Add request ID for tracing
  headers['X-Request-ID'] = crypto.randomUUID();

  try {
    let response = await fetch(url, {
      ...options,
      headers,
      credentials: 'include',
    });

    // Handle 401 - try to refresh token
    if (response.status === 401 && refreshToken) {
      if (!isRefreshing) {
        isRefreshing = true;
        
        try {
          const newToken = await refreshAccessToken();
          isRefreshing = false;
          onTokenRefreshed(newToken);
          
          // Retry original request
          headers['Authorization'] = `Bearer ${newToken}`;
          response = await fetch(url, {
            ...options,
            headers,
            credentials: 'include',
          });
        } catch (error) {
          isRefreshing = false;
          clearTokens();
          window.location.href = '/login';
          throw error;
        }
      } else {
        // Wait for token refresh
        const newToken = await new Promise((resolve) => {
          subscribeTokenRefresh(resolve);
        });
        
        headers['Authorization'] = `Bearer ${newToken}`;
        response = await fetch(url, {
          ...options,
          headers,
          credentials: 'include',
        });
      }
    }

    // Parse response
    const contentType = response.headers.get('content-type');
    let data;
    
    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
    } else {
      data = await response.text();
    }

    if (!response.ok) {
      const error = new Error(data.error || 'Request failed');
      error.code = data.code;
      error.status = response.status;
      throw error;
    }

    return data;
  } catch (error) {
    console.error('API request failed:', {
      endpoint,
      error: error.message,
    });
    throw error;
  }
};

// ============================================
// API METHODS
// ============================================

// Auth
export const auth = {
  login: (email, password) => 
    apiRequest('/auth/login', {
      method: 'POST',
      body: { email, password },
    }),
  
  logout: () => {
    clearTokens();
    return apiRequest('/auth/logout', { method: 'POST' });
  },
  
  register: (data) =>
    apiRequest('/auth/register', {
      method: 'POST',
      body: data,
    }),
  
  forgotPassword: (email) =>
    apiRequest('/auth/forgot-password', {
      method: 'POST',
      body: { email },
    }),
};

// Deal Rooms
export const dealRooms = {
  list: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/deal-rooms${query ? `?${query}` : ''}`);
  },
  
  get: (id) => apiRequest(`/deal-rooms/${id}`),
  
  create: (data) =>
    apiRequest('/deal-rooms', {
      method: 'POST',
      body: data,
    }),
  
  update: (id, data) =>
    apiRequest(`/deal-rooms/${id}`, {
      method: 'PATCH',
      body: data,
    }),
  
  delete: (id) =>
    apiRequest(`/deal-rooms/${id}`, {
      method: 'DELETE',
    }),
  
  // Members
  listMembers: (dealRoomId) => 
    apiRequest(`/deal-rooms/${dealRoomId}/members`),
  
  addMember: (dealRoomId, data) =>
    apiRequest(`/deal-rooms/${dealRoomId}/members`, {
      method: 'POST',
      body: data,
    }),
  
  removeMember: (dealRoomId, userId) =>
    apiRequest(`/deal-rooms/${dealRoomId}/members/${userId}`, {
      method: 'DELETE',
    }),
  
  // Documents
  getUploadUrl: (dealRoomId, data) =>
    apiRequest(`/deal-rooms/${dealRoomId}/documents/upload-url`, {
      method: 'POST',
      body: data,
    }),
  
  confirmUpload: (dealRoomId, documentId, checksum) =>
    apiRequest(`/deal-rooms/${dealRoomId}/documents/${documentId}/confirm`, {
      method: 'POST',
      body: { checksum },
    }),
  
  listDocuments: (dealRoomId, params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/deal-rooms/${dealRoomId}/documents${query ? `?${query}` : ''}`);
  },
  
  getDownloadUrl: (dealRoomId, documentId) =>
    apiRequest(`/deal-rooms/${dealRoomId}/documents/${documentId}/download`),
  
  deleteDocument: (dealRoomId, documentId) =>
    apiRequest(`/deal-rooms/${dealRoomId}/documents/${documentId}`, {
      method: 'DELETE',
    }),
};

// Engagement Analytics
export const analytics = {
  trackEvent: (data) =>
    apiRequest('/analytics/events', {
      method: 'POST',
      body: data,
    }),
  
  trackBatch: (events) =>
    apiRequest('/analytics/events/batch', {
      method: 'POST',
      body: { events },
    }),
  
  getSummary: (dealRoomId, params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/analytics/deal-rooms/${dealRoomId}/summary${query ? `?${query}` : ''}`);
  },
  
  getStakeholders: (dealRoomId, params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/analytics/deal-rooms/${dealRoomId}/stakeholders${query ? `?${query}` : ''}`);
  },
  
  getDocumentHeatmap: (documentId) =>
    apiRequest(`/analytics/documents/${documentId}/heatmap`),
  
  getEngagementScore: (dealRoomId) =>
    apiRequest(`/analytics/deal-rooms/${dealRoomId}/score`),
  
  getAlerts: (dealRoomId, params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/analytics/deal-rooms/${dealRoomId}/alerts${query ? `?${query}` : ''}`);
  },
  
  markAlertRead: (alertId) =>
    apiRequest(`/analytics/alerts/${alertId}/read`, {
      method: 'PATCH',
    }),
};

// ROI Calculators
export const calculators = {
  listTemplates: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/calculators/templates${query ? `?${query}` : ''}`);
  },
  
  getTemplate: (templateId) =>
    apiRequest(`/calculators/templates/${templateId}`),
  
  calculate: (templateId, inputs) =>
    apiRequest('/calculators/calculate', {
      method: 'POST',
      body: { templateId, inputs },
    }),
  
  createSession: (data) =>
    apiRequest('/calculators/sessions', {
      method: 'POST',
      body: data,
    }),
  
  getSession: (sessionId) =>
    apiRequest(`/calculators/sessions/${sessionId}`),
  
  listSessions: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/calculators/sessions${query ? `?${query}` : ''}`);
  },
  
  createScenario: (sessionId, data) =>
    apiRequest(`/calculators/sessions/${sessionId}/scenarios`, {
      method: 'POST',
      body: data,
    }),
  
  compareScenarios: (sessionId) =>
    apiRequest(`/calculators/sessions/${sessionId}/compare`),
  
  shareSession: (sessionId) =>
    apiRequest(`/calculators/sessions/${sessionId}/share`, {
      method: 'POST',
    }),
  
  getShared: (shareToken) =>
    apiRequest(`/calculators/shared/${shareToken}`),
};

// Stakeholders
export const stakeholders = {
  list: (dealRoomId, params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/stakeholders/${dealRoomId}/stakeholders${query ? `?${query}` : ''}`);
  },
  
  get: (dealRoomId, stakeholderId) =>
    apiRequest(`/stakeholders/${dealRoomId}/stakeholders/${stakeholderId}`),
  
  create: (dealRoomId, data) =>
    apiRequest(`/stakeholders/${dealRoomId}/stakeholders`, {
      method: 'POST',
      body: data,
    }),
  
  update: (dealRoomId, stakeholderId, data) =>
    apiRequest(`/stakeholders/${dealRoomId}/stakeholders/${stakeholderId}`, {
      method: 'PATCH',
      body: data,
    }),
  
  delete: (dealRoomId, stakeholderId) =>
    apiRequest(`/stakeholders/${dealRoomId}/stakeholders/${stakeholderId}`, {
      method: 'DELETE',
    }),
  
  getOrgChart: (dealRoomId) =>
    apiRequest(`/stakeholders/${dealRoomId}/org-chart`),
  
  createRelationship: (dealRoomId, data) =>
    apiRequest(`/stakeholders/${dealRoomId}/relationships`, {
      method: 'POST',
      body: data,
    }),
  
  deleteRelationship: (dealRoomId, relationshipId) =>
    apiRequest(`/stakeholders/${dealRoomId}/relationships/${relationshipId}`, {
      method: 'DELETE',
    }),
  
  logInteraction: (dealRoomId, data) =>
    apiRequest(`/stakeholders/${dealRoomId}/interactions`, {
      method: 'POST',
      body: data,
    }),
  
  getInteractions: (dealRoomId, params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/stakeholders/${dealRoomId}/interactions${query ? `?${query}` : ''}`);
  },
  
  getInsights: (dealRoomId) =>
    apiRequest(`/stakeholders/${dealRoomId}/insights`),
};

// Action Plans
export const actionPlans = {
  list: (dealRoomId, params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/action-plans/${dealRoomId}/action-plans${query ? `?${query}` : ''}`);
  },
  
  get: (dealRoomId, planId) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}`),
  
  create: (dealRoomId, data) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans`, {
      method: 'POST',
      body: data,
    }),
  
  update: (dealRoomId, planId, data) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}`, {
      method: 'PATCH',
      body: data,
    }),
  
  delete: (dealRoomId, planId) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}`, {
      method: 'DELETE',
    }),
  
  // Milestones
  createMilestone: (dealRoomId, planId, data) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}/milestones`, {
      method: 'POST',
      body: data,
    }),
  
  updateMilestone: (dealRoomId, planId, milestoneId, data) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}/milestones/${milestoneId}`, {
      method: 'PATCH',
      body: data,
    }),
  
  deleteMilestone: (dealRoomId, planId, milestoneId) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}/milestones/${milestoneId}`, {
      method: 'DELETE',
    }),
  
  // Action Items
  createItem: (dealRoomId, planId, data) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}/items`, {
      method: 'POST',
      body: data,
    }),
  
  updateItem: (dealRoomId, planId, itemId, data) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}/items/${itemId}`, {
      method: 'PATCH',
      body: data,
    }),
  
  deleteItem: (dealRoomId, planId, itemId) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}/items/${itemId}`, {
      method: 'DELETE',
    }),
  
  reorderItems: (dealRoomId, planId, items) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}/reorder`, {
      method: 'POST',
      body: { items },
    }),
  
  // Comments
  addComment: (dealRoomId, planId, itemId, data) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}/items/${itemId}/comments`, {
      method: 'POST',
      body: data,
    }),
  
  getComments: (dealRoomId, planId, itemId, params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}/items/${itemId}/comments${query ? `?${query}` : ''}`);
  },
  
  // Analytics
  getAnalytics: (dealRoomId, planId) =>
    apiRequest(`/action-plans/${dealRoomId}/action-plans/${planId}/analytics`),
};

export default {
  auth,
  dealRooms,
  analytics,
  calculators,
  stakeholders,
  actionPlans,
  setTokens,
  clearTokens,
  hasActiveSession,
};
