/**
 * CDLS Platform - Engagement Dashboard Component
 * Security Review: Data sanitization, secure display, XSS prevention
 */

import { useState, useEffect, useCallback } from 'react';
import { analytics } from '../services/api';

// Safe text display to prevent XSS
const safeText = (text) => {
  if (!text) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
};

// Format date safely
const formatDate = (dateString) => {
  try {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(dateString));
  } catch {
    return 'Invalid date';
  }
};

// Format duration
const formatDuration = (seconds) => {
  if (!seconds || seconds < 0) return '0s';
  if (seconds < 60) return `${Math.round(seconds)}s`;
  if (seconds < 3600) return `${Math.round(seconds / 60)}m`;
  return `${Math.round(seconds / 3600)}h ${Math.round((seconds % 3600) / 60)}m`;
};

// Engagement score color
const getScoreColor = (score) => {
  if (score >= 70) return 'text-green-600 bg-green-100';
  if (score >= 40) return 'text-yellow-600 bg-yellow-100';
  return 'text-red-600 bg-red-100';
};

// Trend indicator
const TrendIndicator = ({ trend }) => {
  if (trend === 'rising') {
    return (
      <span className="inline-flex items-center text-green-600">
        <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M5.293 9.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 7.414V15a1 1 0 11-2 0V7.414L6.707 9.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
        </svg>
        Rising
      </span>
    );
  }
  if (trend === 'declining') {
    return (
      <span className="inline-flex items-center text-red-600">
        <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M14.707 10.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 12.586V5a1 1 0 012 0v7.586l2.293-2.293a1 1 0 011.414 0z" clipRule="evenodd" />
        </svg>
        Declining
      </span>
    );
  }
  return (
    <span className="inline-flex items-center text-gray-500">
      <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
        <path fillRule="evenodd" d="M3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
      </svg>
      Stable
    </span>
  );
};

const EngagementDashboard = ({ dealRoomId }) => {
  const [summary, setSummary] = useState(null);
  const [stakeholders, setStakeholders] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [engagementScore, setEngagementScore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch all data
  const fetchData = useCallback(async () => {
    if (!dealRoomId) return;

    setLoading(true);
    setError(null);

    try {
      const [summaryRes, stakeholdersRes, alertsRes, scoreRes] = await Promise.all([
        analytics.getSummary(dealRoomId),
        analytics.getStakeholders(dealRoomId),
        analytics.getAlerts(dealRoomId, { unreadOnly: 'true' }),
        analytics.getEngagementScore(dealRoomId),
      ]);

      setSummary(summaryRes.data);
      setStakeholders(stakeholdersRes.data || []);
      setAlerts(alertsRes.data || []);
      setEngagementScore(scoreRes.data);
    } catch (err) {
      setError(err.message || 'Failed to load engagement data');
    } finally {
      setLoading(false);
    }
  }, [dealRoomId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Mark alert as read
  const handleMarkAlertRead = useCallback(async (alertId) => {
    try {
      await analytics.markAlertRead(alertId);
      setAlerts(prev => prev.filter(a => a.id !== alertId));
    } catch (err) {
      console.error('Failed to mark alert read:', err);
    }
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-600">{error}</p>
        <button
          onClick={fetchData}
          className="mt-2 text-sm text-red-600 hover:text-red-800 underline"
        >
          Try again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Engagement Score */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Engagement Analytics</h2>
            <p className="text-gray-500 mt-1">
              Track buyer engagement and identify opportunities
            </p>
          </div>
          
          {engagementScore && (
            <div className="text-center">
              <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full ${getScoreColor(engagementScore.overallScore)}`}>
                <span className="text-2xl font-bold">
                  {engagementScore.overallScore}
                </span>
              </div>
              <p className="mt-2 text-sm text-gray-600">Engagement Score</p>
              <TrendIndicator trend={engagementScore.trend} />
            </div>
          )}
        </div>
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Alerts ({alerts.length})
          </h3>
          <div className="space-y-3">
            {alerts.slice(0, 5).map((alert) => (
              <div
                key={alert.id}
                className={`flex items-start justify-between p-3 rounded-lg ${
                  alert.severity === 'critical' ? 'bg-red-50' :
                  alert.severity === 'warning' ? 'bg-yellow-50' : 'bg-blue-50'
                }`}
              >
                <div>
                  <p className="font-medium text-gray-900">
                    {safeText(alert.title)}
                  </p>
                  <p className="text-sm text-gray-600 mt-1">
                    {safeText(alert.message)}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {formatDate(alert.created_at)}
                  </p>
                </div>
                <button
                  onClick={() => handleMarkAlertRead(alert.id)}
                  className="text-gray-400 hover:text-gray-600"
                  aria-label="Dismiss alert"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Summary Stats */}
      {summary && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg shadow p-4">
            <p className="text-sm text-gray-500">Unique Visitors</p>
            <p className="text-2xl font-bold text-gray-900">
              {summary.uniqueVisitors || 0}
            </p>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <p className="text-sm text-gray-500">Total Time Spent</p>
            <p className="text-2xl font-bold text-gray-900">
              {formatDuration(summary.totalTimeSeconds)}
            </p>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <p className="text-sm text-gray-500">Document Views</p>
            <p className="text-2xl font-bold text-gray-900">
              {summary.eventsByType?.find(e => e.event_type === 'document_view')?.count || 0}
            </p>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <p className="text-sm text-gray-500">Downloads</p>
            <p className="text-2xl font-bold text-gray-900">
              {summary.eventsByType?.find(e => e.event_type === 'document_download')?.count || 0}
            </p>
          </div>
        </div>
      )}

      {/* Stakeholder Engagement Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800">
            Stakeholder Engagement
          </h3>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Stakeholder
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Engagement Score
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Time Spent
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Documents
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Last Activity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {stakeholders.length === 0 ? (
                <tr>
                  <td colSpan="6" className="px-6 py-8 text-center text-gray-500">
                    No stakeholder engagement data yet
                  </td>
                </tr>
              ) : (
                stakeholders.map((stakeholder) => (
                  <tr key={stakeholder.user_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center">
                          <span className="text-gray-600 font-medium">
                            {safeText(stakeholder.first_name?.[0] || '')}{safeText(stakeholder.last_name?.[0] || '')}
                          </span>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {safeText(stakeholder.first_name)} {safeText(stakeholder.last_name)}
                          </div>
                          <div className="text-sm text-gray-500">
                            {safeText(stakeholder.email)}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getScoreColor(stakeholder.engagementScore)}`}>
                        {stakeholder.engagementScore}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDuration(stakeholder.total_time_seconds)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {stakeholder.document_views || 0} views, {stakeholder.downloads || 0} downloads
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {stakeholder.last_activity ? formatDate(stakeholder.last_activity) : 'Never'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {stakeholder.isChampion && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Champion
                        </span>
                      )}
                      {stakeholder.riskLevel === 'high' && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          At Risk
                        </span>
                      )}
                      {stakeholder.riskLevel === 'medium' && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                          Needs Attention
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Timeline Chart Placeholder */}
      {summary?.timeline && summary.timeline.length > 0 && (
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Engagement Over Time
          </h3>
          <div className="h-64 flex items-end space-x-2">
            {summary.timeline.map((day, index) => {
              const maxEvents = Math.max(...summary.timeline.map(d => parseInt(d.events, 10)));
              const height = maxEvents > 0 ? (parseInt(day.events, 10) / maxEvents) * 100 : 0;
              
              return (
                <div
                  key={index}
                  className="flex-1 flex flex-col items-center"
                >
                  <div
                    className="w-full bg-blue-500 rounded-t transition-all duration-300 hover:bg-blue-600"
                    style={{ height: `${height}%`, minHeight: '4px' }}
                    title={`${day.events} events, ${day.visitors} visitors`}
                  />
                  <span className="text-xs text-gray-500 mt-1 transform -rotate-45 origin-top-left">
                    {new Date(day.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default EngagementDashboard;
