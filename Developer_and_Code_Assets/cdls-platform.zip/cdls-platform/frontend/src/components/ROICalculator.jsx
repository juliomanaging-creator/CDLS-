/**
 * CDLS Platform - ROI Calculator Component
 * Security Review: Input validation, XSS prevention, secure number handling
 */

import { useState, useCallback, useMemo } from 'react';
import { calculators } from '../services/api';

// Safe number parsing to prevent injection
const safeParseFloat = (value, defaultValue = 0) => {
  if (value === '' || value === null || value === undefined) return defaultValue;
  const parsed = parseFloat(String(value).replace(/[^0-9.-]/g, ''));
  return isNaN(parsed) ? defaultValue : parsed;
};

// Format currency safely
const formatCurrency = (value) => {
  const num = safeParseFloat(value);
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(num);
};

// Format number safely
const formatNumber = (value, decimals = 0) => {
  const num = safeParseFloat(value);
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(num);
};

const ROICalculator = ({ 
  templateId = 'default_fleet_economics',
  dealRoomId = null,
  onSave = null,
}) => {
  const [inputs, setInputs] = useState({
    fleetSize: 10,
    avgRouteDistance: 200,
    tripsPerMonth: 100,
    dieselPricePerGallon: 5.05,
    electricityRatePerKwh: 0.15,
    dieselMpg: 6,
    evMilesPerKwh: 2.5,
    yearsToProject: 5,
  });

  const [outputs, setOutputs] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [sessionName, setSessionName] = useState('');

  // Input constraints for validation
  const inputConstraints = useMemo(() => ({
    fleetSize: { min: 1, max: 500, step: 1, label: 'Fleet Size (vehicles)' },
    avgRouteDistance: { min: 10, max: 2000, step: 10, label: 'Average Route Distance (miles)' },
    tripsPerMonth: { min: 1, max: 5000, step: 10, label: 'Trips per Month' },
    dieselPricePerGallon: { min: 2, max: 15, step: 0.05, label: 'Diesel Price ($/gallon)' },
    electricityRatePerKwh: { min: 0.05, max: 0.50, step: 0.01, label: 'Electricity Rate ($/kWh)' },
    dieselMpg: { min: 3, max: 15, step: 0.5, label: 'Diesel MPG' },
    evMilesPerKwh: { min: 1, max: 5, step: 0.1, label: 'EV Miles per kWh' },
    yearsToProject: { min: 1, max: 15, step: 1, label: 'Years to Project' },
  }), []);

  // Validate single input
  const validateInput = useCallback((name, value) => {
    const constraint = inputConstraints[name];
    if (!constraint) return value;

    const numValue = safeParseFloat(value, constraint.min);
    return Math.min(Math.max(numValue, constraint.min), constraint.max);
  }, [inputConstraints]);

  // Handle input change with validation
  const handleInputChange = useCallback((name, value) => {
    const validatedValue = validateInput(name, value);
    setInputs(prev => ({
      ...prev,
      [name]: validatedValue,
    }));
    setError(null);
  }, [validateInput]);

  // Calculate ROI
  const handleCalculate = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await calculators.calculate(templateId, inputs);
      setOutputs(response.data.outputs);
    } catch (err) {
      setError(err.message || 'Calculation failed');
    } finally {
      setLoading(false);
    }
  }, [templateId, inputs]);

  // Save session
  const handleSave = useCallback(async () => {
    if (!sessionName.trim()) {
      setError('Please enter a session name');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await calculators.createSession({
        templateId,
        dealRoomId,
        sessionName: sessionName.trim(),
        inputs,
      });

      if (onSave) {
        onSave(response.data);
      }
    } catch (err) {
      setError(err.message || 'Failed to save session');
    } finally {
      setLoading(false);
    }
  }, [templateId, dealRoomId, sessionName, inputs, onSave]);

  // Render input field
  const renderInput = useCallback((name) => {
    const constraint = inputConstraints[name];
    if (!constraint) return null;

    return (
      <div key={name} className="mb-4">
        <label 
          htmlFor={name}
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          {constraint.label}
        </label>
        <input
          id={name}
          type="number"
          min={constraint.min}
          max={constraint.max}
          step={constraint.step}
          value={inputs[name]}
          onChange={(e) => handleInputChange(name, e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          aria-describedby={`${name}-description`}
        />
        <p 
          id={`${name}-description`}
          className="mt-1 text-xs text-gray-500"
        >
          Range: {constraint.min} - {formatNumber(constraint.max)}
        </p>
      </div>
    );
  }, [inputs, inputConstraints, handleInputChange]);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Fleet Economics ROI Calculator
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Input Section */}
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Input Parameters
          </h3>
          
          <div className="space-y-4">
            {Object.keys(inputConstraints).map(renderInput)}
          </div>

          <button
            onClick={handleCalculate}
            disabled={loading}
            className="mt-6 w-full bg-blue-600 text-white py-3 px-4 rounded-md font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? 'Calculating...' : 'Calculate ROI'}
          </button>

          {error && (
            <div 
              className="mt-4 p-4 bg-red-50 border border-red-200 rounded-md"
              role="alert"
            >
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}
        </div>

        {/* Output Section */}
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Results
          </h3>

          {outputs ? (
            <div className="space-y-4">
              {/* Key Metrics */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-sm text-green-600 font-medium">Annual Savings</p>
                <p className="text-3xl font-bold text-green-700">
                  {formatCurrency(outputs.annualSavings)}
                </p>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-600 font-medium">Total Savings ({inputs.yearsToProject} years)</p>
                <p className="text-3xl font-bold text-blue-700">
                  {formatCurrency(outputs.totalSavings)}
                </p>
              </div>

              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <p className="text-sm text-purple-600 font-medium">Per Vehicle Savings</p>
                <p className="text-2xl font-bold text-purple-700">
                  {formatCurrency(outputs.savingsPerVehicle)}/year
                </p>
              </div>

              {/* Detailed Breakdown */}
              <div className="border border-gray-200 rounded-lg p-4">
                <h4 className="font-medium text-gray-800 mb-3">Cost Comparison</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Annual Diesel Cost:</span>
                    <span className="font-medium text-red-600">
                      {formatCurrency(outputs.dieselFuelCostPerYear)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Annual EV Electricity Cost:</span>
                    <span className="font-medium text-green-600">
                      {formatCurrency(outputs.evEnergyCostPerYear)}
                    </span>
                  </div>
                  <div className="border-t pt-2 flex justify-between">
                    <span className="text-gray-600">CO2 Reduction:</span>
                    <span className="font-medium text-green-600">
                      {formatNumber(outputs.co2ReductionTons, 1)} tons/year
                    </span>
                  </div>
                </div>
              </div>

              {/* Save Session */}
              {onSave && (
                <div className="border-t pt-4 mt-4">
                  <label 
                    htmlFor="sessionName"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    Save this calculation
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="sessionName"
                      type="text"
                      placeholder="Session name"
                      value={sessionName}
                      onChange={(e) => setSessionName(e.target.value)}
                      maxLength={255}
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      onClick={handleSave}
                      disabled={loading || !sessionName.trim()}
                      className="px-4 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-900 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      Save
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 bg-gray-50 rounded-lg border border-gray-200">
              <p className="text-gray-500">
                Enter parameters and click "Calculate ROI" to see results
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ROICalculator;
