/**
 * CDLS Platform - Mutual Action Plans Component
 * Collaborative deal milestones and task management
 */

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  CheckCircleIcon,
  ClockIcon,
  ExclamationCircleIcon,
  PlusIcon,
  ChevronRightIcon,
  ChevronDownIcon,
  CalendarIcon,
  UserIcon,
} from '@heroicons/react/24/outline';
import { CheckCircleIcon as CheckCircleSolid } from '@heroicons/react/24/solid';
import { actionPlans } from '../services/api';
import toast from 'react-hot-toast';
import clsx from 'clsx';
import { format, isPast, isToday, addDays } from 'date-fns';

// ============================================
// ACTION PLAN MAIN COMPONENT
// ============================================
export function MutualActionPlan({ dealRoomId }) {
  const [selectedPlanId, setSelectedPlanId] = useState(null);
  const [showCreateModal, setShowCreateModal] = useState(false);

  const { data: plansData, isLoading } = useQuery({
    queryKey: ['actionPlans', dealRoomId],
    queryFn: () => actionPlans.list(dealRoomId, {}),
  });

  const plans = plansData?.data || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Mutual Action Plans</h2>
          <p className="text-gray-500">
            Collaborative milestones to close the deal
          </p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <PlusIcon className="w-5 h-5" />
          New Plan
        </button>
      </div>

      {/* Plans List or Detail */}
      {isLoading ? (
        <LoadingSkeleton />
      ) : selectedPlanId ? (
        <ActionPlanDetail
          dealRoomId={dealRoomId}
          planId={selectedPlanId}
          onBack={() => setSelectedPlanId(null)}
        />
      ) : (
        <PlansList
          plans={plans}
          onSelect={setSelectedPlanId}
        />
      )}

      {/* Create Modal */}
      {showCreateModal && (
        <CreatePlanModal
          dealRoomId={dealRoomId}
          onClose={() => setShowCreateModal(false)}
        />
      )}
    </div>
  );
}

// ============================================
// PLANS LIST
// ============================================
function PlansList({ plans, onSelect }) {
  if (plans.length === 0) {
    return (
      <div className="text-center py-12 bg-gray-50 rounded-lg">
        <CalendarIcon className="w-12 h-12 text-gray-400 mx-auto" />
        <h3 className="mt-4 font-medium text-gray-900">No action plans yet</h3>
        <p className="text-gray-500">Create your first mutual action plan to get started</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {plans.map((plan) => (
        <div
          key={plan.id}
          onClick={() => onSelect(plan.id)}
          className="p-4 bg-white border rounded-lg shadow-sm hover:shadow-md cursor-pointer transition-shadow"
        >
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-gray-900">{plan.name}</h3>
              <p className="text-sm text-gray-500 mt-1">{plan.description}</p>
            </div>
            <ChevronRightIcon className="w-5 h-5 text-gray-400" />
          </div>

          <div className="mt-4 flex items-center gap-6">
            {/* Progress Bar */}
            <div className="flex-1">
              <div className="flex justify-between text-sm text-gray-500 mb-1">
                <span>Progress</span>
                <span>{plan.progress_percentage || 0}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className={clsx(
                    'h-full rounded-full transition-all',
                    plan.progress_percentage >= 75 ? 'bg-green-500' :
                    plan.progress_percentage >= 50 ? 'bg-blue-500' :
                    plan.progress_percentage >= 25 ? 'bg-yellow-500' : 'bg-gray-400'
                  )}
                  style={{ width: `${plan.progress_percentage || 0}%` }}
                />
              </div>
            </div>

            {/* Stats */}
            <div className="flex gap-4 text-sm text-gray-500">
              <span>{plan.milestone_count || 0} milestones</span>
              <span>{plan.completed_count || 0}/{plan.action_item_count || 0} tasks</span>
            </div>

            {/* Status Badge */}
            <StatusBadge status={plan.status} />
          </div>

          {plan.target_close_date && (
            <div className="mt-3 flex items-center gap-2 text-sm">
              <CalendarIcon className="w-4 h-4 text-gray-400" />
              <span className={isPast(new Date(plan.target_close_date)) && plan.status !== 'completed' ? 'text-red-600' : 'text-gray-500'}>
                Target: {format(new Date(plan.target_close_date), 'MMM d, yyyy')}
              </span>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ============================================
// ACTION PLAN DETAIL
// ============================================
function ActionPlanDetail({ dealRoomId, planId, onBack }) {
  const queryClient = useQueryClient();
  const [expandedMilestones, setExpandedMilestones] = useState(new Set());
  const [showAddMilestone, setShowAddMilestone] = useState(false);
  const [showAddItem, setShowAddItem] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ['actionPlan', dealRoomId, planId],
    queryFn: () => actionPlans.get(dealRoomId, planId),
  });

  const { data: analyticsData } = useQuery({
    queryKey: ['actionPlanAnalytics', dealRoomId, planId],
    queryFn: () => actionPlans.getAnalytics(dealRoomId, planId),
  });

  const updateItemMutation = useMutation({
    mutationFn: ({ itemId, data }) => actionPlans.updateItem(dealRoomId, planId, itemId, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['actionPlan', dealRoomId, planId]);
      toast.success('Task updated');
    },
  });

  const toggleMilestone = (id) => {
    setExpandedMilestones((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const toggleItemStatus = (item) => {
    const newStatus = item.status === 'completed' ? 'pending' : 'completed';
    updateItemMutation.mutate({
      itemId: item.id,
      data: { status: newStatus },
    });
  };

  if (isLoading) return <LoadingSkeleton />;

  const plan = data?.data;
  const analytics = analyticsData?.data;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="text-gray-500 hover:text-gray-700">
          ← Back
        </button>
        <div className="flex-1">
          <h2 className="text-xl font-bold">{plan?.name}</h2>
          <p className="text-gray-500">{plan?.description}</p>
        </div>
        <StatusBadge status={plan?.status} />
      </div>

      {/* Analytics Summary */}
      {analytics && (
        <div className="grid grid-cols-5 gap-4">
          <StatCard label="Total Tasks" value={analytics.summary.total_items} />
          <StatCard label="Completed" value={analytics.summary.completed} color="green" />
          <StatCard label="In Progress" value={analytics.summary.in_progress} color="blue" />
          <StatCard label="Blocked" value={analytics.summary.blocked} color="red" />
          <StatCard label="Overdue" value={analytics.summary.overdue} color="amber" />
        </div>
      )}

      {/* Milestones */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="font-semibold">Milestones</h3>
          <button
            onClick={() => setShowAddMilestone(true)}
            className="text-sm text-blue-600 hover:text-blue-700"
          >
            + Add Milestone
          </button>
        </div>

        {plan?.milestones?.map((milestone) => (
          <div key={milestone.id} className="border rounded-lg overflow-hidden">
            {/* Milestone Header */}
            <div
              onClick={() => toggleMilestone(milestone.id)}
              className={clsx(
                'p-4 flex items-center gap-3 cursor-pointer',
                milestone.status === 'completed' ? 'bg-green-50' : 'bg-gray-50'
              )}
            >
              {expandedMilestones.has(milestone.id) ? (
                <ChevronDownIcon className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronRightIcon className="w-5 h-5 text-gray-400" />
              )}
              
              <MilestoneStatusIcon status={milestone.status} />
              
              <div className="flex-1">
                <span className="font-medium">{milestone.name}</span>
                {milestone.due_date && (
                  <span className="ml-3 text-sm text-gray-500">
                    Due: {format(new Date(milestone.due_date), 'MMM d')}
                  </span>
                )}
              </div>

              <span className="text-sm text-gray-500">
                {milestone.action_items?.filter((i) => i.status === 'completed').length || 0}/
                {milestone.action_items?.length || 0} tasks
              </span>

              <OwnerBadge ownerType={milestone.owner_type} />
            </div>

            {/* Action Items */}
            {expandedMilestones.has(milestone.id) && (
              <div className="border-t divide-y">
                {milestone.action_items?.map((item) => (
                  <div
                    key={item.id}
                    className={clsx(
                      'p-4 flex items-center gap-3',
                      item.status === 'completed' && 'bg-gray-50'
                    )}
                  >
                    <button
                      onClick={() => toggleItemStatus(item)}
                      className="flex-shrink-0"
                    >
                      {item.status === 'completed' ? (
                        <CheckCircleSolid className="w-6 h-6 text-green-500" />
                      ) : (
                        <div className="w-6 h-6 border-2 rounded-full hover:border-green-500" />
                      )}
                    </button>

                    <div className="flex-1">
                      <span className={clsx(
                        'font-medium',
                        item.status === 'completed' && 'line-through text-gray-400'
                      )}>
                        {item.title}
                      </span>
                      {item.description && (
                        <p className="text-sm text-gray-500 mt-1">{item.description}</p>
                      )}
                    </div>

                    <PriorityBadge priority={item.priority} />
                    <OwnerBadge ownerType={item.ownerType} />

                    {item.dueDate && (
                      <span className={clsx(
                        'text-sm',
                        isPast(new Date(item.dueDate)) && item.status !== 'completed' 
                          ? 'text-red-600' 
                          : 'text-gray-500'
                      )}>
                        {format(new Date(item.dueDate), 'MMM d')}
                      </span>
                    )}
                  </div>
                ))}

                {/* Add Item Button */}
                <button
                  onClick={() => setShowAddItem(milestone.id)}
                  className="w-full p-3 text-left text-sm text-gray-500 hover:bg-gray-50"
                >
                  + Add task
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Add Milestone Modal */}
      {showAddMilestone && (
        <AddMilestoneModal
          dealRoomId={dealRoomId}
          planId={planId}
          onClose={() => setShowAddMilestone(false)}
          nextOrder={plan?.milestones?.length || 0}
        />
      )}

      {/* Add Item Modal */}
      {showAddItem && (
        <AddItemModal
          dealRoomId={dealRoomId}
          planId={planId}
          milestoneId={showAddItem}
          onClose={() => setShowAddItem(null)}
          nextOrder={
            plan?.milestones?.find((m) => m.id === showAddItem)?.action_items?.length || 0
          }
        />
      )}
    </div>
  );
}

// ============================================
// MODALS
// ============================================
function CreatePlanModal({ dealRoomId, onClose }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    targetCloseDate: '',
  });

  const createMutation = useMutation({
    mutationFn: (data) => actionPlans.create(dealRoomId, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['actionPlans', dealRoomId]);
      toast.success('Action plan created');
      onClose();
    },
    onError: () => toast.error('Failed to create plan'),
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  return (
    <Modal title="Create Action Plan" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Plan Name *"
          value={formData.name}
          onChange={(e) => setFormData((f) => ({ ...f, name: e.target.value }))}
          className="w-full px-3 py-2 border rounded-lg"
          required
        />
        
        <textarea
          placeholder="Description"
          value={formData.description}
          onChange={(e) => setFormData((f) => ({ ...f, description: e.target.value }))}
          className="w-full px-3 py-2 border rounded-lg"
          rows={3}
        />
        
        <div>
          <label className="block text-sm font-medium mb-1">Target Close Date</label>
          <input
            type="date"
            value={formData.targetCloseDate}
            onChange={(e) => setFormData((f) => ({ ...f, targetCloseDate: e.target.value }))}
            className="w-full px-3 py-2 border rounded-lg"
            min={format(new Date(), 'yyyy-MM-dd')}
          />
        </div>

        <div className="flex justify-end gap-3">
          <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg">
            Cancel
          </button>
          <button
            type="submit"
            disabled={createMutation.isPending}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {createMutation.isPending ? 'Creating...' : 'Create Plan'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

function AddMilestoneModal({ dealRoomId, planId, onClose, nextOrder }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    dueDate: '',
    ownerType: 'seller',
    sequenceOrder: nextOrder,
  });

  const createMutation = useMutation({
    mutationFn: (data) => actionPlans.createMilestone(dealRoomId, planId, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['actionPlan', dealRoomId, planId]);
      toast.success('Milestone added');
      onClose();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  return (
    <Modal title="Add Milestone" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Milestone Name *"
          value={formData.name}
          onChange={(e) => setFormData((f) => ({ ...f, name: e.target.value }))}
          className="w-full px-3 py-2 border rounded-lg"
          required
        />
        
        <input
          type="date"
          value={formData.dueDate}
          onChange={(e) => setFormData((f) => ({ ...f, dueDate: e.target.value }))}
          className="w-full px-3 py-2 border rounded-lg"
        />
        
        <select
          value={formData.ownerType}
          onChange={(e) => setFormData((f) => ({ ...f, ownerType: e.target.value }))}
          className="w-full px-3 py-2 border rounded-lg"
        >
          <option value="seller">Seller Owned</option>
          <option value="buyer">Buyer Owned</option>
          <option value="both">Joint</option>
        </select>

        <div className="flex justify-end gap-3">
          <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg">
            Cancel
          </button>
          <button
            type="submit"
            disabled={createMutation.isPending}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg"
          >
            Add Milestone
          </button>
        </div>
      </form>
    </Modal>
  );
}

function AddItemModal({ dealRoomId, planId, milestoneId, onClose, nextOrder }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    milestoneId,
    title: '',
    description: '',
    priority: 'medium',
    ownerType: 'seller',
    dueDate: '',
    sequenceOrder: nextOrder,
  });

  const createMutation = useMutation({
    mutationFn: (data) => actionPlans.createItem(dealRoomId, planId, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['actionPlan', dealRoomId, planId]);
      toast.success('Task added');
      onClose();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  return (
    <Modal title="Add Task" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Task Title *"
          value={formData.title}
          onChange={(e) => setFormData((f) => ({ ...f, title: e.target.value }))}
          className="w-full px-3 py-2 border rounded-lg"
          required
        />
        
        <textarea
          placeholder="Description"
          value={formData.description}
          onChange={(e) => setFormData((f) => ({ ...f, description: e.target.value }))}
          className="w-full px-3 py-2 border rounded-lg"
          rows={2}
        />

        <div className="grid grid-cols-2 gap-4">
          <select
            value={formData.priority}
            onChange={(e) => setFormData((f) => ({ ...f, priority: e.target.value }))}
            className="px-3 py-2 border rounded-lg"
          >
            <option value="low">Low Priority</option>
            <option value="medium">Medium Priority</option>
            <option value="high">High Priority</option>
            <option value="critical">Critical</option>
          </select>
          
          <select
            value={formData.ownerType}
            onChange={(e) => setFormData((f) => ({ ...f, ownerType: e.target.value }))}
            className="px-3 py-2 border rounded-lg"
          >
            <option value="seller">Seller</option>
            <option value="buyer">Buyer</option>
          </select>
        </div>
        
        <input
          type="date"
          value={formData.dueDate}
          onChange={(e) => setFormData((f) => ({ ...f, dueDate: e.target.value }))}
          className="w-full px-3 py-2 border rounded-lg"
        />

        <div className="flex justify-end gap-3">
          <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg">
            Cancel
          </button>
          <button
            type="submit"
            disabled={createMutation.isPending}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg"
          >
            Add Task
          </button>
        </div>
      </form>
    </Modal>
  );
}

// ============================================
// UTILITY COMPONENTS
// ============================================
function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const styles = {
    draft: 'bg-gray-100 text-gray-700',
    active: 'bg-blue-100 text-blue-700',
    completed: 'bg-green-100 text-green-700',
    cancelled: 'bg-red-100 text-red-700',
  };

  return (
    <span className={clsx('px-2 py-1 text-xs rounded-full font-medium capitalize', styles[status])}>
      {status}
    </span>
  );
}

function PriorityBadge({ priority }) {
  const styles = {
    low: 'bg-gray-100 text-gray-600',
    medium: 'bg-blue-100 text-blue-600',
    high: 'bg-amber-100 text-amber-600',
    critical: 'bg-red-100 text-red-600',
  };

  return (
    <span className={clsx('px-2 py-0.5 text-xs rounded font-medium', styles[priority])}>
      {priority}
    </span>
  );
}

function OwnerBadge({ ownerType }) {
  const styles = {
    seller: 'bg-purple-100 text-purple-700',
    buyer: 'bg-teal-100 text-teal-700',
    both: 'bg-indigo-100 text-indigo-700',
  };

  if (!ownerType) return null;

  return (
    <span className={clsx('px-2 py-0.5 text-xs rounded font-medium capitalize', styles[ownerType])}>
      {ownerType}
    </span>
  );
}

function MilestoneStatusIcon({ status }) {
  switch (status) {
    case 'completed':
      return <CheckCircleSolid className="w-6 h-6 text-green-500" />;
    case 'in_progress':
      return <ClockIcon className="w-6 h-6 text-blue-500" />;
    case 'blocked':
      return <ExclamationCircleIcon className="w-6 h-6 text-red-500" />;
    default:
      return <div className="w-6 h-6 border-2 rounded-full border-gray-300" />;
  }
}

function StatCard({ label, value, color = 'gray' }) {
  const colors = {
    gray: 'text-gray-900',
    green: 'text-green-600',
    blue: 'text-blue-600',
    red: 'text-red-600',
    amber: 'text-amber-600',
  };

  return (
    <div className="p-4 bg-white border rounded-lg text-center">
      <p className={clsx('text-2xl font-bold', colors[color])}>{value}</p>
      <p className="text-sm text-gray-500">{label}</p>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="space-y-4 animate-pulse">
      <div className="h-32 bg-gray-200 rounded-lg" />
      <div className="h-32 bg-gray-200 rounded-lg" />
    </div>
  );
}

export default MutualActionPlan;
