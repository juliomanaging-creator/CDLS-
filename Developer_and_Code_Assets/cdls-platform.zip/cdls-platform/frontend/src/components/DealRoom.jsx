/**
 * CDLS Platform - Digital Deal Room Component
 * Security: XSS prevention, secure file handling, access control UI
 */

import React, { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  FolderIcon, 
  DocumentIcon, 
  UserGroupIcon,
  ShareIcon,
  TrashIcon,
  CloudArrowUpIcon,
  LockClosedIcon,
  EyeIcon
} from '@heroicons/react/24/outline';
import { dealRooms } from '../services/api';
import toast from 'react-hot-toast';
import clsx from 'clsx';

// ============================================
// DEAL ROOM LIST
// ============================================
export function DealRoomList({ onSelect }) {
  const [filters, setFilters] = useState({ stage: '', search: '' });

  const { data, isLoading, error } = useQuery({
    queryKey: ['dealRooms', filters],
    queryFn: () => dealRooms.list(filters),
  });

  const stageColors = {
    prospect: 'bg-gray-100 text-gray-700',
    qualification: 'bg-blue-100 text-blue-700',
    due_diligence: 'bg-yellow-100 text-yellow-700',
    negotiation: 'bg-purple-100 text-purple-700',
    closing: 'bg-green-100 text-green-700',
    closed_won: 'bg-emerald-100 text-emerald-700',
    closed_lost: 'bg-red-100 text-red-700',
  };

  if (isLoading) return <LoadingSkeleton />;
  if (error) return <ErrorMessage message="Failed to load deal rooms" />;

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex gap-4">
        <input
          type="text"
          placeholder="Search deal rooms..."
          value={filters.search}
          onChange={(e) => setFilters(f => ({ ...f, search: e.target.value }))}
          className="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
        />
        <select
          value={filters.stage}
          onChange={(e) => setFilters(f => ({ ...f, stage: e.target.value }))}
          className="px-4 py-2 border rounded-lg"
        >
          <option value="">All Stages</option>
          <option value="prospect">Prospect</option>
          <option value="qualification">Qualification</option>
          <option value="due_diligence">Due Diligence</option>
          <option value="negotiation">Negotiation</option>
          <option value="closing">Closing</option>
        </select>
      </div>

      {/* Deal Room Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {data?.data?.map((room) => (
          <div
            key={room.id}
            onClick={() => onSelect(room)}
            className="p-4 bg-white border rounded-lg shadow-sm hover:shadow-md cursor-pointer transition-shadow"
          >
            <div className="flex justify-between items-start">
              <h3 className="font-semibold text-gray-900">{room.name}</h3>
              <span className={clsx('px-2 py-1 text-xs rounded-full', stageColors[room.stage])}>
                {room.stage.replace('_', ' ')}
              </span>
            </div>
            
            <p className="mt-2 text-sm text-gray-500 line-clamp-2">
              {room.description || 'No description'}
            </p>
            
            <div className="mt-4 flex items-center gap-4 text-sm text-gray-500">
              <span className="flex items-center gap-1">
                <DocumentIcon className="w-4 h-4" />
                {room.document_count || 0}
              </span>
              <span className="flex items-center gap-1">
                <UserGroupIcon className="w-4 h-4" />
                {room.member_count || 0}
              </span>
              {room.deal_value && (
                <span className="font-medium text-green-600">
                  ${(room.deal_value / 1000000).toFixed(1)}M
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================
// DEAL ROOM DETAIL
// ============================================
export function DealRoomDetail({ dealRoomId }) {
  const [activeTab, setActiveTab] = useState('documents');
  const queryClient = useQueryClient();

  const { data: dealRoom, isLoading } = useQuery({
    queryKey: ['dealRoom', dealRoomId],
    queryFn: () => dealRooms.get(dealRoomId),
  });

  const tabs = [
    { id: 'documents', label: 'Documents', icon: DocumentIcon },
    { id: 'members', label: 'Team', icon: UserGroupIcon },
    { id: 'sharing', label: 'Sharing', icon: ShareIcon },
  ];

  if (isLoading) return <LoadingSkeleton />;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border rounded-lg p-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{dealRoom?.data?.name}</h1>
            <p className="mt-1 text-gray-500">{dealRoom?.data?.description}</p>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              Edit Room
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b">
        <nav className="flex gap-4">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={clsx(
                'flex items-center gap-2 px-4 py-3 border-b-2 transition-colors',
                activeTab === tab.id
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              )}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="bg-white border rounded-lg p-6">
        {activeTab === 'documents' && <DocumentsTab dealRoomId={dealRoomId} />}
        {activeTab === 'members' && <MembersTab dealRoomId={dealRoomId} />}
        {activeTab === 'sharing' && <SharingTab dealRoomId={dealRoomId} />}
      </div>
    </div>
  );
}

// ============================================
// DOCUMENTS TAB
// ============================================
function DocumentsTab({ dealRoomId }) {
  const [uploading, setUploading] = useState(false);
  const queryClient = useQueryClient();

  const { data: documents, isLoading } = useQuery({
    queryKey: ['documents', dealRoomId],
    queryFn: () => dealRooms.getDocuments(dealRoomId),
  });

  const deleteMutation = useMutation({
    mutationFn: (documentId) => dealRooms.deleteDocument(dealRoomId, documentId),
    onSuccess: () => {
      queryClient.invalidateQueries(['documents', dealRoomId]);
      toast.success('Document deleted');
    },
    onError: () => toast.error('Failed to delete document'),
  });

  // Secure file upload handler
  const handleFileUpload = useCallback(async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type (whitelist)
    const allowedTypes = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'png', 'jpg', 'jpeg'];
    const extension = file.name.split('.').pop()?.toLowerCase();
    if (!allowedTypes.includes(extension)) {
      toast.error('File type not allowed');
      return;
    }

    // Validate file size (100MB max)
    if (file.size > 100 * 1024 * 1024) {
      toast.error('File too large (max 100MB)');
      return;
    }

    setUploading(true);
    try {
      // Get presigned URL
      const { data } = await dealRooms.getUploadUrl(dealRoomId, {
        name: file.name,
        fileType: extension,
        fileSize: file.size,
      });

      // Upload to S3
      await fetch(data.uploadUrl, {
        method: 'PUT',
        body: file,
        headers: { 'Content-Type': file.type },
      });

      // Calculate checksum and confirm
      const checksum = await calculateChecksum(file);
      await dealRooms.confirmUpload(dealRoomId, data.document.id, { checksum });

      queryClient.invalidateQueries(['documents', dealRoomId]);
      toast.success('Document uploaded successfully');
    } catch (error) {
      toast.error('Upload failed');
    } finally {
      setUploading(false);
    }
  }, [dealRoomId, queryClient]);

  const handleDownload = async (documentId) => {
    try {
      const { data } = await dealRooms.getDownloadUrl(dealRoomId, documentId);
      window.open(data.downloadUrl, '_blank');
    } catch (error) {
      toast.error('Failed to download');
    }
  };

  return (
    <div className="space-y-4">
      {/* Upload Button */}
      <div className="flex justify-between items-center">
        <h3 className="font-semibold">Documents</h3>
        <label className={clsx(
          'flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg cursor-pointer',
          uploading ? 'opacity-50' : 'hover:bg-blue-700'
        )}>
          <CloudArrowUpIcon className="w-5 h-5" />
          {uploading ? 'Uploading...' : 'Upload'}
          <input
            type="file"
            onChange={handleFileUpload}
            disabled={uploading}
            className="hidden"
            accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.png,.jpg,.jpeg"
          />
        </label>
      </div>

      {/* Documents List */}
      {isLoading ? (
        <LoadingSkeleton />
      ) : (
        <div className="divide-y">
          {documents?.data?.map((doc) => (
            <div key={doc.id} className="flex items-center justify-between py-3">
              <div className="flex items-center gap-3">
                <DocumentIcon className="w-8 h-8 text-gray-400" />
                <div>
                  <p className="font-medium">{doc.name}</p>
                  <p className="text-sm text-gray-500">
                    {formatFileSize(doc.file_size)} • {doc.file_type.toUpperCase()}
                  </p>
                </div>
                {doc.is_confidential && (
                  <LockClosedIcon className="w-4 h-4 text-amber-500" title="Confidential" />
                )}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleDownload(doc.id)}
                  className="p-2 text-gray-500 hover:text-blue-600"
                  title="Download"
                >
                  <EyeIcon className="w-5 h-5" />
                </button>
                <button
                  onClick={() => deleteMutation.mutate(doc.id)}
                  className="p-2 text-gray-500 hover:text-red-600"
                  title="Delete"
                >
                  <TrashIcon className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================
// MEMBERS TAB
// ============================================
function MembersTab({ dealRoomId }) {
  const { data: members, isLoading } = useQuery({
    queryKey: ['members', dealRoomId],
    queryFn: () => dealRooms.getMembers(dealRoomId),
  });

  const roleColors = {
    owner: 'bg-purple-100 text-purple-700',
    admin: 'bg-blue-100 text-blue-700',
    contributor: 'bg-green-100 text-green-700',
    viewer: 'bg-gray-100 text-gray-700',
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-semibold">Team Members</h3>
        <button className="px-4 py-2 border rounded-lg hover:bg-gray-50">
          + Invite Member
        </button>
      </div>

      {isLoading ? (
        <LoadingSkeleton />
      ) : (
        <div className="divide-y">
          {members?.data?.map((member) => (
            <div key={member.id} className="flex items-center justify-between py-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                  {member.first_name?.[0]}{member.last_name?.[0]}
                </div>
                <div>
                  <p className="font-medium">
                    {member.first_name} {member.last_name}
                  </p>
                  <p className="text-sm text-gray-500">{member.email}</p>
                </div>
              </div>
              <span className={clsx('px-2 py-1 text-xs rounded-full', roleColors[member.role])}>
                {member.role}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================
// SHARING TAB
// ============================================
function SharingTab({ dealRoomId }) {
  const [shareSettings, setShareSettings] = useState({
    expiresIn: 604800, // 7 days
    hasPassword: false,
    password: '',
    allowDownload: true,
  });

  const createShareMutation = useMutation({
    mutationFn: (data) => dealRooms.createShareLink(dealRoomId, data),
    onSuccess: (response) => {
      toast.success('Share link created');
      navigator.clipboard.writeText(response.data.shareUrl);
      toast.success('Link copied to clipboard');
    },
    onError: () => toast.error('Failed to create share link'),
  });

  const handleCreateLink = () => {
    createShareMutation.mutate({
      dealRoomId,
      expiresIn: shareSettings.expiresIn,
      password: shareSettings.hasPassword ? shareSettings.password : undefined,
      allowDownload: shareSettings.allowDownload,
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-semibold mb-4">Create Share Link</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Link Expiration</label>
            <select
              value={shareSettings.expiresIn}
              onChange={(e) => setShareSettings(s => ({ ...s, expiresIn: Number(e.target.value) }))}
              className="w-full px-3 py-2 border rounded-lg"
            >
              <option value={86400}>1 day</option>
              <option value={604800}>7 days</option>
              <option value={2592000}>30 days</option>
            </select>
          </div>

          <div>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={shareSettings.hasPassword}
                onChange={(e) => setShareSettings(s => ({ ...s, hasPassword: e.target.checked }))}
                className="rounded"
              />
              <span className="text-sm">Password protect</span>
            </label>
            {shareSettings.hasPassword && (
              <input
                type="password"
                value={shareSettings.password}
                onChange={(e) => setShareSettings(s => ({ ...s, password: e.target.value }))}
                placeholder="Enter password"
                className="mt-2 w-full px-3 py-2 border rounded-lg"
                minLength={8}
              />
            )}
          </div>

          <div>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={shareSettings.allowDownload}
                onChange={(e) => setShareSettings(s => ({ ...s, allowDownload: e.target.checked }))}
                className="rounded"
              />
              <span className="text-sm">Allow downloads</span>
            </label>
          </div>

          <button
            onClick={handleCreateLink}
            disabled={createShareMutation.isPending}
            className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {createShareMutation.isPending ? 'Creating...' : 'Create Share Link'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================
// UTILITY COMPONENTS & FUNCTIONS
// ============================================
function LoadingSkeleton() {
  return (
    <div className="space-y-3 animate-pulse">
      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
      <div className="h-4 bg-gray-200 rounded w-2/3"></div>
    </div>
  );
}

function ErrorMessage({ message }) {
  return (
    <div className="p-4 bg-red-50 text-red-700 rounded-lg">
      {message}
    </div>
  );
}

function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

async function calculateChecksum(file) {
  const buffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export default DealRoomDetail;
