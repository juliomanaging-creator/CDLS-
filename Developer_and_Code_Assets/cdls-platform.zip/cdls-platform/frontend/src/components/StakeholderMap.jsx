/**
 * CDLS Platform - Stakeholder Mapping Component
 * Visualize stakeholder relationships and track engagement
 */

import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  UserIcon,
  UserPlusIcon,
  ArrowsPointingOutIcon,
  ChartBarIcon,
  StarIcon,
  ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';
import { stakeholders } from '../services/api';
import toast from 'react-hot-toast';
import clsx from 'clsx';

// ============================================
// STAKEHOLDER MAP MAIN COMPONENT
// ============================================
export function StakeholderMap({ dealRoomId }) {
  const [view, setView] = useState('grid'); // 'grid' | 'chart' | 'matrix'
  const [selectedStakeholder, setSelectedStakeholder] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const { data: stakeholderData, isLoading } = useQuery({
    queryKey: ['stakeholders', dealRoomId],
    queryFn: () => stakeholders.list(dealRoomId, {}),
  });

  const { data: insightsData } = useQuery({
    queryKey: ['stakeholderInsights', dealRoomId],
    queryFn: () => stakeholders.getInsights(dealRoomId),
  });

  const { data: orgChartData } = useQuery({
    queryKey: ['orgChart', dealRoomId],
    queryFn: () => stakeholders.getOrgChart(dealRoomId),
    enabled: view === 'chart',
  });

  return (
    <div className="space-y-6">
      {/* Header with View Toggle */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Stakeholder Map</h2>
          <p className="text-gray-500">
            {stakeholderData?.data?.length || 0} stakeholders tracked
          </p>
        </div>
        
        <div className="flex gap-2">
          <div className="flex border rounded-lg overflow-hidden">
            {[
              { id: 'grid', icon: '▤', label: 'Grid' },
              { id: 'chart', icon: '◎', label: 'Org Chart' },
              { id: 'matrix', icon: '▦', label: 'Matrix' },
            ].map((v) => (
              <button
                key={v.id}
                onClick={() => setView(v.id)}
                className={clsx(
                  'px-4 py-2 text-sm',
                  view === v.id ? 'bg-blue-600 text-white' : 'hover:bg-gray-100'
                )}
              >
                {v.label}
              </button>
            ))}
          </div>
          
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <UserPlusIcon className="w-5 h-5" />
            Add Stakeholder
          </button>
        </div>
      </div>

      {/* Key Insights Cards */}
      <div className="grid grid-cols-4 gap-4">
        <InsightCard
          title="Champions"
          count={insightsData?.data?.champions?.length || 0}
          icon={StarIcon}
          color="green"
        />
        <InsightCard
          title="Blockers"
          count={insightsData?.data?.blockers?.length || 0}
          icon={ExclamationTriangleIcon}
          color="red"
        />
        <InsightCard
          title="Coverage Gaps"
          count={insightsData?.data?.coverageGaps?.length || 0}
          icon={ArrowsPointingOutIcon}
          color="amber"
        />
        <InsightCard
          title="Avg. Engagement"
          count={calculateAvgEngagement(stakeholderData?.data)}
          suffix="/100"
          icon={ChartBarIcon}
          color="blue"
        />
      </div>

      {/* Main View */}
      {isLoading ? (
        <LoadingSkeleton />
      ) : view === 'grid' ? (
        <StakeholderGrid
          stakeholders={stakeholderData?.data || []}
          onSelect={setSelectedStakeholder}
        />
      ) : view === 'chart' ? (
        <OrgChartView
          nodes={orgChartData?.data?.nodes || []}
          edges={orgChartData?.data?.edges || []}
          onNodeClick={setSelectedStakeholder}
        />
      ) : (
        <InfluenceMatrix stakeholders={stakeholderData?.data || []} />
      )}

      {/* Detail Sidebar */}
      {selectedStakeholder && (
        <StakeholderDetail
          dealRoomId={dealRoomId}
          stakeholderId={selectedStakeholder.id}
          onClose={() => setSelectedStakeholder(null)}
        />
      )}

      {/* Add Modal */}
      {showAddModal && (
        <AddStakeholderModal
          dealRoomId={dealRoomId}
          onClose={() => setShowAddModal(false)}
        />
      )}
    </div>
  );
}

// ============================================
// STAKEHOLDER GRID VIEW
// ============================================
function StakeholderGrid({ stakeholders, onSelect }) {
  const [filter, setFilter] = useState({ roleType: '', sentiment: '' });

  const filteredStakeholders = useMemo(() => {
    return stakeholders.filter((s) => {
      if (filter.roleType && s.role_type !== filter.roleType) return false;
      if (filter.sentiment && s.sentiment !== filter.sentiment) return false;
      return true;
    });
  }, [stakeholders, filter]);

  const roleTypeColors = {
    decision_maker: 'border-purple-500 bg-purple-50',
    influencer: 'border-blue-500 bg-blue-50',
    champion: 'border-green-500 bg-green-50',
    blocker: 'border-red-500 bg-red-50',
    end_user: 'border-gray-500 bg-gray-50',
    unknown: 'border-gray-300',
  };

  const sentimentIcons = {
    positive: '😊',
    neutral: '😐',
    negative: '😟',
    unknown: '❓',
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex gap-4">
        <select
          value={filter.roleType}
          onChange={(e) => setFilter((f) => ({ ...f, roleType: e.target.value }))}
          className="px-3 py-2 border rounded-lg"
        >
          <option value="">All Roles</option>
          <option value="decision_maker">Decision Makers</option>
          <option value="influencer">Influencers</option>
          <option value="champion">Champions</option>
          <option value="blocker">Blockers</option>
          <option value="end_user">End Users</option>
        </select>
        
        <select
          value={filter.sentiment}
          onChange={(e) => setFilter((f) => ({ ...f, sentiment: e.target.value }))}
          className="px-3 py-2 border rounded-lg"
        >
          <option value="">All Sentiments</option>
          <option value="positive">Positive</option>
          <option value="neutral">Neutral</option>
          <option value="negative">Negative</option>
        </select>
      </div>

      {/* Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredStakeholders.map((stakeholder) => (
          <div
            key={stakeholder.id}
            onClick={() => onSelect(stakeholder)}
            className={clsx(
              'p-4 border-l-4 rounded-lg bg-white shadow-sm cursor-pointer hover:shadow-md transition-shadow',
              roleTypeColors[stakeholder.role_type]
            )}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center text-lg font-semibold">
                  {stakeholder.first_name?.[0]}{stakeholder.last_name?.[0]}
                </div>
                <div>
                  <p className="font-medium">
                    {stakeholder.first_name} {stakeholder.last_name}
                  </p>
                  <p className="text-sm text-gray-500">{stakeholder.title}</p>
                </div>
              </div>
              <span className="text-xl" title={stakeholder.sentiment}>
                {sentimentIcons[stakeholder.sentiment]}
              </span>
            </div>

            <div className="mt-3 flex items-center justify-between text-sm">
              <span className="text-gray-500">{stakeholder.company}</span>
              {stakeholder.isChampion && (
                <span className="flex items-center gap-1 text-green-600">
                  <StarIcon className="w-4 h-4" /> Champion
                </span>
              )}
              {stakeholder.isBlocker && (
                <span className="flex items-center gap-1 text-red-600">
                  <ExclamationTriangleIcon className="w-4 h-4" /> Blocker
                </span>
              )}
            </div>

            {/* Engagement Score Bar */}
            <div className="mt-3">
              <div className="flex justify-between text-xs text-gray-500 mb-1">
                <span>Engagement</span>
                <span>{stakeholder.influenceScore || 0}/100</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className={clsx(
                    'h-full rounded-full',
                    stakeholder.influenceScore >= 70 ? 'bg-green-500' :
                    stakeholder.influenceScore >= 40 ? 'bg-yellow-500' : 'bg-red-500'
                  )}
                  style={{ width: `${stakeholder.influenceScore || 0}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================
// INFLUENCE MATRIX VIEW
// ============================================
function InfluenceMatrix({ stakeholders }) {
  // Group stakeholders by influence level and sentiment
  const matrix = useMemo(() => {
    const grid = {
      high: { positive: [], neutral: [], negative: [] },
      medium: { positive: [], neutral: [], negative: [] },
      low: { positive: [], neutral: [], negative: [] },
    };

    stakeholders.forEach((s) => {
      const influence = s.influence_level >= 4 ? 'high' : s.influence_level >= 2 ? 'medium' : 'low';
      const sentiment = s.sentiment || 'neutral';
      if (grid[influence] && grid[influence][sentiment]) {
        grid[influence][sentiment].push(s);
      }
    });

    return grid;
  }, [stakeholders]);

  const cellColors = {
    'high-positive': 'bg-green-100 border-green-300',
    'high-neutral': 'bg-yellow-100 border-yellow-300',
    'high-negative': 'bg-red-100 border-red-300',
    'medium-positive': 'bg-green-50 border-green-200',
    'medium-neutral': 'bg-yellow-50 border-yellow-200',
    'medium-negative': 'bg-red-50 border-red-200',
    'low-positive': 'bg-gray-50 border-gray-200',
    'low-neutral': 'bg-gray-50 border-gray-200',
    'low-negative': 'bg-gray-50 border-gray-200',
  };

  return (
    <div className="overflow-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            <th className="p-3 border bg-gray-50">Influence / Sentiment</th>
            <th className="p-3 border bg-green-50 text-green-700">Positive 😊</th>
            <th className="p-3 border bg-yellow-50 text-yellow-700">Neutral 😐</th>
            <th className="p-3 border bg-red-50 text-red-700">Negative 😟</th>
          </tr>
        </thead>
        <tbody>
          {['high', 'medium', 'low'].map((influence) => (
            <tr key={influence}>
              <th className="p-3 border bg-gray-50 font-medium capitalize">{influence}</th>
              {['positive', 'neutral', 'negative'].map((sentiment) => (
                <td
                  key={`${influence}-${sentiment}`}
                  className={clsx(
                    'p-3 border min-w-[200px] align-top',
                    cellColors[`${influence}-${sentiment}`]
                  )}
                >
                  <div className="space-y-2">
                    {matrix[influence][sentiment].map((s) => (
                      <div
                        key={s.id}
                        className="p-2 bg-white rounded shadow-sm text-sm"
                      >
                        <p className="font-medium">
                          {s.first_name} {s.last_name}
                        </p>
                        <p className="text-gray-500 text-xs">{s.title}</p>
                      </div>
                    ))}
                    {matrix[influence][sentiment].length === 0 && (
                      <p className="text-gray-400 text-sm italic">No stakeholders</p>
                    )}
                  </div>
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ============================================
// ORG CHART VIEW (Simplified)
// ============================================
function OrgChartView({ nodes, edges, onNodeClick }) {
  // Build hierarchy from edges
  const hierarchy = useMemo(() => {
    const nodeMap = new Map(nodes.map((n) => [n.id, { ...n, children: [] }]));
    const roots = [];

    edges
      .filter((e) => e.type === 'reports_to')
      .forEach((edge) => {
        const parent = nodeMap.get(edge.to);
        const child = nodeMap.get(edge.from);
        if (parent && child) {
          parent.children.push(child);
          child.hasParent = true;
        }
      });

    nodeMap.forEach((node) => {
      if (!node.hasParent) roots.push(node);
    });

    return roots;
  }, [nodes, edges]);

  const renderNode = (node, level = 0) => (
    <div key={node.id} className="flex flex-col items-center">
      <div
        onClick={() => onNodeClick(node)}
        className={clsx(
          'p-4 bg-white border-2 rounded-lg shadow-sm cursor-pointer hover:shadow-md min-w-[180px]',
          node.roleType === 'decision_maker' ? 'border-purple-500' :
          node.roleType === 'champion' ? 'border-green-500' :
          node.roleType === 'blocker' ? 'border-red-500' : 'border-gray-300'
        )}
      >
        <p className="font-medium text-center">{node.label}</p>
        <p className="text-sm text-gray-500 text-center">{node.title}</p>
      </div>
      
      {node.children?.length > 0 && (
        <>
          <div className="w-0.5 h-6 bg-gray-300" />
          <div className="flex gap-4">
            {node.children.map((child) => renderNode(child, level + 1))}
          </div>
        </>
      )}
    </div>
  );

  return (
    <div className="overflow-auto p-8 bg-gray-50 rounded-lg min-h-[400px]">
      <div className="flex flex-col items-center gap-4">
        {hierarchy.map((root) => renderNode(root))}
      </div>
      {hierarchy.length === 0 && (
        <p className="text-center text-gray-500">
          No reporting relationships defined. Add relationships to see the org chart.
        </p>
      )}
    </div>
  );
}

// ============================================
// STAKEHOLDER DETAIL SIDEBAR
// ============================================
function StakeholderDetail({ dealRoomId, stakeholderId, onClose }) {
  const { data, isLoading } = useQuery({
    queryKey: ['stakeholder', dealRoomId, stakeholderId],
    queryFn: () => stakeholders.get(dealRoomId, stakeholderId),
  });

  const stakeholder = data?.data;

  if (isLoading) return <div className="fixed inset-y-0 right-0 w-96 bg-white shadow-xl p-6">Loading...</div>;

  return (
    <div className="fixed inset-y-0 right-0 w-96 bg-white shadow-xl overflow-y-auto">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center text-2xl font-semibold">
              {stakeholder?.first_name?.[0]}{stakeholder?.last_name?.[0]}
            </div>
            <div>
              <h3 className="text-lg font-bold">
                {stakeholder?.first_name} {stakeholder?.last_name}
              </h3>
              <p className="text-gray-500">{stakeholder?.title}</p>
              <p className="text-sm text-gray-400">{stakeholder?.company}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">✕</button>
        </div>

        {/* Contact Info */}
        <div className="space-y-2">
          <h4 className="font-medium text-sm text-gray-500 uppercase">Contact</h4>
          {stakeholder?.email && <p className="text-sm">{stakeholder.email}</p>}
          {stakeholder?.phone && <p className="text-sm">{stakeholder.phone}</p>}
          {stakeholder?.linkedin_url && (
            <a href={stakeholder.linkedin_url} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-600">
              LinkedIn Profile
            </a>
          )}
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-500">Influence</p>
            <p className="text-xl font-bold">{stakeholder?.influence_level || '-'}/5</p>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-500">Engagement</p>
            <p className="text-xl font-bold">{stakeholder?.engagement_level || '-'}/5</p>
          </div>
        </div>

        {/* Recent Interactions */}
        <div>
          <h4 className="font-medium text-sm text-gray-500 uppercase mb-2">Recent Activity</h4>
          <div className="space-y-2">
            {stakeholder?.interactions?.slice(0, 5).map((interaction) => (
              <div key={interaction.id} className="p-2 bg-gray-50 rounded text-sm">
                <p className="font-medium">{interaction.interaction_type}</p>
                <p className="text-gray-500 text-xs">
                  {new Date(interaction.interaction_date).toLocaleDateString()}
                </p>
              </div>
            ))}
            {(!stakeholder?.interactions || stakeholder.interactions.length === 0) && (
              <p className="text-gray-400 text-sm">No recent interactions</p>
            )}
          </div>
        </div>

        {/* Notes */}
        {stakeholder?.notes && (
          <div>
            <h4 className="font-medium text-sm text-gray-500 uppercase mb-2">Notes</h4>
            <p className="text-sm text-gray-700 whitespace-pre-wrap">{stakeholder.notes}</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================
// ADD STAKEHOLDER MODAL
// ============================================
function AddStakeholderModal({ dealRoomId, onClose }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    title: '',
    company: '',
    roleType: 'unknown',
    influenceLevel: 3,
    sentiment: 'neutral',
  });

  const createMutation = useMutation({
    mutationFn: (data) => stakeholders.create(dealRoomId, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['stakeholders', dealRoomId]);
      toast.success('Stakeholder added');
      onClose();
    },
    onError: () => toast.error('Failed to add stakeholder'),
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-lg">
        <h3 className="text-lg font-bold mb-4">Add Stakeholder</h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="First Name *"
              value={formData.firstName}
              onChange={(e) => setFormData((f) => ({ ...f, firstName: e.target.value }))}
              className="px-3 py-2 border rounded-lg"
              required
            />
            <input
              type="text"
              placeholder="Last Name *"
              value={formData.lastName}
              onChange={(e) => setFormData((f) => ({ ...f, lastName: e.target.value }))}
              className="px-3 py-2 border rounded-lg"
              required
            />
          </div>
          
          <input
            type="email"
            placeholder="Email"
            value={formData.email}
            onChange={(e) => setFormData((f) => ({ ...f, email: e.target.value }))}
            className="w-full px-3 py-2 border rounded-lg"
          />
          
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="Title"
              value={formData.title}
              onChange={(e) => setFormData((f) => ({ ...f, title: e.target.value }))}
              className="px-3 py-2 border rounded-lg"
            />
            <input
              type="text"
              placeholder="Company"
              value={formData.company}
              onChange={(e) => setFormData((f) => ({ ...f, company: e.target.value }))}
              className="px-3 py-2 border rounded-lg"
            />
          </div>
          
          <select
            value={formData.roleType}
            onChange={(e) => setFormData((f) => ({ ...f, roleType: e.target.value }))}
            className="w-full px-3 py-2 border rounded-lg"
          >
            <option value="unknown">Select Role Type</option>
            <option value="decision_maker">Decision Maker</option>
            <option value="influencer">Influencer</option>
            <option value="champion">Champion</option>
            <option value="blocker">Blocker</option>
            <option value="end_user">End User</option>
          </select>

          <div className="flex justify-end gap-3">
            <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg">
              Cancel
            </button>
            <button
              type="submit"
              disabled={createMutation.isPending}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {createMutation.isPending ? 'Adding...' : 'Add Stakeholder'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============================================
// UTILITY COMPONENTS
// ============================================
function InsightCard({ title, count, suffix = '', icon: Icon, color }) {
  const colorClasses = {
    green: 'bg-green-50 text-green-700',
    red: 'bg-red-50 text-red-700',
    amber: 'bg-amber-50 text-amber-700',
    blue: 'bg-blue-50 text-blue-700',
  };

  return (
    <div className={clsx('p-4 rounded-lg', colorClasses[color])}>
      <div className="flex items-center gap-2">
        <Icon className="w-5 h-5" />
        <span className="text-sm font-medium">{title}</span>
      </div>
      <p className="mt-2 text-2xl font-bold">
        {count}{suffix}
      </p>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="grid gap-4 md:grid-cols-3 animate-pulse">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div key={i} className="h-32 bg-gray-200 rounded-lg" />
      ))}
    </div>
  );
}

function calculateAvgEngagement(stakeholders) {
  if (!stakeholders?.length) return 0;
  const total = stakeholders.reduce((sum, s) => sum + (s.influenceScore || 0), 0);
  return Math.round(total / stakeholders.length);
}

export default StakeholderMap;
