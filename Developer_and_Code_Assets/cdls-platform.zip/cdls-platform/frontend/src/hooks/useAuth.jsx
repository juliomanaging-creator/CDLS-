/**
 * CDLS Platform - Authentication Hook
 * Security Review: Secure token handling, session management
 */

import { useState, useEffect, useCallback, createContext, useContext } from 'react';
import { auth, setTokens, clearTokens, hasActiveSession } from '../services/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Check for existing session on mount
  useEffect(() => {
    const checkSession = async () => {
      if (hasActiveSession()) {
        try {
          // Validate session with server
          const response = await fetch('/api/auth/me', {
            credentials: 'include',
          });
          
          if (response.ok) {
            const data = await response.json();
            setUser(data.user);
          } else {
            clearTokens();
          }
        } catch (err) {
          console.error('Session check failed:', err);
          clearTokens();
        }
      }
      setLoading(false);
    };

    checkSession();
  }, []);

  const login = useCallback(async (email, password) => {
    setError(null);
    setLoading(true);

    try {
      // Input validation
      if (!email || !password) {
        throw new Error('Email and password are required');
      }

      // Email format validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        throw new Error('Invalid email format');
      }

      const response = await auth.login(email, password);
      
      setTokens(response.accessToken, response.refreshToken);
      setUser(response.user);
      
      return response.user;
    } catch (err) {
      setError(err.message || 'Login failed');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await auth.logout();
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      clearTokens();
      setUser(null);
      // Redirect to login
      window.location.href = '/login';
    }
  }, []);

  const register = useCallback(async (data) => {
    setError(null);
    setLoading(true);

    try {
      // Password strength validation
      if (data.password.length < 12) {
        throw new Error('Password must be at least 12 characters');
      }
      
      if (!/[A-Z]/.test(data.password)) {
        throw new Error('Password must contain at least one uppercase letter');
      }
      
      if (!/[a-z]/.test(data.password)) {
        throw new Error('Password must contain at least one lowercase letter');
      }
      
      if (!/[0-9]/.test(data.password)) {
        throw new Error('Password must contain at least one number');
      }
      
      if (!/[!@#$%^&*(),.?":{}|<>]/.test(data.password)) {
        throw new Error('Password must contain at least one special character');
      }

      const response = await auth.register(data);
      return response;
    } catch (err) {
      setError(err.message || 'Registration failed');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const forgotPassword = useCallback(async (email) => {
    setError(null);
    setLoading(true);

    try {
      await auth.forgotPassword(email);
      return true;
    } catch (err) {
      setError(err.message || 'Password reset request failed');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const value = {
    user,
    loading,
    error,
    isAuthenticated: !!user,
    login,
    logout,
    register,
    forgotPassword,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

/**
 * Protected Route Component
 */
export const ProtectedRoute = ({ children, requiredRoles = [] }) => {
  const { user, loading, isAuthenticated } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    window.location.href = '/login';
    return null;
  }

  if (requiredRoles.length > 0 && !requiredRoles.includes(user.role)) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Access Denied</h1>
          <p className="mt-2 text-gray-600">You don't have permission to view this page.</p>
        </div>
      </div>
    );
  }

  return children;
};

export default useAuth;
