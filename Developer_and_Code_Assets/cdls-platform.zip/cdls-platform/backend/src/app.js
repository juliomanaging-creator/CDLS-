/**
 * CDLS Platform - Main Application Entry Point
 * Security Review: Helmet, CORS, rate limiting, error handling
 */

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const compression = require('compression');
const morgan = require('morgan');

const config = require('./config');
const {
  securityHeaders,
  corsOptions,
  apiRateLimiter,
  authRateLimiter,
  sanitizeInput,
  requestLogger,
} = require('./middleware/security');

// Import route modules
const dealRoomsRouter = require('./modules/dealRooms');
const engagementRouter = require('./modules/engagementAnalytics');
const calculatorsRouter = require('./modules/roiCalculators');
const stakeholdersRouter = require('./modules/stakeholderMapping');
const actionPlansRouter = require('./modules/actionPlans');

const app = express();

// ============================================
// SECURITY MIDDLEWARE (Order Matters!)
// ============================================

// Security headers first
app.use(securityHeaders);

// CORS
app.use(cors(corsOptions));

// Compression
app.use(compression());

// Body parsing with size limits
app.use(express.json({ 
  limit: '10mb',
  strict: true,
}));
app.use(express.urlencoded({ 
  extended: true, 
  limit: '10mb',
}));

// Request logging
if (config.env !== 'test') {
  app.use(morgan('combined'));
}
app.use(requestLogger);

// Global input sanitization
app.use(sanitizeInput);

// ============================================
// HEALTH CHECK (No auth required)
// ============================================

app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: process.env.npm_package_version || '1.0.0',
  });
});

app.get('/ready', async (req, res) => {
  try {
    // Check database connection
    const { query } = require('./utils/database');
    await query('SELECT 1');
    
    res.json({ 
      status: 'ready',
      database: 'connected',
    });
  } catch (error) {
    res.status(503).json({ 
      status: 'not ready',
      database: 'disconnected',
    });
  }
});

// ============================================
// API ROUTES
// ============================================

// API rate limiting
app.use('/api', apiRateLimiter);

// Auth routes with stricter rate limiting
app.use('/api/auth', authRateLimiter);

// Mount route modules
app.use('/api/deal-rooms', dealRoomsRouter);
app.use('/api/analytics', engagementRouter);
app.use('/api/calculators', calculatorsRouter);
app.use('/api/stakeholders', stakeholdersRouter);
app.use('/api/action-plans', actionPlansRouter);

// ============================================
// ERROR HANDLING
// ============================================

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Not Found',
    code: 'NOT_FOUND',
    path: req.path,
  });
});

// Global error handler
app.use((err, req, res, next) => {
  // Log error details (but not to client)
  console.error('Unhandled error:', {
    error: err.message,
    stack: config.isProduction ? undefined : err.stack,
    requestId: req.requestId,
    path: req.path,
    method: req.method,
  });

  // CORS error
  if (err.message === 'Not allowed by CORS') {
    return res.status(403).json({
      error: 'CORS policy violation',
      code: 'CORS_ERROR',
    });
  }

  // JSON parsing error
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({
      error: 'Invalid JSON',
      code: 'INVALID_JSON',
    });
  }

  // Payload too large
  if (err.type === 'entity.too.large') {
    return res.status(413).json({
      error: 'Request payload too large',
      code: 'PAYLOAD_TOO_LARGE',
    });
  }

  // Database errors
  if (err.code && err.code.startsWith('23')) {
    return res.status(400).json({
      error: 'Database constraint violation',
      code: 'DB_CONSTRAINT_ERROR',
    });
  }

  // Default error response
  res.status(err.status || 500).json({
    error: config.isProduction ? 'Internal server error' : err.message,
    code: 'SERVER_ERROR',
    requestId: req.requestId,
  });
});

// ============================================
// GRACEFUL SHUTDOWN
// ============================================

const shutdown = async (signal) => {
  console.log(`\n${signal} received. Starting graceful shutdown...`);
  
  // Close server
  server.close(async () => {
    console.log('HTTP server closed.');
    
    // Close database connections
    try {
      const { pool } = require('./utils/database');
      await pool.end();
      console.log('Database connections closed.');
    } catch (error) {
      console.error('Error closing database:', error);
    }
    
    process.exit(0);
  });

  // Force close after 30 seconds
  setTimeout(() => {
    console.error('Forced shutdown after timeout');
    process.exit(1);
  }, 30000);
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Unhandled rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection:', reason);
});

// Uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  process.exit(1);
});

// ============================================
// START SERVER
// ============================================

const server = app.listen(config.port, () => {
  console.log(`
╔═══════════════════════════════════════════════════╗
║      CDLS Platform API Server                     ║
╠═══════════════════════════════════════════════════╣
║  Environment: ${config.env.padEnd(35)}║
║  Port: ${String(config.port).padEnd(42)}║
║  Time: ${new Date().toISOString().padEnd(42)}║
╚═══════════════════════════════════════════════════╝
  `);
});

module.exports = app;
