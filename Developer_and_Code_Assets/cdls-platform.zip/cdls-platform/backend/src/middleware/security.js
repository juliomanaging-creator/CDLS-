/**
 * CDLS Platform - Security Middleware
 * Security Review: JWT validation, rate limiting, input sanitization, CSRF protection
 */

const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const xss = require('xss');
const { v4: uuidv4 } = require('uuid');
const config = require('../config');

// ============================================
// JWT Authentication Middleware
// ============================================
const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ 
        error: 'Authentication required',
        code: 'AUTH_REQUIRED' 
      });
    }
    
    const token = authHeader.substring(7);
    
    // Verify token with strict options
    const decoded = jwt.verify(token, config.jwt.secret, {
      algorithms: ['HS256'], // Explicitly specify algorithm to prevent algorithm confusion attacks
      complete: true,
    });
    
    // Validate token payload
    if (!decoded.payload.userId || !decoded.payload.orgId) {
      return res.status(401).json({ 
        error: 'Invalid token payload',
        code: 'INVALID_TOKEN' 
      });
    }
    
    // Check token expiration (additional check)
    if (decoded.payload.exp < Date.now() / 1000) {
      return res.status(401).json({ 
        error: 'Token expired',
        code: 'TOKEN_EXPIRED' 
      });
    }
    
    // Attach user info to request
    req.user = {
      id: decoded.payload.userId,
      orgId: decoded.payload.orgId,
      role: decoded.payload.role,
      email: decoded.payload.email,
    };
    
    // Add request ID for tracing
    req.requestId = uuidv4();
    
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ 
        error: 'Token expired',
        code: 'TOKEN_EXPIRED' 
      });
    }
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ 
        error: 'Invalid token',
        code: 'INVALID_TOKEN' 
      });
    }
    console.error('Authentication error:', error);
    return res.status(500).json({ 
      error: 'Authentication failed',
      code: 'AUTH_ERROR' 
    });
  }
};

// ============================================
// Role-Based Authorization
// ============================================
const authorize = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ 
        error: 'Authentication required',
        code: 'AUTH_REQUIRED' 
      });
    }
    
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ 
        error: 'Insufficient permissions',
        code: 'FORBIDDEN' 
      });
    }
    
    next();
  };
};

// ============================================
// Rate Limiting
// ============================================
const createRateLimiter = (options = {}) => {
  return rateLimit({
    windowMs: options.windowMs || config.rateLimit.windowMs,
    max: options.max || config.rateLimit.maxRequests,
    message: {
      error: 'Too many requests, please try again later',
      code: 'RATE_LIMIT_EXCEEDED',
      retryAfter: Math.ceil((options.windowMs || config.rateLimit.windowMs) / 1000),
    },
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => {
      // Use user ID if authenticated, otherwise IP
      return req.user?.id || req.ip;
    },
    skip: (req) => {
      // Skip rate limiting for health checks
      return req.path === '/health';
    },
  });
};

// Stricter rate limit for authentication endpoints
const authRateLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts per window
});

// Standard API rate limiter
const apiRateLimiter = createRateLimiter();

// ============================================
// Input Sanitization
// ============================================
const sanitizeInput = (req, res, next) => {
  const sanitize = (obj) => {
    if (typeof obj === 'string') {
      return xss(obj.trim());
    }
    if (Array.isArray(obj)) {
      return obj.map(sanitize);
    }
    if (obj && typeof obj === 'object') {
      const sanitized = {};
      for (const [key, value] of Object.entries(obj)) {
        // Prevent prototype pollution
        if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
          continue;
        }
        sanitized[key] = sanitize(value);
      }
      return sanitized;
    }
    return obj;
  };
  
  if (req.body) {
    req.body = sanitize(req.body);
  }
  if (req.query) {
    req.query = sanitize(req.query);
  }
  if (req.params) {
    req.params = sanitize(req.params);
  }
  
  next();
};

// ============================================
// Security Headers (Helmet configuration)
// ============================================
const securityHeaders = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
    },
  },
  crossOriginEmbedderPolicy: true,
  crossOriginOpenerPolicy: true,
  crossOriginResourcePolicy: { policy: 'same-site' },
  dnsPrefetchControl: { allow: false },
  frameguard: { action: 'deny' },
  hidePoweredBy: true,
  hsts: {
    maxAge: 31536000, // 1 year
    includeSubDomains: true,
    preload: true,
  },
  ieNoOpen: true,
  noSniff: true,
  originAgentCluster: true,
  permittedCrossDomainPolicies: { permittedPolicies: 'none' },
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  xssFilter: true,
});

// ============================================
// CORS Configuration
// ============================================
const corsOptions = {
  origin: (origin, callback) => {
    // Allow requests with no origin (mobile apps, curl, etc.)
    if (!origin) return callback(null, true);
    
    if (config.cors.origins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID'],
  exposedHeaders: ['X-Request-ID'],
  maxAge: 86400, // 24 hours
};

// ============================================
// Request Logging (with PII protection)
// ============================================
const requestLogger = (req, res, next) => {
  const startTime = Date.now();
  
  // Mask sensitive data
  const maskSensitive = (obj) => {
    if (!obj) return obj;
    const masked = { ...obj };
    const sensitiveFields = ['password', 'token', 'secret', 'apiKey', 'authorization'];
    for (const field of sensitiveFields) {
      if (masked[field]) {
        masked[field] = '***REDACTED***';
      }
    }
    return masked;
  };
  
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    console.log(JSON.stringify({
      timestamp: new Date().toISOString(),
      requestId: req.requestId,
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      duration: `${duration}ms`,
      userId: req.user?.id,
      userAgent: req.get('user-agent'),
      ip: req.ip,
    }));
  });
  
  next();
};

// ============================================
// Deal Room Access Control
// ============================================
const checkDealRoomAccess = async (req, res, next) => {
  const { dealRoomId } = req.params;
  const userId = req.user.id;
  const orgId = req.user.orgId;
  
  // This would query the database - placeholder for now
  // In production, this checks if user has access to the specific deal room
  const hasAccess = await verifyDealRoomAccess(dealRoomId, userId, orgId);
  
  if (!hasAccess) {
    return res.status(403).json({
      error: 'Access denied to this deal room',
      code: 'DEAL_ROOM_ACCESS_DENIED',
    });
  }
  
  next();
};

// Placeholder - implement with actual database query
const verifyDealRoomAccess = async (dealRoomId, userId, orgId) => {
  // TODO: Implement actual database check
  return true;
};

module.exports = {
  authenticate,
  authorize,
  authRateLimiter,
  apiRateLimiter,
  createRateLimiter,
  sanitizeInput,
  securityHeaders,
  corsOptions,
  requestLogger,
  checkDealRoomAccess,
};
