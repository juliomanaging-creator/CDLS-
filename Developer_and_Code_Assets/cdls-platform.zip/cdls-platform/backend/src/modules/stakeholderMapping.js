/**
 * CDLS Platform - Module 4: Stakeholder Mapping & Multithreading
 * Security Review: PII protection, access control, input validation
 */

const express = require('express');
const Joi = require('joi');
const { query, transaction, buildPaginationClause } = require('../utils/database');
const { authenticate, checkDealRoomAccess, sanitizeInput } = require('../middleware/security');

const router = express.Router();

// ============================================
// VALIDATION SCHEMAS
// ============================================

const createStakeholderSchema = Joi.object({
  firstName: Joi.string().trim().min(1).max(100).required(),
  lastName: Joi.string().trim().min(1).max(100).required(),
  email: Joi.string().email().max(255).allow('', null),
  phone: Joi.string().max(50).pattern(/^[\d\s\-+()]*$/).allow('', null),
  title: Joi.string().trim().max(200).allow('', null),
  department: Joi.string().trim().max(200).allow('', null),
  company: Joi.string().trim().max(255).allow('', null),
  roleType: Joi.string().valid('decision_maker', 'influencer', 'champion', 'blocker', 'end_user', 'unknown').default('unknown'),
  influenceLevel: Joi.number().integer().min(1).max(5).allow(null),
  engagementLevel: Joi.number().integer().min(1).max(5).allow(null),
  sentiment: Joi.string().valid('positive', 'neutral', 'negative', 'unknown').default('unknown'),
  linkedinUrl: Joi.string().uri().max(500).allow('', null),
  notes: Joi.string().trim().max(5000).allow('', null),
  isPrimaryContact: Joi.boolean().default(false),
});

const updateStakeholderSchema = createStakeholderSchema.fork(
  ['firstName', 'lastName'],
  (schema) => schema.optional()
);

const createRelationshipSchema = Joi.object({
  fromStakeholderId: Joi.string().uuid().required(),
  toStakeholderId: Joi.string().uuid().required(),
  relationshipType: Joi.string().valid('reports_to', 'manages', 'collaborates', 'influences', 'advises').required(),
  strength: Joi.number().integer().min(1).max(5).allow(null),
  notes: Joi.string().trim().max(1000).allow('', null),
});

const createInteractionSchema = Joi.object({
  stakeholderId: Joi.string().uuid().required(),
  interactionType: Joi.string().valid('email', 'call', 'meeting', 'document_view', 'calculator_use', 'comment', 'other').required(),
  subject: Joi.string().trim().max(255).allow('', null),
  summary: Joi.string().trim().max(5000).allow('', null),
  sentiment: Joi.string().valid('positive', 'neutral', 'negative').allow(null),
  outcome: Joi.string().trim().max(100).allow('', null),
  nextSteps: Joi.string().trim().max(2000).allow('', null),
  interactionDate: Joi.date().iso().required(),
  durationMinutes: Joi.number().integer().min(0).max(1440).allow(null),
  metadata: Joi.object().default({}),
});

// ============================================
// HELPER FUNCTIONS
// ============================================

// Calculate stakeholder influence score
const calculateInfluenceScore = (stakeholder, interactions, engagementEvents) => {
  let score = 0;

  // Base score from role type
  const roleScores = {
    decision_maker: 40,
    influencer: 30,
    champion: 35,
    blocker: 25,
    end_user: 15,
    unknown: 10,
  };
  score += roleScores[stakeholder.role_type] || 10;

  // Influence level contribution (1-5 scale -> 0-20 points)
  if (stakeholder.influence_level) {
    score += stakeholder.influence_level * 4;
  }

  // Engagement level contribution
  if (stakeholder.engagement_level) {
    score += stakeholder.engagement_level * 3;
  }

  // Sentiment contribution
  const sentimentScores = { positive: 10, neutral: 5, negative: -5, unknown: 0 };
  score += sentimentScores[stakeholder.sentiment] || 0;

  // Recent interactions boost
  const recentInteractions = interactions.filter(
    i => new Date(i.interaction_date) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
  );
  score += Math.min(recentInteractions.length * 2, 15);

  // Document engagement boost
  const docViews = engagementEvents.filter(e => e.event_type === 'document_view').length;
  score += Math.min(docViews, 10);

  return Math.min(100, Math.max(0, score));
};

// Determine champion status
const isChampion = (stakeholder, influenceScore) => {
  return (
    stakeholder.sentiment === 'positive' &&
    influenceScore >= 60 &&
    stakeholder.engagement_level >= 4
  );
};

// Identify blockers
const isBlocker = (stakeholder) => {
  return (
    stakeholder.role_type === 'blocker' ||
    (stakeholder.sentiment === 'negative' && stakeholder.influence_level >= 4)
  );
};

// ============================================
// STAKEHOLDER ROUTES
// ============================================

// Create stakeholder
router.post('/:dealRoomId/stakeholders', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { error, value } = createStakeholderSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const {
      firstName, lastName, email, phone, title, department, company,
      roleType, influenceLevel, engagementLevel, sentiment, linkedinUrl,
      notes, isPrimaryContact,
    } = value;

    // Check for duplicate email in same deal room
    if (email) {
      const duplicateCheck = await query(
        'SELECT id FROM stakeholders WHERE deal_room_id = $1 AND email = $2',
        [dealRoomId, email]
      );
      if (duplicateCheck.rows.length > 0) {
        return res.status(409).json({ error: 'Stakeholder with this email already exists', code: 'DUPLICATE_EMAIL' });
      }
    }

    const result = await query(
      `INSERT INTO stakeholders 
       (deal_room_id, first_name, last_name, email, phone, title, department, company,
        role_type, influence_level, engagement_level, sentiment, linkedin_url, notes, is_primary_contact, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
       RETURNING *`,
      [dealRoomId, firstName, lastName, email, phone, title, department, company,
       roleType, influenceLevel, engagementLevel, sentiment, linkedinUrl, notes, isPrimaryContact, req.user.id]
    );

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Create stakeholder error:', error);
    res.status(500).json({ error: 'Failed to create stakeholder', code: 'SERVER_ERROR' });
  }
});

// List stakeholders
router.get('/:dealRoomId/stakeholders', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { roleType, sentiment, search, page, limit } = req.query;
    const pagination = buildPaginationClause(page, limit, 100);

    let whereConditions = ['deal_room_id = $1'];
    const params = [dealRoomId];
    let paramIndex = 2;

    if (roleType) {
      whereConditions.push(`role_type = $${paramIndex}`);
      params.push(roleType);
      paramIndex++;
    }

    if (sentiment) {
      whereConditions.push(`sentiment = $${paramIndex}`);
      params.push(sentiment);
      paramIndex++;
    }

    if (search) {
      whereConditions.push(
        `(first_name ILIKE $${paramIndex} OR last_name ILIKE $${paramIndex} OR email ILIKE $${paramIndex} OR company ILIKE $${paramIndex})`
      );
      params.push(`%${search.replace(/[%_]/g, '\\$&')}%`);
      paramIndex++;
    }

    const whereClause = whereConditions.join(' AND ');

    const result = await query(
      `SELECT s.*,
              (SELECT COUNT(*) FROM stakeholder_interactions si WHERE si.stakeholder_id = s.id) as interaction_count,
              (SELECT MAX(interaction_date) FROM stakeholder_interactions si WHERE si.stakeholder_id = s.id) as last_interaction
       FROM stakeholders s
       WHERE ${whereClause}
       ORDER BY s.is_primary_contact DESC, s.influence_level DESC NULLS LAST, s.last_name
       ${pagination.clause}`,
      params
    );

    // Enrich with influence scores
    const enrichedStakeholders = await Promise.all(result.rows.map(async (stakeholder) => {
      const interactions = await query(
        'SELECT interaction_date FROM stakeholder_interactions WHERE stakeholder_id = $1',
        [stakeholder.id]
      );
      
      const engagementEvents = await query(
        `SELECT event_type FROM engagement_events 
         WHERE deal_room_id = $1 AND user_id = $2`,
        [dealRoomId, stakeholder.user_id]
      );

      const influenceScore = calculateInfluenceScore(stakeholder, interactions.rows, engagementEvents.rows);

      return {
        ...stakeholder,
        influenceScore,
        isChampion: isChampion(stakeholder, influenceScore),
        isBlocker: isBlocker(stakeholder),
      };
    }));

    res.json({ data: enrichedStakeholders, pagination });
  } catch (error) {
    console.error('List stakeholders error:', error);
    res.status(500).json({ error: 'Failed to list stakeholders', code: 'SERVER_ERROR' });
  }
});

// Get stakeholder by ID
router.get('/:dealRoomId/stakeholders/:stakeholderId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId, stakeholderId } = req.params;

    const result = await query(
      `SELECT s.*,
              u.first_name as created_by_first, u.last_name as created_by_last
       FROM stakeholders s
       LEFT JOIN users u ON s.created_by = u.id
       WHERE s.id = $1 AND s.deal_room_id = $2`,
      [stakeholderId, dealRoomId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Stakeholder not found', code: 'NOT_FOUND' });
    }

    const stakeholder = result.rows[0];

    // Get interactions
    const interactions = await query(
      `SELECT * FROM stakeholder_interactions
       WHERE stakeholder_id = $1
       ORDER BY interaction_date DESC
       LIMIT 10`,
      [stakeholderId]
    );

    // Get relationships
    const relationships = await query(
      `SELECT sr.*, 
              s.first_name, s.last_name, s.title, s.company
       FROM stakeholder_relationships sr
       JOIN stakeholders s ON (
         CASE WHEN sr.from_stakeholder_id = $1 THEN sr.to_stakeholder_id = s.id
              ELSE sr.from_stakeholder_id = s.id END
       )
       WHERE sr.from_stakeholder_id = $1 OR sr.to_stakeholder_id = $1`,
      [stakeholderId]
    );

    // Get engagement events if linked to user
    let engagementEvents = [];
    if (stakeholder.user_id) {
      const events = await query(
        `SELECT event_type, COUNT(*) as count, MAX(created_at) as last_event
         FROM engagement_events
         WHERE deal_room_id = $1 AND user_id = $2
         GROUP BY event_type`,
        [dealRoomId, stakeholder.user_id]
      );
      engagementEvents = events.rows;
    }

    const influenceScore = calculateInfluenceScore(stakeholder, interactions.rows, engagementEvents);

    res.json({
      data: {
        ...stakeholder,
        interactions: interactions.rows,
        relationships: relationships.rows,
        engagementEvents,
        influenceScore,
        isChampion: isChampion(stakeholder, influenceScore),
        isBlocker: isBlocker(stakeholder),
      },
    });
  } catch (error) {
    console.error('Get stakeholder error:', error);
    res.status(500).json({ error: 'Failed to get stakeholder', code: 'SERVER_ERROR' });
  }
});

// Update stakeholder
router.patch('/:dealRoomId/stakeholders/:stakeholderId', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId, stakeholderId } = req.params;
    const { error, value } = updateStakeholderSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Build dynamic update
    const fieldMapping = {
      firstName: 'first_name',
      lastName: 'last_name',
      email: 'email',
      phone: 'phone',
      title: 'title',
      department: 'department',
      company: 'company',
      roleType: 'role_type',
      influenceLevel: 'influence_level',
      engagementLevel: 'engagement_level',
      sentiment: 'sentiment',
      linkedinUrl: 'linkedin_url',
      notes: 'notes',
      isPrimaryContact: 'is_primary_contact',
    };

    const updates = [];
    const params = [];
    let paramIndex = 1;

    for (const [jsField, dbField] of Object.entries(fieldMapping)) {
      if (value[jsField] !== undefined) {
        updates.push(`${dbField} = $${paramIndex}`);
        params.push(value[jsField]);
        paramIndex++;
      }
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No valid fields to update', code: 'VALIDATION_ERROR' });
    }

    params.push(stakeholderId, dealRoomId);

    const result = await query(
      `UPDATE stakeholders SET ${updates.join(', ')}
       WHERE id = $${paramIndex} AND deal_room_id = $${paramIndex + 1}
       RETURNING *`,
      params
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Stakeholder not found', code: 'NOT_FOUND' });
    }

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Update stakeholder error:', error);
    res.status(500).json({ error: 'Failed to update stakeholder', code: 'SERVER_ERROR' });
  }
});

// Delete stakeholder
router.delete('/:dealRoomId/stakeholders/:stakeholderId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId, stakeholderId } = req.params;

    const result = await query(
      'DELETE FROM stakeholders WHERE id = $1 AND deal_room_id = $2 RETURNING id',
      [stakeholderId, dealRoomId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Stakeholder not found', code: 'NOT_FOUND' });
    }

    res.json({ message: 'Stakeholder deleted successfully' });
  } catch (error) {
    console.error('Delete stakeholder error:', error);
    res.status(500).json({ error: 'Failed to delete stakeholder', code: 'SERVER_ERROR' });
  }
});

// ============================================
// RELATIONSHIP ROUTES
// ============================================

// Create relationship
router.post('/:dealRoomId/relationships', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { error, value } = createRelationshipSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { fromStakeholderId, toStakeholderId, relationshipType, strength, notes } = value;

    // Verify both stakeholders exist in this deal room
    const stakeholderCheck = await query(
      'SELECT id FROM stakeholders WHERE id IN ($1, $2) AND deal_room_id = $3',
      [fromStakeholderId, toStakeholderId, dealRoomId]
    );

    if (stakeholderCheck.rows.length !== 2) {
      return res.status(400).json({ error: 'One or both stakeholders not found', code: 'INVALID_STAKEHOLDERS' });
    }

    const result = await query(
      `INSERT INTO stakeholder_relationships (deal_room_id, from_stakeholder_id, to_stakeholder_id, relationship_type, strength, notes)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [dealRoomId, fromStakeholderId, toStakeholderId, relationshipType, strength, notes]
    );

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') { // Unique violation
      return res.status(409).json({ error: 'Relationship already exists', code: 'DUPLICATE_RELATIONSHIP' });
    }
    console.error('Create relationship error:', error);
    res.status(500).json({ error: 'Failed to create relationship', code: 'SERVER_ERROR' });
  }
});

// Get org chart data
router.get('/:dealRoomId/org-chart', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;

    // Get all stakeholders
    const stakeholders = await query(
      `SELECT id, first_name, last_name, title, department, company, role_type,
              influence_level, engagement_level, sentiment, is_primary_contact
       FROM stakeholders
       WHERE deal_room_id = $1
       ORDER BY influence_level DESC NULLS LAST`,
      [dealRoomId]
    );

    // Get all relationships
    const relationships = await query(
      `SELECT * FROM stakeholder_relationships WHERE deal_room_id = $1`,
      [dealRoomId]
    );

    // Build hierarchical structure
    const nodes = stakeholders.rows.map(s => ({
      id: s.id,
      label: `${s.first_name} ${s.last_name}`,
      title: s.title,
      department: s.department,
      company: s.company,
      roleType: s.role_type,
      influenceLevel: s.influence_level,
      sentiment: s.sentiment,
      isPrimaryContact: s.is_primary_contact,
    }));

    const edges = relationships.rows.map(r => ({
      id: r.id,
      from: r.from_stakeholder_id,
      to: r.to_stakeholder_id,
      type: r.relationship_type,
      strength: r.strength,
    }));

    res.json({
      data: {
        nodes,
        edges,
      },
    });
  } catch (error) {
    console.error('Get org chart error:', error);
    res.status(500).json({ error: 'Failed to get org chart', code: 'SERVER_ERROR' });
  }
});

// Delete relationship
router.delete('/:dealRoomId/relationships/:relationshipId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId, relationshipId } = req.params;

    const result = await query(
      'DELETE FROM stakeholder_relationships WHERE id = $1 AND deal_room_id = $2 RETURNING id',
      [relationshipId, dealRoomId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Relationship not found', code: 'NOT_FOUND' });
    }

    res.json({ message: 'Relationship deleted successfully' });
  } catch (error) {
    console.error('Delete relationship error:', error);
    res.status(500).json({ error: 'Failed to delete relationship', code: 'SERVER_ERROR' });
  }
});

// ============================================
// INTERACTION ROUTES
// ============================================

// Log interaction
router.post('/:dealRoomId/interactions', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { error, value } = createInteractionSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const {
      stakeholderId, interactionType, subject, summary, sentiment,
      outcome, nextSteps, interactionDate, durationMinutes, metadata,
    } = value;

    // Verify stakeholder exists in this deal room
    const stakeholderCheck = await query(
      'SELECT id FROM stakeholders WHERE id = $1 AND deal_room_id = $2',
      [stakeholderId, dealRoomId]
    );

    if (stakeholderCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Stakeholder not found', code: 'NOT_FOUND' });
    }

    const result = await query(
      `INSERT INTO stakeholder_interactions 
       (stakeholder_id, deal_room_id, interaction_type, subject, summary, sentiment, outcome, next_steps, interaction_date, duration_minutes, metadata, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       RETURNING *`,
      [stakeholderId, dealRoomId, interactionType, subject, summary, sentiment, outcome, nextSteps, interactionDate, durationMinutes, metadata, req.user.id]
    );

    // Update stakeholder's last_contact_at
    await query(
      'UPDATE stakeholders SET last_contact_at = $1 WHERE id = $2',
      [interactionDate, stakeholderId]
    );

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Log interaction error:', error);
    res.status(500).json({ error: 'Failed to log interaction', code: 'SERVER_ERROR' });
  }
});

// Get interactions timeline
router.get('/:dealRoomId/interactions', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { stakeholderId, interactionType, startDate, endDate, page, limit } = req.query;
    const pagination = buildPaginationClause(page, limit, 50);

    let whereConditions = ['si.deal_room_id = $1'];
    const params = [dealRoomId];
    let paramIndex = 2;

    if (stakeholderId) {
      whereConditions.push(`si.stakeholder_id = $${paramIndex}`);
      params.push(stakeholderId);
      paramIndex++;
    }

    if (interactionType) {
      whereConditions.push(`si.interaction_type = $${paramIndex}`);
      params.push(interactionType);
      paramIndex++;
    }

    if (startDate) {
      whereConditions.push(`si.interaction_date >= $${paramIndex}`);
      params.push(startDate);
      paramIndex++;
    }

    if (endDate) {
      whereConditions.push(`si.interaction_date <= $${paramIndex}`);
      params.push(endDate);
      paramIndex++;
    }

    const whereClause = whereConditions.join(' AND ');

    const result = await query(
      `SELECT si.*, 
              s.first_name, s.last_name, s.title, s.company,
              u.first_name as created_by_first, u.last_name as created_by_last
       FROM stakeholder_interactions si
       JOIN stakeholders s ON si.stakeholder_id = s.id
       LEFT JOIN users u ON si.created_by = u.id
       WHERE ${whereClause}
       ORDER BY si.interaction_date DESC
       ${pagination.clause}`,
      params
    );

    res.json({ data: result.rows, pagination });
  } catch (error) {
    console.error('Get interactions error:', error);
    res.status(500).json({ error: 'Failed to get interactions', code: 'SERVER_ERROR' });
  }
});

// ============================================
// ANALYTICS ROUTES
// ============================================

// Get stakeholder insights
router.get('/:dealRoomId/insights', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;

    // Role distribution
    const roleDistribution = await query(
      `SELECT role_type, COUNT(*) as count
       FROM stakeholders WHERE deal_room_id = $1
       GROUP BY role_type`,
      [dealRoomId]
    );

    // Sentiment distribution
    const sentimentDistribution = await query(
      `SELECT sentiment, COUNT(*) as count
       FROM stakeholders WHERE deal_room_id = $1
       GROUP BY sentiment`,
      [dealRoomId]
    );

    // Champions and blockers
    const championsAndBlockers = await query(
      `SELECT id, first_name, last_name, title, role_type, sentiment, influence_level, engagement_level
       FROM stakeholders
       WHERE deal_room_id = $1 
       AND (
         (sentiment = 'positive' AND engagement_level >= 4)
         OR role_type = 'blocker'
         OR (sentiment = 'negative' AND influence_level >= 4)
       )`,
      [dealRoomId]
    );

    // Interaction frequency
    const interactionFrequency = await query(
      `SELECT DATE_TRUNC('week', interaction_date) as week, COUNT(*) as count
       FROM stakeholder_interactions
       WHERE deal_room_id = $1 AND interaction_date > NOW() - INTERVAL '12 weeks'
       GROUP BY DATE_TRUNC('week', interaction_date)
       ORDER BY week`,
      [dealRoomId]
    );

    // Coverage gaps - high influence but low engagement
    const coverageGaps = await query(
      `SELECT s.id, s.first_name, s.last_name, s.title, s.influence_level, s.engagement_level, s.last_contact_at
       FROM stakeholders s
       WHERE s.deal_room_id = $1
       AND s.influence_level >= 4
       AND (s.engagement_level IS NULL OR s.engagement_level <= 2 OR s.last_contact_at < NOW() - INTERVAL '14 days')`,
      [dealRoomId]
    );

    res.json({
      data: {
        roleDistribution: roleDistribution.rows,
        sentimentDistribution: sentimentDistribution.rows,
        champions: championsAndBlockers.rows.filter(s => 
          s.sentiment === 'positive' && s.engagement_level >= 4 && s.role_type !== 'blocker'
        ),
        blockers: championsAndBlockers.rows.filter(s => 
          s.role_type === 'blocker' || (s.sentiment === 'negative' && s.influence_level >= 4)
        ),
        interactionFrequency: interactionFrequency.rows,
        coverageGaps: coverageGaps.rows,
      },
    });
  } catch (error) {
    console.error('Get insights error:', error);
    res.status(500).json({ error: 'Failed to get insights', code: 'SERVER_ERROR' });
  }
});

module.exports = router;
