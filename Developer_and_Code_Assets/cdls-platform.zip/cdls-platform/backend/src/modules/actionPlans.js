/**
 * CDLS Platform - Module 5: Mutual Action Plans
 * Security Review: Input validation, access control, task ownership verification
 */

const express = require('express');
const Joi = require('joi');
const { query, transaction, buildPaginationClause } = require('../utils/database');
const { authenticate, checkDealRoomAccess, sanitizeInput } = require('../middleware/security');

const router = express.Router();

// ============================================
// VALIDATION SCHEMAS
// ============================================

const createActionPlanSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255).required(),
  description: Joi.string().trim().max(5000).allow('', null),
  targetCloseDate: Joi.date().iso().min('now').allow(null),
  isSharedWithBuyer: Joi.boolean().default(false),
});

const updateActionPlanSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255),
  description: Joi.string().trim().max(5000).allow('', null),
  status: Joi.string().valid('draft', 'active', 'completed', 'cancelled'),
  targetCloseDate: Joi.date().iso().allow(null),
  isSharedWithBuyer: Joi.boolean(),
}).min(1);

const createMilestoneSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255).required(),
  description: Joi.string().trim().max(2000).allow('', null),
  sequenceOrder: Joi.number().integer().min(0).required(),
  dueDate: Joi.date().iso().allow(null),
  ownerType: Joi.string().valid('seller', 'buyer', 'both').allow(null),
});

const updateMilestoneSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255),
  description: Joi.string().trim().max(2000).allow('', null),
  status: Joi.string().valid('pending', 'in_progress', 'completed', 'blocked', 'skipped'),
  sequenceOrder: Joi.number().integer().min(0),
  dueDate: Joi.date().iso().allow(null),
  ownerType: Joi.string().valid('seller', 'buyer', 'both').allow(null),
}).min(1);

const createActionItemSchema = Joi.object({
  milestoneId: Joi.string().uuid().required(),
  title: Joi.string().trim().min(1).max(255).required(),
  description: Joi.string().trim().max(5000).allow('', null),
  priority: Joi.string().valid('low', 'medium', 'high', 'critical').default('medium'),
  ownerType: Joi.string().valid('seller', 'buyer').allow(null),
  assignedTo: Joi.string().uuid().allow(null),
  stakeholderId: Joi.string().uuid().allow(null),
  dueDate: Joi.date().iso().allow(null),
  sequenceOrder: Joi.number().integer().min(0).required(),
  dependencies: Joi.array().items(Joi.string().uuid()).default([]),
});

const updateActionItemSchema = Joi.object({
  title: Joi.string().trim().min(1).max(255),
  description: Joi.string().trim().max(5000).allow('', null),
  status: Joi.string().valid('pending', 'in_progress', 'completed', 'blocked', 'cancelled'),
  priority: Joi.string().valid('low', 'medium', 'high', 'critical'),
  ownerType: Joi.string().valid('seller', 'buyer').allow(null),
  assignedTo: Joi.string().uuid().allow(null),
  stakeholderId: Joi.string().uuid().allow(null),
  dueDate: Joi.date().iso().allow(null),
  sequenceOrder: Joi.number().integer().min(0),
  dependencies: Joi.array().items(Joi.string().uuid()),
}).min(1);

const createCommentSchema = Joi.object({
  content: Joi.string().trim().min(1).max(5000).required(),
  isInternal: Joi.boolean().default(false),
});

// ============================================
// HELPER FUNCTIONS
// ============================================

const calculateProgress = async (actionPlanId) => {
  const result = await query(
    `SELECT 
       COUNT(*) as total,
       COUNT(*) FILTER (WHERE status = 'completed') as completed
     FROM action_items
     WHERE action_plan_id = $1 AND status != 'cancelled'`,
    [actionPlanId]
  );

  const { total, completed } = result.rows[0];
  const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;

  await query(
    'UPDATE action_plans SET progress_percentage = $1 WHERE id = $2',
    [percentage, actionPlanId]
  );

  return percentage;
};

const checkDependenciesComplete = async (dependencies) => {
  if (!dependencies || dependencies.length === 0) return true;

  const result = await query(
    `SELECT COUNT(*) as incomplete
     FROM action_items
     WHERE id = ANY($1) AND status != 'completed'`,
    [dependencies]
  );

  return parseInt(result.rows[0].incomplete, 10) === 0;
};

const logAudit = async (userId, orgId, action, entityType, entityId, oldValues, newValues, req) => {
  await query(
    `INSERT INTO audit_logs (user_id, org_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent, request_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
    [userId, orgId, action, entityType, entityId, JSON.stringify(oldValues), JSON.stringify(newValues), req.ip, req.get('user-agent'), req.requestId]
  );
};

// ============================================
// ACTION PLAN ROUTES
// ============================================

// Create action plan
router.post('/:dealRoomId/action-plans', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { error, value } = createActionPlanSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { name, description, targetCloseDate, isSharedWithBuyer } = value;

    const result = await query(
      `INSERT INTO action_plans (deal_room_id, name, description, target_close_date, is_shared_with_buyer, created_by)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [dealRoomId, name, description, targetCloseDate, isSharedWithBuyer, req.user.id]
    );

    await logAudit(req.user.id, req.user.orgId, 'CREATE', 'action_plan', result.rows[0].id, null, result.rows[0], req);

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Create action plan error:', error);
    res.status(500).json({ error: 'Failed to create action plan', code: 'SERVER_ERROR' });
  }
});

// List action plans
router.get('/:dealRoomId/action-plans', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { status, page, limit } = req.query;
    const pagination = buildPaginationClause(page, limit, 20);

    let whereClause = 'deal_room_id = $1';
    const params = [dealRoomId];

    if (status) {
      whereClause += ' AND status = $2';
      params.push(status);
    }

    const result = await query(
      `SELECT ap.*,
              (SELECT COUNT(*) FROM milestones m WHERE m.action_plan_id = ap.id) as milestone_count,
              (SELECT COUNT(*) FROM action_items ai WHERE ai.action_plan_id = ap.id) as item_count,
              (SELECT COUNT(*) FROM action_items ai WHERE ai.action_plan_id = ap.id AND ai.status = 'completed') as completed_count,
              u.first_name || ' ' || u.last_name as created_by_name
       FROM action_plans ap
       LEFT JOIN users u ON ap.created_by = u.id
       WHERE ${whereClause}
       ORDER BY ap.created_at DESC
       ${pagination.clause}`,
      params
    );

    res.json({ data: result.rows, pagination });
  } catch (error) {
    console.error('List action plans error:', error);
    res.status(500).json({ error: 'Failed to list action plans', code: 'SERVER_ERROR' });
  }
});

// Get action plan with full details
router.get('/:dealRoomId/action-plans/:planId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId, planId } = req.params;

    const planResult = await query(
      `SELECT ap.*, u.first_name || ' ' || u.last_name as created_by_name
       FROM action_plans ap
       LEFT JOIN users u ON ap.created_by = u.id
       WHERE ap.id = $1 AND ap.deal_room_id = $2`,
      [planId, dealRoomId]
    );

    if (planResult.rows.length === 0) {
      return res.status(404).json({ error: 'Action plan not found', code: 'NOT_FOUND' });
    }

    // Get milestones with their action items
    const milestonesResult = await query(
      `SELECT m.*,
              json_agg(
                json_build_object(
                  'id', ai.id,
                  'title', ai.title,
                  'description', ai.description,
                  'status', ai.status,
                  'priority', ai.priority,
                  'ownerType', ai.owner_type,
                  'assignedTo', ai.assigned_to,
                  'dueDate', ai.due_date,
                  'completedDate', ai.completed_date,
                  'sequenceOrder', ai.sequence_order,
                  'dependencies', ai.dependencies
                ) ORDER BY ai.sequence_order
              ) FILTER (WHERE ai.id IS NOT NULL) as action_items
       FROM milestones m
       LEFT JOIN action_items ai ON m.id = ai.milestone_id
       WHERE m.action_plan_id = $1
       GROUP BY m.id
       ORDER BY m.sequence_order`,
      [planId]
    );

    res.json({
      data: {
        ...planResult.rows[0],
        milestones: milestonesResult.rows,
      },
    });
  } catch (error) {
    console.error('Get action plan error:', error);
    res.status(500).json({ error: 'Failed to get action plan', code: 'SERVER_ERROR' });
  }
});

// Update action plan
router.patch('/:dealRoomId/action-plans/:planId', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId, planId } = req.params;
    const { error, value } = updateActionPlanSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Get current values
    const current = await query(
      'SELECT * FROM action_plans WHERE id = $1 AND deal_room_id = $2',
      [planId, dealRoomId]
    );

    if (current.rows.length === 0) {
      return res.status(404).json({ error: 'Action plan not found', code: 'NOT_FOUND' });
    }

    const fieldMapping = {
      name: 'name',
      description: 'description',
      status: 'status',
      targetCloseDate: 'target_close_date',
      isSharedWithBuyer: 'is_shared_with_buyer',
    };

    const updates = [];
    const params = [];
    let paramIndex = 1;

    for (const [jsField, dbField] of Object.entries(fieldMapping)) {
      if (value[jsField] !== undefined) {
        updates.push(`${dbField} = $${paramIndex}`);
        params.push(value[jsField]);
        paramIndex++;
      }
    }

    // Handle sharing timestamp
    if (value.isSharedWithBuyer === true && !current.rows[0].shared_at) {
      updates.push(`shared_at = NOW()`);
    }

    // Handle completion
    if (value.status === 'completed' && current.rows[0].status !== 'completed') {
      updates.push(`actual_close_date = CURRENT_DATE`);
    }

    params.push(planId, dealRoomId);

    const result = await query(
      `UPDATE action_plans SET ${updates.join(', ')}
       WHERE id = $${paramIndex} AND deal_room_id = $${paramIndex + 1}
       RETURNING *`,
      params
    );

    await logAudit(req.user.id, req.user.orgId, 'UPDATE', 'action_plan', planId, current.rows[0], result.rows[0], req);

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Update action plan error:', error);
    res.status(500).json({ error: 'Failed to update action plan', code: 'SERVER_ERROR' });
  }
});

// Delete action plan
router.delete('/:dealRoomId/action-plans/:planId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId, planId } = req.params;

    const result = await query(
      'DELETE FROM action_plans WHERE id = $1 AND deal_room_id = $2 RETURNING *',
      [planId, dealRoomId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Action plan not found', code: 'NOT_FOUND' });
    }

    await logAudit(req.user.id, req.user.orgId, 'DELETE', 'action_plan', planId, result.rows[0], null, req);

    res.json({ message: 'Action plan deleted successfully' });
  } catch (error) {
    console.error('Delete action plan error:', error);
    res.status(500).json({ error: 'Failed to delete action plan', code: 'SERVER_ERROR' });
  }
});

// ============================================
// MILESTONE ROUTES
// ============================================

// Create milestone
router.post('/:dealRoomId/action-plans/:planId/milestones', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId, planId } = req.params;
    const { error, value } = createMilestoneSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Verify action plan exists
    const planCheck = await query(
      'SELECT id FROM action_plans WHERE id = $1 AND deal_room_id = $2',
      [planId, dealRoomId]
    );

    if (planCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Action plan not found', code: 'NOT_FOUND' });
    }

    const { name, description, sequenceOrder, dueDate, ownerType } = value;

    const result = await query(
      `INSERT INTO milestones (action_plan_id, name, description, sequence_order, due_date, owner_type)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [planId, name, description, sequenceOrder, dueDate, ownerType]
    );

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Create milestone error:', error);
    res.status(500).json({ error: 'Failed to create milestone', code: 'SERVER_ERROR' });
  }
});

// Update milestone
router.patch('/:dealRoomId/action-plans/:planId/milestones/:milestoneId', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { planId, milestoneId } = req.params;
    const { error, value } = updateMilestoneSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const fieldMapping = {
      name: 'name',
      description: 'description',
      status: 'status',
      sequenceOrder: 'sequence_order',
      dueDate: 'due_date',
      ownerType: 'owner_type',
    };

    const updates = [];
    const params = [];
    let paramIndex = 1;

    for (const [jsField, dbField] of Object.entries(fieldMapping)) {
      if (value[jsField] !== undefined) {
        updates.push(`${dbField} = $${paramIndex}`);
        params.push(value[jsField]);
        paramIndex++;
      }
    }

    // Handle completion date
    if (value.status === 'completed') {
      updates.push('completed_date = CURRENT_DATE');
    }

    params.push(milestoneId, planId);

    const result = await query(
      `UPDATE milestones SET ${updates.join(', ')}
       WHERE id = $${paramIndex} AND action_plan_id = $${paramIndex + 1}
       RETURNING *`,
      params
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Milestone not found', code: 'NOT_FOUND' });
    }

    // Recalculate plan progress
    await calculateProgress(planId);

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Update milestone error:', error);
    res.status(500).json({ error: 'Failed to update milestone', code: 'SERVER_ERROR' });
  }
});

// Delete milestone
router.delete('/:dealRoomId/action-plans/:planId/milestones/:milestoneId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { planId, milestoneId } = req.params;

    const result = await query(
      'DELETE FROM milestones WHERE id = $1 AND action_plan_id = $2 RETURNING id',
      [milestoneId, planId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Milestone not found', code: 'NOT_FOUND' });
    }

    // Recalculate plan progress
    await calculateProgress(planId);

    res.json({ message: 'Milestone deleted successfully' });
  } catch (error) {
    console.error('Delete milestone error:', error);
    res.status(500).json({ error: 'Failed to delete milestone', code: 'SERVER_ERROR' });
  }
});

// ============================================
// ACTION ITEM ROUTES
// ============================================

// Create action item
router.post('/:dealRoomId/action-plans/:planId/items', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId, planId } = req.params;
    const { error, value } = createActionItemSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Verify milestone exists and belongs to this plan
    const milestoneCheck = await query(
      `SELECT m.id FROM milestones m
       JOIN action_plans ap ON m.action_plan_id = ap.id
       WHERE m.id = $1 AND ap.id = $2 AND ap.deal_room_id = $3`,
      [value.milestoneId, planId, dealRoomId]
    );

    if (milestoneCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Milestone not found', code: 'NOT_FOUND' });
    }

    const {
      milestoneId, title, description, priority, ownerType,
      assignedTo, stakeholderId, dueDate, sequenceOrder, dependencies,
    } = value;

    const result = await query(
      `INSERT INTO action_items 
       (milestone_id, action_plan_id, title, description, priority, owner_type, assigned_to, stakeholder_id, due_date, sequence_order, dependencies, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       RETURNING *`,
      [milestoneId, planId, title, description, priority, ownerType, assignedTo, stakeholderId, dueDate, sequenceOrder, JSON.stringify(dependencies), req.user.id]
    );

    // Recalculate plan progress
    await calculateProgress(planId);

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Create action item error:', error);
    res.status(500).json({ error: 'Failed to create action item', code: 'SERVER_ERROR' });
  }
});

// Update action item
router.patch('/:dealRoomId/action-plans/:planId/items/:itemId', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { planId, itemId } = req.params;
    const { error, value } = updateActionItemSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Get current item to check dependencies
    const current = await query(
      'SELECT * FROM action_items WHERE id = $1 AND action_plan_id = $2',
      [itemId, planId]
    );

    if (current.rows.length === 0) {
      return res.status(404).json({ error: 'Action item not found', code: 'NOT_FOUND' });
    }

    // If completing, check dependencies
    if (value.status === 'completed') {
      const depsComplete = await checkDependenciesComplete(current.rows[0].dependencies);
      if (!depsComplete) {
        return res.status(400).json({ 
          error: 'Cannot complete item - dependent items not yet completed', 
          code: 'DEPENDENCIES_INCOMPLETE' 
        });
      }
    }

    const fieldMapping = {
      title: 'title',
      description: 'description',
      status: 'status',
      priority: 'priority',
      ownerType: 'owner_type',
      assignedTo: 'assigned_to',
      stakeholderId: 'stakeholder_id',
      dueDate: 'due_date',
      sequenceOrder: 'sequence_order',
      dependencies: 'dependencies',
    };

    const updates = [];
    const params = [];
    let paramIndex = 1;

    for (const [jsField, dbField] of Object.entries(fieldMapping)) {
      if (value[jsField] !== undefined) {
        updates.push(`${dbField} = $${paramIndex}`);
        params.push(jsField === 'dependencies' ? JSON.stringify(value[jsField]) : value[jsField]);
        paramIndex++;
      }
    }

    // Handle completion
    if (value.status === 'completed' && current.rows[0].status !== 'completed') {
      updates.push(`completed_date = CURRENT_DATE`);
      updates.push(`completed_by = $${paramIndex}`);
      params.push(req.user.id);
      paramIndex++;
    }

    params.push(itemId, planId);

    const result = await query(
      `UPDATE action_items SET ${updates.join(', ')}
       WHERE id = $${paramIndex} AND action_plan_id = $${paramIndex + 1}
       RETURNING *`,
      params
    );

    // Recalculate plan progress
    const progress = await calculateProgress(planId);

    // Check if milestone should be auto-completed
    if (value.status === 'completed') {
      const milestoneItems = await query(
        `SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE status = 'completed') as completed
         FROM action_items WHERE milestone_id = $1`,
        [current.rows[0].milestone_id]
      );

      if (milestoneItems.rows[0].total === milestoneItems.rows[0].completed) {
        await query(
          `UPDATE milestones SET status = 'completed', completed_date = CURRENT_DATE WHERE id = $1`,
          [current.rows[0].milestone_id]
        );
      }
    }

    res.json({ 
      data: result.rows[0],
      planProgress: progress,
    });
  } catch (error) {
    console.error('Update action item error:', error);
    res.status(500).json({ error: 'Failed to update action item', code: 'SERVER_ERROR' });
  }
});

// Delete action item
router.delete('/:dealRoomId/action-plans/:planId/items/:itemId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { planId, itemId } = req.params;

    // Check if any other items depend on this one
    const dependencyCheck = await query(
      `SELECT id, title FROM action_items 
       WHERE action_plan_id = $1 AND dependencies ? $2`,
      [planId, itemId]
    );

    if (dependencyCheck.rows.length > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete - other items depend on this one',
        code: 'HAS_DEPENDENTS',
        dependents: dependencyCheck.rows,
      });
    }

    const result = await query(
      'DELETE FROM action_items WHERE id = $1 AND action_plan_id = $2 RETURNING id',
      [itemId, planId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Action item not found', code: 'NOT_FOUND' });
    }

    // Recalculate plan progress
    await calculateProgress(planId);

    res.json({ message: 'Action item deleted successfully' });
  } catch (error) {
    console.error('Delete action item error:', error);
    res.status(500).json({ error: 'Failed to delete action item', code: 'SERVER_ERROR' });
  }
});

// ============================================
// COMMENT ROUTES
// ============================================

// Add comment to action item
router.post('/:dealRoomId/action-plans/:planId/items/:itemId/comments', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { planId, itemId } = req.params;
    const { error, value } = createCommentSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Verify item exists
    const itemCheck = await query(
      'SELECT id FROM action_items WHERE id = $1 AND action_plan_id = $2',
      [itemId, planId]
    );

    if (itemCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Action item not found', code: 'NOT_FOUND' });
    }

    const { content, isInternal } = value;

    const result = await query(
      `INSERT INTO action_item_comments (action_item_id, user_id, content, is_internal)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [itemId, req.user.id, content, isInternal]
    );

    // Get user info for response
    const userInfo = await query(
      'SELECT first_name, last_name, email FROM users WHERE id = $1',
      [req.user.id]
    );

    res.status(201).json({
      data: {
        ...result.rows[0],
        user: userInfo.rows[0],
      },
    });
  } catch (error) {
    console.error('Add comment error:', error);
    res.status(500).json({ error: 'Failed to add comment', code: 'SERVER_ERROR' });
  }
});

// Get comments for action item
router.get('/:dealRoomId/action-plans/:planId/items/:itemId/comments', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { planId, itemId } = req.params;
    const { includeInternal } = req.query;

    let whereClause = 'aic.action_item_id = $1';
    const params = [itemId];

    // Only show internal comments to sellers
    if (includeInternal !== 'true') {
      whereClause += ' AND aic.is_internal = FALSE';
    }

    const result = await query(
      `SELECT aic.*, u.first_name, u.last_name, u.email
       FROM action_item_comments aic
       JOIN users u ON aic.user_id = u.id
       WHERE ${whereClause}
       ORDER BY aic.created_at ASC`,
      params
    );

    res.json({ data: result.rows });
  } catch (error) {
    console.error('Get comments error:', error);
    res.status(500).json({ error: 'Failed to get comments', code: 'SERVER_ERROR' });
  }
});

// ============================================
// ANALYTICS ROUTES
// ============================================

// Get plan analytics
router.get('/:dealRoomId/action-plans/:planId/analytics', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { planId } = req.params;

    // Status breakdown
    const statusBreakdown = await query(
      `SELECT status, COUNT(*) as count
       FROM action_items WHERE action_plan_id = $1
       GROUP BY status`,
      [planId]
    );

    // Priority breakdown
    const priorityBreakdown = await query(
      `SELECT priority, COUNT(*) as count
       FROM action_items WHERE action_plan_id = $1
       GROUP BY priority`,
      [planId]
    );

    // Owner type breakdown
    const ownerBreakdown = await query(
      `SELECT owner_type, COUNT(*) as count
       FROM action_items WHERE action_plan_id = $1
       GROUP BY owner_type`,
      [planId]
    );

    // Overdue items
    const overdueItems = await query(
      `SELECT id, title, due_date, priority, assigned_to
       FROM action_items
       WHERE action_plan_id = $1 AND due_date < CURRENT_DATE AND status NOT IN ('completed', 'cancelled')
       ORDER BY due_date`,
      [planId]
    );

    // Upcoming items (next 7 days)
    const upcomingItems = await query(
      `SELECT id, title, due_date, priority, assigned_to, status
       FROM action_items
       WHERE action_plan_id = $1 
       AND due_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '7 days'
       AND status NOT IN ('completed', 'cancelled')
       ORDER BY due_date`,
      [planId]
    );

    // Blocked items
    const blockedItems = await query(
      `SELECT ai.id, ai.title, ai.dependencies
       FROM action_items ai
       WHERE ai.action_plan_id = $1 AND ai.status = 'blocked'`,
      [planId]
    );

    // Completion velocity (items completed per week)
    const velocity = await query(
      `SELECT DATE_TRUNC('week', completed_date) as week, COUNT(*) as completed
       FROM action_items
       WHERE action_plan_id = $1 AND status = 'completed' AND completed_date IS NOT NULL
       GROUP BY DATE_TRUNC('week', completed_date)
       ORDER BY week`,
      [planId]
    );

    res.json({
      data: {
        statusBreakdown: statusBreakdown.rows,
        priorityBreakdown: priorityBreakdown.rows,
        ownerBreakdown: ownerBreakdown.rows,
        overdueItems: overdueItems.rows,
        upcomingItems: upcomingItems.rows,
        blockedItems: blockedItems.rows,
        velocity: velocity.rows,
      },
    });
  } catch (error) {
    console.error('Get plan analytics error:', error);
    res.status(500).json({ error: 'Failed to get analytics', code: 'SERVER_ERROR' });
  }
});

// Reorder items (bulk update sequence)
router.post('/:dealRoomId/action-plans/:planId/reorder', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { planId } = req.params;
    const { items } = req.body;

    // Validate input
    if (!Array.isArray(items)) {
      return res.status(400).json({ error: 'Items must be an array', code: 'VALIDATION_ERROR' });
    }

    const reorderSchema = Joi.array().items(
      Joi.object({
        id: Joi.string().uuid().required(),
        sequenceOrder: Joi.number().integer().min(0).required(),
        milestoneId: Joi.string().uuid().required(),
      })
    ).min(1).max(500);

    const { error, value } = reorderSchema.validate(items);
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Use transaction for bulk update
    await transaction(async (client) => {
      for (const item of value) {
        await client.query(
          `UPDATE action_items 
           SET sequence_order = $1, milestone_id = $2
           WHERE id = $3 AND action_plan_id = $4`,
          [item.sequenceOrder, item.milestoneId, item.id, planId]
        );
      }
    });

    res.json({ message: 'Items reordered successfully' });
  } catch (error) {
    console.error('Reorder items error:', error);
    res.status(500).json({ error: 'Failed to reorder items', code: 'SERVER_ERROR' });
  }
});

module.exports = router;
