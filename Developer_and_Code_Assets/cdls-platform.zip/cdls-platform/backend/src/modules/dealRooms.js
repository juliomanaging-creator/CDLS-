/**
 * CDLS Platform - Module 1: Digital Deal Rooms
 * Security Review: Input validation, access control, secure file handling
 */

const express = require('express');
const Joi = require('joi');
const crypto = require('crypto');
const { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const { query, transaction, buildWhereClause, buildPaginationClause } = require('../utils/database');
const { authenticate, authorize, checkDealRoomAccess, sanitizeInput } = require('../middleware/security');
const config = require('../config');

const router = express.Router();

// Initialize S3 client
const s3Client = new S3Client({
  region: config.aws.region,
  credentials: {
    accessKeyId: config.aws.accessKeyId,
    secretAccessKey: config.aws.secretAccessKey,
  },
});

// ============================================
// VALIDATION SCHEMAS
// ============================================

const createDealRoomSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255).required(),
  description: Joi.string().trim().max(2000).allow(''),
  investorOrgId: Joi.string().uuid().allow(null),
  stage: Joi.string().valid('prospect', 'qualification', 'due_diligence', 'negotiation', 'closing').default('prospect'),
  dealValue: Joi.number().positive().max(999999999999).allow(null),
  expectedCloseDate: Joi.date().iso().min('now').allow(null),
  branding: Joi.object({
    primaryColor: Joi.string().pattern(/^#[0-9A-Fa-f]{6}$/),
    logoUrl: Joi.string().uri().max(500),
  }).default({}),
  settings: Joi.object().default({}),
});

const updateDealRoomSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255),
  description: Joi.string().trim().max(2000).allow(''),
  stage: Joi.string().valid('prospect', 'qualification', 'due_diligence', 'negotiation', 'closing', 'closed_won', 'closed_lost'),
  dealValue: Joi.number().positive().max(999999999999).allow(null),
  expectedCloseDate: Joi.date().iso().allow(null),
  branding: Joi.object(),
  settings: Joi.object(),
}).min(1);

const addMemberSchema = Joi.object({
  userId: Joi.string().uuid().required(),
  role: Joi.string().valid('admin', 'contributor', 'viewer').default('viewer'),
  permissions: Joi.object({
    view: Joi.boolean().default(true),
    upload: Joi.boolean().default(false),
    delete: Joi.boolean().default(false),
    invite: Joi.boolean().default(false),
  }).default(),
});

const uploadDocumentSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255).required(),
  fileType: Joi.string().max(50).required(),
  fileSize: Joi.number().positive().max(104857600).required(), // Max 100MB
  folderPath: Joi.string().max(500).pattern(/^\//).default('/'),
  description: Joi.string().trim().max(2000).allow(''),
  isConfidential: Joi.boolean().default(false),
  watermarkEnabled: Joi.boolean().default(false),
});

const createShareLinkSchema = Joi.object({
  documentId: Joi.string().uuid(),
  dealRoomId: Joi.string().uuid(),
  password: Joi.string().min(8).max(100),
  expiresIn: Joi.number().positive().max(2592000), // Max 30 days in seconds
  maxViews: Joi.number().positive().max(1000),
  allowDownload: Joi.boolean().default(true),
  recipientEmail: Joi.string().email().max(255),
}).or('documentId', 'dealRoomId');

// ============================================
// HELPER FUNCTIONS
// ============================================

const generateSecureToken = () => {
  return crypto.randomBytes(32).toString('hex');
};

const hashPassword = (password) => {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
};

const verifyPassword = (password, storedHash) => {
  const [salt, hash] = storedHash.split(':');
  const verifyHash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(verifyHash));
};

const logAudit = async (userId, orgId, action, entityType, entityId, oldValues, newValues, req) => {
  await query(
    `INSERT INTO audit_logs (user_id, org_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent, request_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
    [userId, orgId, action, entityType, entityId, JSON.stringify(oldValues), JSON.stringify(newValues), req.ip, req.get('user-agent'), req.requestId]
  );
};

// ============================================
// DEAL ROOM ROUTES
// ============================================

// Create deal room
router.post('/', authenticate, sanitizeInput, async (req, res) => {
  try {
    const { error, value } = createDealRoomSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { name, description, investorOrgId, stage, dealValue, expectedCloseDate, branding, settings } = value;

    const result = await query(
      `INSERT INTO deal_rooms (org_id, name, description, investor_org_id, stage, deal_value, expected_close_date, branding, settings, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       RETURNING *`,
      [req.user.orgId, name, description, investorOrgId, stage, dealValue, expectedCloseDate, branding, settings, req.user.id]
    );

    const dealRoom = result.rows[0];

    // Add creator as owner
    await query(
      `INSERT INTO deal_room_members (deal_room_id, user_id, role, permissions, accepted_at, invited_by)
       VALUES ($1, $2, 'owner', $3, NOW(), $4)`,
      [dealRoom.id, req.user.id, { view: true, upload: true, delete: true, invite: true }, req.user.id]
    );

    await logAudit(req.user.id, req.user.orgId, 'CREATE', 'deal_room', dealRoom.id, null, dealRoom, req);

    res.status(201).json({ data: dealRoom });
  } catch (error) {
    console.error('Create deal room error:', error);
    res.status(500).json({ error: 'Failed to create deal room', code: 'SERVER_ERROR' });
  }
});

// List deal rooms
router.get('/', authenticate, async (req, res) => {
  try {
    const { page, limit, stage, status, search } = req.query;
    const pagination = buildPaginationClause(page, limit, 50);

    let whereConditions = ['dr.org_id = $1', 'dr.status != $2'];
    let params = [req.user.orgId, 'deleted'];
    let paramIndex = 3;

    if (stage) {
      whereConditions.push(`dr.stage = $${paramIndex}`);
      params.push(stage);
      paramIndex++;
    }

    if (status && status !== 'all') {
      whereConditions.push(`dr.status = $${paramIndex}`);
      params.push(status);
      paramIndex++;
    }

    if (search) {
      whereConditions.push(`(dr.name ILIKE $${paramIndex} OR dr.description ILIKE $${paramIndex})`);
      params.push(`%${search.replace(/[%_]/g, '\\$&')}%`);
      paramIndex++;
    }

    const whereClause = whereConditions.join(' AND ');

    const countResult = await query(
      `SELECT COUNT(*) FROM deal_rooms dr WHERE ${whereClause}`,
      params
    );

    const result = await query(
      `SELECT dr.*, 
              o.name as investor_name,
              (SELECT COUNT(*) FROM documents d WHERE d.deal_room_id = dr.id AND d.status = 'active') as document_count,
              (SELECT COUNT(*) FROM deal_room_members drm WHERE drm.deal_room_id = dr.id) as member_count
       FROM deal_rooms dr
       LEFT JOIN organizations o ON dr.investor_org_id = o.id
       WHERE ${whereClause}
       ORDER BY dr.updated_at DESC
       ${pagination.clause}`,
      params
    );

    res.json({
      data: result.rows,
      pagination: {
        page: pagination.page,
        limit: pagination.limit,
        total: parseInt(countResult.rows[0].count, 10),
      },
    });
  } catch (error) {
    console.error('List deal rooms error:', error);
    res.status(500).json({ error: 'Failed to list deal rooms', code: 'SERVER_ERROR' });
  }
});

// Get deal room by ID
router.get('/:dealRoomId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;

    const result = await query(
      `SELECT dr.*, 
              o.name as investor_name,
              u.first_name || ' ' || u.last_name as created_by_name
       FROM deal_rooms dr
       LEFT JOIN organizations o ON dr.investor_org_id = o.id
       LEFT JOIN users u ON dr.created_by = u.id
       WHERE dr.id = $1 AND dr.status != 'deleted'`,
      [dealRoomId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Deal room not found', code: 'NOT_FOUND' });
    }

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Get deal room error:', error);
    res.status(500).json({ error: 'Failed to get deal room', code: 'SERVER_ERROR' });
  }
});

// Update deal room
router.patch('/:dealRoomId', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { error, value } = updateDealRoomSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Get current values for audit
    const current = await query('SELECT * FROM deal_rooms WHERE id = $1', [dealRoomId]);
    if (current.rows.length === 0) {
      return res.status(404).json({ error: 'Deal room not found', code: 'NOT_FOUND' });
    }

    // Build update query dynamically
    const updates = [];
    const params = [];
    let paramIndex = 1;

    const fieldMapping = {
      name: 'name',
      description: 'description',
      stage: 'stage',
      dealValue: 'deal_value',
      expectedCloseDate: 'expected_close_date',
      branding: 'branding',
      settings: 'settings',
    };

    for (const [key, dbField] of Object.entries(fieldMapping)) {
      if (value[key] !== undefined) {
        updates.push(`${dbField} = $${paramIndex}`);
        params.push(key === 'branding' || key === 'settings' ? JSON.stringify(value[key]) : value[key]);
        paramIndex++;
      }
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No valid fields to update', code: 'VALIDATION_ERROR' });
    }

    params.push(dealRoomId);
    const result = await query(
      `UPDATE deal_rooms SET ${updates.join(', ')} WHERE id = $${paramIndex} RETURNING *`,
      params
    );

    await logAudit(req.user.id, req.user.orgId, 'UPDATE', 'deal_room', dealRoomId, current.rows[0], result.rows[0], req);

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Update deal room error:', error);
    res.status(500).json({ error: 'Failed to update deal room', code: 'SERVER_ERROR' });
  }
});

// Delete deal room (soft delete)
router.delete('/:dealRoomId', authenticate, checkDealRoomAccess, authorize('admin', 'manager'), async (req, res) => {
  try {
    const { dealRoomId } = req.params;

    const result = await query(
      `UPDATE deal_rooms SET status = 'deleted' WHERE id = $1 RETURNING *`,
      [dealRoomId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Deal room not found', code: 'NOT_FOUND' });
    }

    await logAudit(req.user.id, req.user.orgId, 'DELETE', 'deal_room', dealRoomId, result.rows[0], null, req);

    res.json({ message: 'Deal room deleted successfully' });
  } catch (error) {
    console.error('Delete deal room error:', error);
    res.status(500).json({ error: 'Failed to delete deal room', code: 'SERVER_ERROR' });
  }
});

// ============================================
// MEMBER MANAGEMENT
// ============================================

router.post('/:dealRoomId/members', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { error, value } = addMemberSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { userId, role, permissions } = value;

    // Check if user exists
    const userCheck = await query('SELECT id FROM users WHERE id = $1', [userId]);
    if (userCheck.rows.length === 0) {
      return res.status(404).json({ error: 'User not found', code: 'USER_NOT_FOUND' });
    }

    // Check if already a member
    const memberCheck = await query(
      'SELECT id FROM deal_room_members WHERE deal_room_id = $1 AND user_id = $2',
      [dealRoomId, userId]
    );
    if (memberCheck.rows.length > 0) {
      return res.status(409).json({ error: 'User is already a member', code: 'ALREADY_MEMBER' });
    }

    const result = await query(
      `INSERT INTO deal_room_members (deal_room_id, user_id, role, permissions, invited_by)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [dealRoomId, userId, role, permissions, req.user.id]
    );

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Add member error:', error);
    res.status(500).json({ error: 'Failed to add member', code: 'SERVER_ERROR' });
  }
});

router.get('/:dealRoomId/members', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;

    const result = await query(
      `SELECT drm.*, u.email, u.first_name, u.last_name
       FROM deal_room_members drm
       JOIN users u ON drm.user_id = u.id
       WHERE drm.deal_room_id = $1
       ORDER BY drm.role, u.last_name`,
      [dealRoomId]
    );

    res.json({ data: result.rows });
  } catch (error) {
    console.error('List members error:', error);
    res.status(500).json({ error: 'Failed to list members', code: 'SERVER_ERROR' });
  }
});

router.delete('/:dealRoomId/members/:userId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId, userId } = req.params;

    // Prevent removing the last owner
    const ownerCheck = await query(
      `SELECT COUNT(*) FROM deal_room_members WHERE deal_room_id = $1 AND role = 'owner'`,
      [dealRoomId]
    );

    const memberRole = await query(
      `SELECT role FROM deal_room_members WHERE deal_room_id = $1 AND user_id = $2`,
      [dealRoomId, userId]
    );

    if (memberRole.rows[0]?.role === 'owner' && parseInt(ownerCheck.rows[0].count, 10) <= 1) {
      return res.status(400).json({ error: 'Cannot remove the last owner', code: 'LAST_OWNER' });
    }

    await query(
      'DELETE FROM deal_room_members WHERE deal_room_id = $1 AND user_id = $2',
      [dealRoomId, userId]
    );

    res.json({ message: 'Member removed successfully' });
  } catch (error) {
    console.error('Remove member error:', error);
    res.status(500).json({ error: 'Failed to remove member', code: 'SERVER_ERROR' });
  }
});

// ============================================
// DOCUMENT MANAGEMENT
// ============================================

// Get presigned URL for upload
router.post('/:dealRoomId/documents/upload-url', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { error, value } = uploadDocumentSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { name, fileType, fileSize, folderPath, description, isConfidential, watermarkEnabled } = value;

    // Validate file type (whitelist approach)
    const allowedTypes = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'png', 'jpg', 'jpeg', 'gif'];
    const extension = fileType.toLowerCase().replace('.', '');
    if (!allowedTypes.includes(extension)) {
      return res.status(400).json({ error: 'File type not allowed', code: 'INVALID_FILE_TYPE' });
    }

    // Generate secure S3 key
    const documentId = crypto.randomUUID();
    const s3Key = `deal-rooms/${dealRoomId}/${documentId}/${name}`;

    // Create document record
    const result = await query(
      `INSERT INTO documents (id, deal_room_id, name, file_type, file_size, s3_key, s3_bucket, folder_path, description, is_confidential, watermark_enabled, uploaded_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       RETURNING *`,
      [documentId, dealRoomId, name, extension, fileSize, s3Key, config.aws.s3Bucket, folderPath, description, isConfidential, watermarkEnabled, req.user.id]
    );

    // Generate presigned upload URL
    const command = new PutObjectCommand({
      Bucket: config.aws.s3Bucket,
      Key: s3Key,
      ContentType: `application/${extension}`,
      ContentLength: fileSize,
    });

    const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });

    res.json({
      data: {
        document: result.rows[0],
        uploadUrl,
        expiresIn: 3600,
      },
    });
  } catch (error) {
    console.error('Generate upload URL error:', error);
    res.status(500).json({ error: 'Failed to generate upload URL', code: 'SERVER_ERROR' });
  }
});

// Confirm upload complete
router.post('/:dealRoomId/documents/:documentId/confirm', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { documentId } = req.params;
    const { checksum } = req.body;

    const result = await query(
      `UPDATE documents SET checksum = $1, status = 'active' WHERE id = $2 RETURNING *`,
      [checksum, documentId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Document not found', code: 'NOT_FOUND' });
    }

    await logAudit(req.user.id, req.user.orgId, 'UPLOAD', 'document', documentId, null, result.rows[0], req);

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Confirm upload error:', error);
    res.status(500).json({ error: 'Failed to confirm upload', code: 'SERVER_ERROR' });
  }
});

// List documents
router.get('/:dealRoomId/documents', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { folderPath, page, limit } = req.query;
    const pagination = buildPaginationClause(page, limit, 100);

    let whereClause = 'deal_room_id = $1 AND status = $2';
    const params = [dealRoomId, 'active'];

    if (folderPath) {
      whereClause += ` AND folder_path = $3`;
      params.push(folderPath);
    }

    const result = await query(
      `SELECT d.*, u.first_name || ' ' || u.last_name as uploaded_by_name
       FROM documents d
       LEFT JOIN users u ON d.uploaded_by = u.id
       WHERE ${whereClause}
       ORDER BY d.created_at DESC
       ${pagination.clause}`,
      params
    );

    res.json({ data: result.rows, pagination });
  } catch (error) {
    console.error('List documents error:', error);
    res.status(500).json({ error: 'Failed to list documents', code: 'SERVER_ERROR' });
  }
});

// Get document download URL
router.get('/:dealRoomId/documents/:documentId/download', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { documentId } = req.params;

    const result = await query(
      'SELECT * FROM documents WHERE id = $1 AND status = $2',
      [documentId, 'active']
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Document not found', code: 'NOT_FOUND' });
    }

    const doc = result.rows[0];

    // Increment download count
    await query(
      'UPDATE documents SET download_count = download_count + 1 WHERE id = $1',
      [documentId]
    );

    // Generate presigned download URL
    const command = new GetObjectCommand({
      Bucket: doc.s3_bucket,
      Key: doc.s3_key,
      ResponseContentDisposition: `attachment; filename="${doc.name}"`,
    });

    const downloadUrl = await getSignedUrl(s3Client, command, { expiresIn: 300 });

    res.json({ data: { downloadUrl, expiresIn: 300 } });
  } catch (error) {
    console.error('Get download URL error:', error);
    res.status(500).json({ error: 'Failed to get download URL', code: 'SERVER_ERROR' });
  }
});

// Delete document
router.delete('/:dealRoomId/documents/:documentId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { documentId } = req.params;

    const result = await query(
      `UPDATE documents SET status = 'deleted' WHERE id = $1 RETURNING *`,
      [documentId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Document not found', code: 'NOT_FOUND' });
    }

    await logAudit(req.user.id, req.user.orgId, 'DELETE', 'document', documentId, result.rows[0], null, req);

    res.json({ message: 'Document deleted successfully' });
  } catch (error) {
    console.error('Delete document error:', error);
    res.status(500).json({ error: 'Failed to delete document', code: 'SERVER_ERROR' });
  }
});

// ============================================
// SHARE LINKS
// ============================================

router.post('/:dealRoomId/share-links', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { error, value } = createShareLinkSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { documentId, password, expiresIn, maxViews, allowDownload, recipientEmail } = value;

    const token = generateSecureToken();
    const passwordHash = password ? hashPassword(password) : null;
    const expiresAt = expiresIn ? new Date(Date.now() + expiresIn * 1000) : null;

    const result = await query(
      `INSERT INTO share_links (document_id, deal_room_id, token, password_hash, expires_at, max_views, allow_download, recipient_email, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING id, token, expires_at, max_views, allow_download, created_at`,
      [documentId || null, dealRoomId, token, passwordHash, expiresAt, maxViews, allowDownload, recipientEmail, req.user.id]
    );

    const shareUrl = `${process.env.APP_URL}/share/${token}`;

    res.status(201).json({
      data: {
        ...result.rows[0],
        shareUrl,
        hasPassword: !!password,
      },
    });
  } catch (error) {
    console.error('Create share link error:', error);
    res.status(500).json({ error: 'Failed to create share link', code: 'SERVER_ERROR' });
  }
});

module.exports = router;
