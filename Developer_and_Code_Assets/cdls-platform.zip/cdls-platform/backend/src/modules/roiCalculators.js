/**
 * CDLS Platform - Module 3: Interactive ROI Calculators
 * Security Review: Calculation sandboxing, input validation, formula injection prevention
 */

const express = require('express');
const Joi = require('joi');
const crypto = require('crypto');
const { query, transaction } = require('../utils/database');
const { authenticate, checkDealRoomAccess, sanitizeInput } = require('../middleware/security');

const router = express.Router();

// ============================================
// VALIDATION SCHEMAS
// ============================================

const calculatorInputSchema = Joi.object({
  // Fleet economics inputs
  fleetSize: Joi.number().integer().min(1).max(10000),
  avgRouteDistance: Joi.number().positive().max(5000), // miles
  tripsPerMonth: Joi.number().integer().min(1).max(10000),
  dieselPricePerGallon: Joi.number().positive().max(20),
  electricityRatePerKwh: Joi.number().positive().max(1),
  
  // Vehicle specifications
  dieselMpg: Joi.number().positive().max(50),
  evMilesPerKwh: Joi.number().positive().max(10),
  vehiclePurchasePrice: Joi.number().positive().max(500000),
  evPurchasePrice: Joi.number().positive().max(500000),
  
  // Operational costs
  maintenanceCostPerMile: Joi.number().min(0).max(10),
  evMaintenanceCostPerMile: Joi.number().min(0).max(10),
  driverHourlyRate: Joi.number().positive().max(200),
  
  // Third-party comparison
  thirdPartyRatePerMile: Joi.number().positive().max(10),
  syndicateSavingsPercent: Joi.number().min(0).max(100),
  
  // Financial assumptions
  yearsToProject: Joi.number().integer().min(1).max(20),
  discountRate: Joi.number().min(0).max(30),
  fuelInflationRate: Joi.number().min(0).max(20),
  electricityInflationRate: Joi.number().min(0).max(20),
  
  // CARB compliance
  carbComplianceCost: Joi.number().min(0).max(100000),
  evIncentives: Joi.number().min(0).max(100000),
}).unknown(true);

const createTemplateSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255).required(),
  description: Joi.string().trim().max(2000),
  type: Joi.string().valid('fleet_economics', 'ev_transition', 'syndicate_savings', 'custom').required(),
  inputSchema: Joi.object().required(),
  calculationLogic: Joi.object().required(),
  outputSchema: Joi.object().required(),
  isPublic: Joi.boolean().default(false),
});

const createSessionSchema = Joi.object({
  templateId: Joi.string().uuid().required(),
  dealRoomId: Joi.string().uuid(),
  sessionName: Joi.string().trim().max(255),
  inputs: calculatorInputSchema.required(),
  notes: Joi.string().trim().max(5000),
});

const createScenarioSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255).required(),
  description: Joi.string().trim().max(2000),
  inputs: calculatorInputSchema.required(),
  isBaseline: Joi.boolean().default(false),
});

// ============================================
// SECURE CALCULATION ENGINE
// ============================================

/**
 * Safe calculation engine that prevents code injection
 * Uses a whitelist approach for allowed operations
 */
class CalculationEngine {
  constructor() {
    this.allowedOperations = new Set([
      'add', 'subtract', 'multiply', 'divide', 'power',
      'min', 'max', 'round', 'floor', 'ceil', 'abs',
      'sum', 'average', 'npv', 'pmt', 'fv', 'pv'
    ]);
  }

  /**
   * Execute calculation safely
   * @param {Object} logic - Calculation logic definition
   * @param {Object} inputs - User inputs
   * @returns {Object} Calculated outputs
   */
  execute(logic, inputs) {
    const results = {};
    
    // Validate inputs are numbers or null
    for (const [key, value] of Object.entries(inputs)) {
      if (value !== null && typeof value !== 'number') {
        throw new Error(`Invalid input type for ${key}`);
      }
    }

    // Process each calculation step
    for (const [outputKey, formula] of Object.entries(logic.formulas || {})) {
      try {
        results[outputKey] = this.evaluateFormula(formula, inputs, results);
      } catch (error) {
        console.error(`Calculation error for ${outputKey}:`, error);
        results[outputKey] = null;
      }
    }

    return results;
  }

  evaluateFormula(formula, inputs, previousResults) {
    if (typeof formula === 'number') {
      return formula;
    }

    if (typeof formula === 'string') {
      // Reference to input or previous result
      if (inputs[formula] !== undefined) return inputs[formula];
      if (previousResults[formula] !== undefined) return previousResults[formula];
      throw new Error(`Unknown reference: ${formula}`);
    }

    if (!formula || typeof formula !== 'object') {
      throw new Error('Invalid formula structure');
    }

    const { operation, operands } = formula;

    if (!this.allowedOperations.has(operation)) {
      throw new Error(`Disallowed operation: ${operation}`);
    }

    // Recursively evaluate operands
    const evaluatedOperands = operands.map(op => 
      this.evaluateFormula(op, inputs, previousResults)
    );

    // Execute operation
    return this.executeOperation(operation, evaluatedOperands);
  }

  executeOperation(operation, operands) {
    switch (operation) {
      case 'add':
        return operands.reduce((a, b) => (a || 0) + (b || 0), 0);
      case 'subtract':
        return operands[0] - (operands[1] || 0);
      case 'multiply':
        return operands.reduce((a, b) => (a || 0) * (b || 1), 1);
      case 'divide':
        if (operands[1] === 0) return null;
        return operands[0] / operands[1];
      case 'power':
        return Math.pow(operands[0], operands[1]);
      case 'min':
        return Math.min(...operands.filter(v => v !== null));
      case 'max':
        return Math.max(...operands.filter(v => v !== null));
      case 'round':
        return Math.round(operands[0] * Math.pow(10, operands[1] || 0)) / Math.pow(10, operands[1] || 0);
      case 'floor':
        return Math.floor(operands[0]);
      case 'ceil':
        return Math.ceil(operands[0]);
      case 'abs':
        return Math.abs(operands[0]);
      case 'sum':
        return operands.reduce((a, b) => (a || 0) + (b || 0), 0);
      case 'average':
        const validOps = operands.filter(v => v !== null);
        return validOps.reduce((a, b) => a + b, 0) / validOps.length;
      case 'npv':
        // NPV calculation: [rate, ...cashflows]
        const rate = operands[0];
        const cashflows = operands.slice(1);
        return cashflows.reduce((npv, cf, t) => npv + cf / Math.pow(1 + rate, t + 1), 0);
      case 'pmt':
        // PMT calculation: [rate, nper, pv]
        const [pmtRate, nper, pv] = operands;
        if (pmtRate === 0) return -pv / nper;
        return -pv * (pmtRate * Math.pow(1 + pmtRate, nper)) / (Math.pow(1 + pmtRate, nper) - 1);
      case 'fv':
        // Future Value: [rate, nper, pmt, pv]
        const [fvRate, fvNper, fvPmt, fvPv] = operands;
        return -fvPv * Math.pow(1 + fvRate, fvNper) - fvPmt * ((Math.pow(1 + fvRate, fvNper) - 1) / fvRate);
      case 'pv':
        // Present Value: [rate, nper, pmt, fv]
        const [pvRate, pvNper, pvPmt, pvFv] = operands;
        if (pvRate === 0) return -(pvFv + pvPmt * pvNper);
        return -(pvFv / Math.pow(1 + pvRate, pvNper)) - pvPmt * ((1 - Math.pow(1 + pvRate, -pvNper)) / pvRate);
      default:
        throw new Error(`Unknown operation: ${operation}`);
    }
  }
}

const calculationEngine = new CalculationEngine();

// ============================================
// DEFAULT CALCULATOR TEMPLATES
// ============================================

const DEFAULT_TEMPLATES = {
  fleet_economics: {
    name: 'Fleet Economics Calculator',
    description: 'Compare diesel vs electric vehicle fleet operating costs',
    inputSchema: {
      fleetSize: { type: 'number', label: 'Number of Vehicles', default: 10, min: 1, max: 500 },
      avgRouteDistance: { type: 'number', label: 'Average Route Distance (miles)', default: 200, min: 10, max: 2000 },
      tripsPerMonth: { type: 'number', label: 'Trips per Month', default: 100, min: 1, max: 5000 },
      dieselPricePerGallon: { type: 'number', label: 'Diesel Price ($/gallon)', default: 5.05, min: 2, max: 15 },
      electricityRatePerKwh: { type: 'number', label: 'Electricity Rate ($/kWh)', default: 0.15, min: 0.05, max: 0.50 },
      dieselMpg: { type: 'number', label: 'Diesel MPG', default: 6, min: 3, max: 15 },
      evMilesPerKwh: { type: 'number', label: 'EV Miles per kWh', default: 2.5, min: 1, max: 5 },
      yearsToProject: { type: 'number', label: 'Years to Project', default: 5, min: 1, max: 15 },
    },
    calculationLogic: {
      formulas: {
        monthlyMiles: { operation: 'multiply', operands: ['avgRouteDistance', 'tripsPerMonth'] },
        annualMiles: { operation: 'multiply', operands: ['monthlyMiles', 12] },
        totalAnnualMiles: { operation: 'multiply', operands: ['annualMiles', 'fleetSize'] },
        dieselGallonsPerYear: { operation: 'divide', operands: ['totalAnnualMiles', 'dieselMpg'] },
        dieselFuelCostPerYear: { operation: 'multiply', operands: ['dieselGallonsPerYear', 'dieselPricePerGallon'] },
        evKwhPerYear: { operation: 'divide', operands: ['totalAnnualMiles', 'evMilesPerKwh'] },
        evEnergyCostPerYear: { operation: 'multiply', operands: ['evKwhPerYear', 'electricityRatePerKwh'] },
        annualSavings: { operation: 'subtract', operands: ['dieselFuelCostPerYear', 'evEnergyCostPerYear'] },
        totalSavings: { operation: 'multiply', operands: ['annualSavings', 'yearsToProject'] },
        savingsPerVehicle: { operation: 'divide', operands: ['annualSavings', 'fleetSize'] },
        co2ReductionTons: { operation: 'multiply', operands: ['dieselGallonsPerYear', 0.010180] },
      },
    },
    outputSchema: {
      annualSavings: { label: 'Annual Fuel Savings', format: 'currency' },
      totalSavings: { label: 'Total Savings (projection period)', format: 'currency' },
      savingsPerVehicle: { label: 'Annual Savings per Vehicle', format: 'currency' },
      dieselFuelCostPerYear: { label: 'Annual Diesel Cost', format: 'currency' },
      evEnergyCostPerYear: { label: 'Annual EV Electricity Cost', format: 'currency' },
      co2ReductionTons: { label: 'CO2 Reduction (tons/year)', format: 'number' },
    },
  },
  syndicate_savings: {
    name: 'Syndicate Savings Calculator',
    description: 'Calculate savings from joining the dealer logistics syndicate vs third-party haulers',
    inputSchema: {
      fleetSize: { type: 'number', label: 'Vehicles to Transport', default: 100, min: 1, max: 10000 },
      avgRouteDistance: { type: 'number', label: 'Average Haul Distance (miles)', default: 350, min: 50, max: 2000 },
      tripsPerMonth: { type: 'number', label: 'Transports per Month', default: 50, min: 1, max: 1000 },
      thirdPartyRatePerMile: { type: 'number', label: 'Current Rate ($/mile)', default: 1.05, min: 0.50, max: 3.00 },
      syndicateSavingsPercent: { type: 'number', label: 'Syndicate Savings (%)', default: 25, min: 10, max: 50 },
      yearsToProject: { type: 'number', label: 'Years to Project', default: 5, min: 1, max: 10 },
    },
    calculationLogic: {
      formulas: {
        monthlyMiles: { operation: 'multiply', operands: ['avgRouteDistance', 'tripsPerMonth'] },
        annualMiles: { operation: 'multiply', operands: ['monthlyMiles', 12] },
        currentAnnualCost: { operation: 'multiply', operands: ['annualMiles', 'thirdPartyRatePerMile'] },
        savingsRate: { operation: 'divide', operands: ['syndicateSavingsPercent', 100] },
        annualSavings: { operation: 'multiply', operands: ['currentAnnualCost', 'savingsRate'] },
        syndicateAnnualCost: { operation: 'subtract', operands: ['currentAnnualCost', 'annualSavings'] },
        totalSavings: { operation: 'multiply', operands: ['annualSavings', 'yearsToProject'] },
        savingsPerTrip: { operation: 'divide', operands: [{ operation: 'divide', operands: ['annualSavings', 12] }, 'tripsPerMonth'] },
        syndicateRatePerMile: { operation: 'multiply', operands: ['thirdPartyRatePerMile', { operation: 'subtract', operands: [1, 'savingsRate'] }] },
      },
    },
    outputSchema: {
      currentAnnualCost: { label: 'Current Annual Cost', format: 'currency' },
      syndicateAnnualCost: { label: 'Syndicate Annual Cost', format: 'currency' },
      annualSavings: { label: 'Annual Savings', format: 'currency' },
      totalSavings: { label: 'Total Savings (projection period)', format: 'currency' },
      savingsPerTrip: { label: 'Savings per Trip', format: 'currency' },
      syndicateRatePerMile: { label: 'Syndicate Rate ($/mile)', format: 'currency' },
    },
  },
};

// ============================================
// TEMPLATE ROUTES
// ============================================

// List available templates
router.get('/templates', authenticate, async (req, res) => {
  try {
    const { type, includePublic } = req.query;

    let whereClause = '(org_id = $1 OR is_public = TRUE) AND is_active = TRUE';
    const params = [req.user.orgId];

    if (type) {
      whereClause += ' AND type = $2';
      params.push(type);
    }

    const result = await query(
      `SELECT id, name, description, type, version, is_public, created_at
       FROM calculator_templates
       WHERE ${whereClause}
       ORDER BY is_public DESC, name`,
      params
    );

    // Include default templates
    const templates = [...result.rows];
    for (const [key, template] of Object.entries(DEFAULT_TEMPLATES)) {
      if (!type || template.type === type) {
        templates.push({
          id: `default_${key}`,
          ...template,
          isDefault: true,
        });
      }
    }

    res.json({ data: templates });
  } catch (error) {
    console.error('List templates error:', error);
    res.status(500).json({ error: 'Failed to list templates', code: 'SERVER_ERROR' });
  }
});

// Get template by ID
router.get('/templates/:templateId', authenticate, async (req, res) => {
  try {
    const { templateId } = req.params;

    // Check for default template
    if (templateId.startsWith('default_')) {
      const key = templateId.replace('default_', '');
      if (DEFAULT_TEMPLATES[key]) {
        return res.json({
          data: {
            id: templateId,
            ...DEFAULT_TEMPLATES[key],
            isDefault: true,
          },
        });
      }
    }

    const result = await query(
      `SELECT * FROM calculator_templates
       WHERE id = $1 AND (org_id = $2 OR is_public = TRUE) AND is_active = TRUE`,
      [templateId, req.user.orgId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Template not found', code: 'NOT_FOUND' });
    }

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Get template error:', error);
    res.status(500).json({ error: 'Failed to get template', code: 'SERVER_ERROR' });
  }
});

// Create custom template
router.post('/templates', authenticate, sanitizeInput, async (req, res) => {
  try {
    const { error, value } = createTemplateSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { name, description, type, inputSchema, calculationLogic, outputSchema, isPublic } = value;

    // Validate calculation logic doesn't contain dangerous operations
    const logicStr = JSON.stringify(calculationLogic);
    if (logicStr.includes('eval') || logicStr.includes('Function') || logicStr.includes('exec')) {
      return res.status(400).json({ error: 'Invalid calculation logic', code: 'VALIDATION_ERROR' });
    }

    const result = await query(
      `INSERT INTO calculator_templates (org_id, name, description, type, input_schema, calculation_logic, output_schema, is_public, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [req.user.orgId, name, description, type, inputSchema, calculationLogic, outputSchema, isPublic, req.user.id]
    );

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Create template error:', error);
    res.status(500).json({ error: 'Failed to create template', code: 'SERVER_ERROR' });
  }
});

// ============================================
// SESSION ROUTES
// ============================================

// Create calculation session
router.post('/sessions', authenticate, sanitizeInput, async (req, res) => {
  try {
    const { error, value } = createSessionSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { templateId, dealRoomId, sessionName, inputs, notes } = value;

    // Get template
    let template;
    if (templateId.startsWith('default_')) {
      const key = templateId.replace('default_', '');
      template = DEFAULT_TEMPLATES[key];
      if (!template) {
        return res.status(404).json({ error: 'Template not found', code: 'NOT_FOUND' });
      }
    } else {
      const templateResult = await query(
        `SELECT * FROM calculator_templates WHERE id = $1 AND is_active = TRUE`,
        [templateId]
      );
      if (templateResult.rows.length === 0) {
        return res.status(404).json({ error: 'Template not found', code: 'NOT_FOUND' });
      }
      template = templateResult.rows[0];
    }

    // Execute calculation
    const outputs = calculationEngine.execute(template.calculationLogic || template.calculation_logic, inputs);

    // Store session
    const result = await query(
      `INSERT INTO calculator_sessions (template_id, deal_room_id, user_id, session_name, inputs, outputs, notes)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [templateId.startsWith('default_') ? null : templateId, dealRoomId, req.user.id, sessionName, inputs, outputs, notes]
    );

    res.status(201).json({
      data: {
        session: result.rows[0],
        outputs,
        outputSchema: template.outputSchema || template.output_schema,
      },
    });
  } catch (error) {
    console.error('Create session error:', error);
    res.status(500).json({ error: 'Failed to create calculation session', code: 'SERVER_ERROR' });
  }
});

// Calculate without saving
router.post('/calculate', authenticate, sanitizeInput, async (req, res) => {
  try {
    const { templateId, inputs } = req.body;

    // Validate inputs
    const { error } = calculatorInputSchema.validate(inputs);
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Get template
    let template;
    if (templateId.startsWith('default_')) {
      const key = templateId.replace('default_', '');
      template = DEFAULT_TEMPLATES[key];
    } else {
      const templateResult = await query(
        `SELECT * FROM calculator_templates WHERE id = $1 AND is_active = TRUE`,
        [templateId]
      );
      if (templateResult.rows.length === 0) {
        return res.status(404).json({ error: 'Template not found', code: 'NOT_FOUND' });
      }
      template = templateResult.rows[0];
    }

    if (!template) {
      return res.status(404).json({ error: 'Template not found', code: 'NOT_FOUND' });
    }

    // Execute calculation
    const outputs = calculationEngine.execute(template.calculationLogic || template.calculation_logic, inputs);

    res.json({
      data: {
        outputs,
        outputSchema: template.outputSchema || template.output_schema,
      },
    });
  } catch (error) {
    console.error('Calculate error:', error);
    res.status(500).json({ error: 'Calculation failed', code: 'SERVER_ERROR' });
  }
});

// Get session
router.get('/sessions/:sessionId', authenticate, async (req, res) => {
  try {
    const { sessionId } = req.params;

    const result = await query(
      `SELECT cs.*, ct.name as template_name, ct.type as template_type, ct.output_schema
       FROM calculator_sessions cs
       LEFT JOIN calculator_templates ct ON cs.template_id = ct.id
       WHERE cs.id = $1 AND cs.user_id = $2`,
      [sessionId, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Session not found', code: 'NOT_FOUND' });
    }

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Get session error:', error);
    res.status(500).json({ error: 'Failed to get session', code: 'SERVER_ERROR' });
  }
});

// List sessions
router.get('/sessions', authenticate, async (req, res) => {
  try {
    const { dealRoomId, page, limit } = req.query;
    const pagination = require('../utils/database').buildPaginationClause(page, limit, 50);

    let whereClause = 'cs.user_id = $1';
    const params = [req.user.id];

    if (dealRoomId) {
      whereClause += ' AND cs.deal_room_id = $2';
      params.push(dealRoomId);
    }

    const result = await query(
      `SELECT cs.id, cs.session_name, cs.created_at, cs.updated_at,
              ct.name as template_name, ct.type as template_type
       FROM calculator_sessions cs
       LEFT JOIN calculator_templates ct ON cs.template_id = ct.id
       WHERE ${whereClause}
       ORDER BY cs.updated_at DESC
       ${pagination.clause}`,
      params
    );

    res.json({ data: result.rows, pagination });
  } catch (error) {
    console.error('List sessions error:', error);
    res.status(500).json({ error: 'Failed to list sessions', code: 'SERVER_ERROR' });
  }
});

// ============================================
// SCENARIO ROUTES
// ============================================

// Create scenario
router.post('/sessions/:sessionId/scenarios', authenticate, sanitizeInput, async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { error, value } = createScenarioSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Verify session ownership
    const sessionCheck = await query(
      `SELECT cs.*, ct.calculation_logic FROM calculator_sessions cs
       LEFT JOIN calculator_templates ct ON cs.template_id = ct.id
       WHERE cs.id = $1 AND cs.user_id = $2`,
      [sessionId, req.user.id]
    );

    if (sessionCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Session not found', code: 'NOT_FOUND' });
    }

    const session = sessionCheck.rows[0];
    const { name, description, inputs, isBaseline } = value;

    // Calculate outputs for scenario
    const calcLogic = session.calculation_logic || 
                      DEFAULT_TEMPLATES[session.template_id?.replace('default_', '')]?.calculationLogic;
    
    const outputs = calculationEngine.execute(calcLogic, inputs);

    // If setting as baseline, unset other baselines
    if (isBaseline) {
      await query(
        'UPDATE calculator_scenarios SET is_baseline = FALSE WHERE session_id = $1',
        [sessionId]
      );
    }

    const result = await query(
      `INSERT INTO calculator_scenarios (session_id, name, description, inputs, outputs, is_baseline, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [sessionId, name, description, inputs, outputs, isBaseline, req.user.id]
    );

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Create scenario error:', error);
    res.status(500).json({ error: 'Failed to create scenario', code: 'SERVER_ERROR' });
  }
});

// Compare scenarios
router.get('/sessions/:sessionId/compare', authenticate, async (req, res) => {
  try {
    const { sessionId } = req.params;

    const scenarios = await query(
      `SELECT * FROM calculator_scenarios
       WHERE session_id = $1
       ORDER BY is_baseline DESC, created_at`,
      [sessionId]
    );

    if (scenarios.rows.length < 2) {
      return res.status(400).json({ 
        error: 'Need at least 2 scenarios to compare', 
        code: 'INSUFFICIENT_SCENARIOS' 
      });
    }

    const baseline = scenarios.rows.find(s => s.is_baseline) || scenarios.rows[0];
    const comparisons = scenarios.rows
      .filter(s => s.id !== baseline.id)
      .map(scenario => {
        const differences = {};
        for (const [key, value] of Object.entries(scenario.outputs)) {
          const baselineValue = baseline.outputs[key];
          if (typeof value === 'number' && typeof baselineValue === 'number') {
            differences[key] = {
              absolute: value - baselineValue,
              percentage: baselineValue !== 0 ? ((value - baselineValue) / baselineValue) * 100 : null,
            };
          }
        }
        return {
          scenario,
          differences,
        };
      });

    res.json({
      data: {
        baseline,
        comparisons,
      },
    });
  } catch (error) {
    console.error('Compare scenarios error:', error);
    res.status(500).json({ error: 'Failed to compare scenarios', code: 'SERVER_ERROR' });
  }
});

// Generate shareable link
router.post('/sessions/:sessionId/share', authenticate, async (req, res) => {
  try {
    const { sessionId } = req.params;

    const sessionCheck = await query(
      'SELECT id FROM calculator_sessions WHERE id = $1 AND user_id = $2',
      [sessionId, req.user.id]
    );

    if (sessionCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Session not found', code: 'NOT_FOUND' });
    }

    const shareToken = crypto.randomUUID();

    await query(
      'UPDATE calculator_sessions SET is_shared = TRUE, share_token = $1 WHERE id = $2',
      [shareToken, sessionId]
    );

    const shareUrl = `${process.env.APP_URL}/calculator/shared/${shareToken}`;

    res.json({ data: { shareUrl, shareToken } });
  } catch (error) {
    console.error('Share session error:', error);
    res.status(500).json({ error: 'Failed to share session', code: 'SERVER_ERROR' });
  }
});

// Access shared session (no auth required)
router.get('/shared/:shareToken', async (req, res) => {
  try {
    const { shareToken } = req.params;

    const result = await query(
      `SELECT cs.inputs, cs.outputs, ct.name as template_name, ct.output_schema
       FROM calculator_sessions cs
       LEFT JOIN calculator_templates ct ON cs.template_id = ct.id
       WHERE cs.share_token = $1 AND cs.is_shared = TRUE`,
      [shareToken]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Shared session not found', code: 'NOT_FOUND' });
    }

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Get shared session error:', error);
    res.status(500).json({ error: 'Failed to get shared session', code: 'SERVER_ERROR' });
  }
});

module.exports = router;
