/**
 * CDLS Platform - Module 5: Mutual Action Plans
 * Security Review: Access control, input validation, dependency validation
 */

const express = require('express');
const Joi = require('joi');
const { query, transaction, buildPaginationClause } = require('../utils/database');
const { authenticate, checkDealRoomAccess, sanitizeInput } = require('../middleware/security');

const router = express.Router();

// ============================================
// VALIDATION SCHEMAS
// ============================================

const createActionPlanSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255).required(),
  description: Joi.string().trim().max(5000).allow('', null),
  targetCloseDate: Joi.date().iso().min('now').allow(null),
  isSharedWithBuyer: Joi.boolean().default(false),
});

const updateActionPlanSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255),
  description: Joi.string().trim().max(5000).allow('', null),
  status: Joi.string().valid('draft', 'active', 'completed', 'cancelled'),
  targetCloseDate: Joi.date().iso().allow(null),
  isSharedWithBuyer: Joi.boolean(),
}).min(1);

const createMilestoneSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255).required(),
  description: Joi.string().trim().max(2000).allow('', null),
  sequenceOrder: Joi.number().integer().min(0).required(),
  dueDate: Joi.date().iso().allow(null),
  ownerType: Joi.string().valid('seller', 'buyer', 'both').allow(null),
});

const updateMilestoneSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255),
  description: Joi.string().trim().max(2000).allow('', null),
  status: Joi.string().valid('pending', 'in_progress', 'completed', 'blocked', 'skipped'),
  sequenceOrder: Joi.number().integer().min(0),
  dueDate: Joi.date().iso().allow(null),
  ownerType: Joi.string().valid('seller', 'buyer', 'both').allow(null),
}).min(1);

const createActionItemSchema = Joi.object({
  milestoneId: Joi.string().uuid().required(),
  title: Joi.string().trim().min(1).max(255).required(),
  description: Joi.string().trim().max(2000).allow('', null),
  priority: Joi.string().valid('low', 'medium', 'high', 'critical').default('medium'),
  ownerType: Joi.string().valid('seller', 'buyer').allow(null),
  assignedTo: Joi.string().uuid().allow(null),
  stakeholderId: Joi.string().uuid().allow(null),
  dueDate: Joi.date().iso().allow(null),
  sequenceOrder: Joi.number().integer().min(0).required(),
  dependencies: Joi.array().items(Joi.string().uuid()).default([]),
});

const updateActionItemSchema = Joi.object({
  title: Joi.string().trim().min(1).max(255),
  description: Joi.string().trim().max(2000).allow('', null),
  status: Joi.string().valid('pending', 'in_progress', 'completed', 'blocked', 'cancelled'),
  priority: Joi.string().valid('low', 'medium', 'high', 'critical'),
  ownerType: Joi.string().valid('seller', 'buyer').allow(null),
  assignedTo: Joi.string().uuid().allow(null),
  stakeholderId: Joi.string().uuid().allow(null),
  dueDate: Joi.date().iso().allow(null),
  sequenceOrder: Joi.number().integer().min(0),
  dependencies: Joi.array().items(Joi.string().uuid()),
}).min(1);

const addCommentSchema = Joi.object({
  content: Joi.string().trim().min(1).max(5000).required(),
  isInternal: Joi.boolean().default(false),
});

// ============================================
// HELPER FUNCTIONS
// ============================================

const calculatePlanProgress = async (actionPlanId) => {
  const result = await query(
    `SELECT 
       COUNT(*) as total,
       COUNT(*) FILTER (WHERE status = 'completed') as completed,
       COUNT(*) FILTER (WHERE status = 'blocked') as blocked
     FROM action_items
     WHERE action_plan_id = $1`,
    [actionPlanId]
  );

  const { total, completed, blocked } = result.rows[0];
  const totalNum = parseInt(total, 10);
  const completedNum = parseInt(completed, 10);

  if (totalNum === 0) return 0;
  return Math.round((completedNum / totalNum) * 100);
};

const updatePlanProgress = async (actionPlanId) => {
  const progress = await calculatePlanProgress(actionPlanId);
  await query(
    'UPDATE action_plans SET progress_percentage = $1 WHERE id = $2',
    [progress, actionPlanId]
  );
  return progress;
};

const checkDependencies = async (actionItemId, dependencies) => {
  if (!dependencies || dependencies.length === 0) return { valid: true };

  // Check for circular dependencies
  const visited = new Set([actionItemId]);
  const toCheck = [...dependencies];

  while (toCheck.length > 0) {
    const depId = toCheck.pop();
    if (visited.has(depId)) {
      return { valid: false, error: 'Circular dependency detected' };
    }
    visited.add(depId);

    // Get dependencies of this item
    const depResult = await query(
      'SELECT dependencies FROM action_items WHERE id = $1',
      [depId]
    );

    if (depResult.rows.length > 0 && depResult.rows[0].dependencies) {
      toCheck.push(...depResult.rows[0].dependencies);
    }
  }

  // Check all dependencies exist and are in same action plan
  const depCheck = await query(
    `SELECT id, action_plan_id FROM action_items WHERE id = ANY($1)`,
    [dependencies]
  );

  if (depCheck.rows.length !== dependencies.length) {
    return { valid: false, error: 'One or more dependencies not found' };
  }

  return { valid: true };
};

const getBlockedItems = async (actionItemId) => {
  // Find all items that depend on this one
  const result = await query(
    `SELECT id, title FROM action_items WHERE $1 = ANY(dependencies)`,
    [actionItemId]
  );
  return result.rows;
};

// ============================================
// ACTION PLAN ROUTES
// ============================================

// Create action plan
router.post('/:dealRoomId/action-plans', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { error, value } = createActionPlanSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { name, description, targetCloseDate, isSharedWithBuyer } = value;

    const result = await query(
      `INSERT INTO action_plans (deal_room_id, name, description, target_close_date, is_shared_with_buyer, created_by)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [dealRoomId, name, description, targetCloseDate, isSharedWithBuyer, req.user.id]
    );

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Create action plan error:', error);
    res.status(500).json({ error: 'Failed to create action plan', code: 'SERVER_ERROR' });
  }
});

// List action plans
router.get('/:dealRoomId/action-plans', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { status, page, limit } = req.query;
    const pagination = buildPaginationClause(page, limit, 20);

    let whereClause = 'deal_room_id = $1';
    const params = [dealRoomId];

    if (status) {
      whereClause += ' AND status = $2';
      params.push(status);
    }

    const result = await query(
      `SELECT ap.*,
              (SELECT COUNT(*) FROM milestones m WHERE m.action_plan_id = ap.id) as milestone_count,
              (SELECT COUNT(*) FROM action_items ai WHERE ai.action_plan_id = ap.id) as action_item_count,
              (SELECT COUNT(*) FROM action_items ai WHERE ai.action_plan_id = ap.id AND ai.status = 'completed') as completed_count,
              u.first_name || ' ' || u.last_name as created_by_name
       FROM action_plans ap
       LEFT JOIN users u ON ap.created_by = u.id
       WHERE ${whereClause}
       ORDER BY ap.created_at DESC
       ${pagination.clause}`,
      params
    );

    res.json({ data: result.rows, pagination });
  } catch (error) {
    console.error('List action plans error:', error);
    res.status(500).json({ error: 'Failed to list action plans', code: 'SERVER_ERROR' });
  }
});

// Get action plan with full details
router.get('/:dealRoomId/action-plans/:planId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId, planId } = req.params;

    const planResult = await query(
      `SELECT ap.*, u.first_name || ' ' || u.last_name as created_by_name
       FROM action_plans ap
       LEFT JOIN users u ON ap.created_by = u.id
       WHERE ap.id = $1 AND ap.deal_room_id = $2`,
      [planId, dealRoomId]
    );

    if (planResult.rows.length === 0) {
      return res.status(404).json({ error: 'Action plan not found', code: 'NOT_FOUND' });
    }

    // Get milestones with action items
    const milestonesResult = await query(
      `SELECT m.*,
              COALESCE(json_agg(
                json_build_object(
                  'id', ai.id,
                  'title', ai.title,
                  'description', ai.description,
                  'status', ai.status,
                  'priority', ai.priority,
                  'ownerType', ai.owner_type,
                  'assignedTo', ai.assigned_to,
                  'stakeholderId', ai.stakeholder_id,
                  'dueDate', ai.due_date,
                  'completedDate', ai.completed_date,
                  'sequenceOrder', ai.sequence_order,
                  'dependencies', ai.dependencies
                ) ORDER BY ai.sequence_order
              ) FILTER (WHERE ai.id IS NOT NULL), '[]') as action_items
       FROM milestones m
       LEFT JOIN action_items ai ON m.id = ai.milestone_id
       WHERE m.action_plan_id = $1
       GROUP BY m.id
       ORDER BY m.sequence_order`,
      [planId]
    );

    res.json({
      data: {
        ...planResult.rows[0],
        milestones: milestonesResult.rows,
      },
    });
  } catch (error) {
    console.error('Get action plan error:', error);
    res.status(500).json({ error: 'Failed to get action plan', code: 'SERVER_ERROR' });
  }
});

// Update action plan
router.patch('/:dealRoomId/action-plans/:planId', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { dealRoomId, planId } = req.params;
    const { error, value } = updateActionPlanSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const fieldMapping = {
      name: 'name',
      description: 'description',
      status: 'status',
      targetCloseDate: 'target_close_date',
      isSharedWithBuyer: 'is_shared_with_buyer',
    };

    const updates = [];
    const params = [];
    let paramIndex = 1;

    for (const [jsField, dbField] of Object.entries(fieldMapping)) {
      if (value[jsField] !== undefined) {
        updates.push(`${dbField} = $${paramIndex}`);
        params.push(value[jsField]);
        paramIndex++;
      }
    }

    // Handle shared_at timestamp
    if (value.isSharedWithBuyer === true) {
      updates.push(`shared_at = NOW()`);
    }

    // Handle actual_close_date when completing
    if (value.status === 'completed') {
      updates.push(`actual_close_date = CURRENT_DATE`);
    }

    params.push(planId, dealRoomId);

    const result = await query(
      `UPDATE action_plans SET ${updates.join(', ')}
       WHERE id = $${paramIndex} AND deal_room_id = $${paramIndex + 1}
       RETURNING *`,
      params
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Action plan not found', code: 'NOT_FOUND' });
    }

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Update action plan error:', error);
    res.status(500).json({ error: 'Failed to update action plan', code: 'SERVER_ERROR' });
  }
});

// Delete action plan
router.delete('/:dealRoomId/action-plans/:planId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId, planId } = req.params;

    const result = await query(
      'DELETE FROM action_plans WHERE id = $1 AND deal_room_id = $2 RETURNING id',
      [planId, dealRoomId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Action plan not found', code: 'NOT_FOUND' });
    }

    res.json({ message: 'Action plan deleted successfully' });
  } catch (error) {
    console.error('Delete action plan error:', error);
    res.status(500).json({ error: 'Failed to delete action plan', code: 'SERVER_ERROR' });
  }
});

// ============================================
// MILESTONE ROUTES
// ============================================

// Create milestone
router.post('/:dealRoomId/action-plans/:planId/milestones', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { planId } = req.params;
    const { error, value } = createMilestoneSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { name, description, sequenceOrder, dueDate, ownerType } = value;

    const result = await query(
      `INSERT INTO milestones (action_plan_id, name, description, sequence_order, due_date, owner_type)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [planId, name, description, sequenceOrder, dueDate, ownerType]
    );

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Create milestone error:', error);
    res.status(500).json({ error: 'Failed to create milestone', code: 'SERVER_ERROR' });
  }
});

// Update milestone
router.patch('/:dealRoomId/action-plans/:planId/milestones/:milestoneId', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { planId, milestoneId } = req.params;
    const { error, value } = updateMilestoneSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const fieldMapping = {
      name: 'name',
      description: 'description',
      status: 'status',
      sequenceOrder: 'sequence_order',
      dueDate: 'due_date',
      ownerType: 'owner_type',
    };

    const updates = [];
    const params = [];
    let paramIndex = 1;

    for (const [jsField, dbField] of Object.entries(fieldMapping)) {
      if (value[jsField] !== undefined) {
        updates.push(`${dbField} = $${paramIndex}`);
        params.push(value[jsField]);
        paramIndex++;
      }
    }

    if (value.status === 'completed') {
      updates.push(`completed_date = CURRENT_DATE`);
    }

    params.push(milestoneId, planId);

    const result = await query(
      `UPDATE milestones SET ${updates.join(', ')}
       WHERE id = $${paramIndex} AND action_plan_id = $${paramIndex + 1}
       RETURNING *`,
      params
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Milestone not found', code: 'NOT_FOUND' });
    }

    // Update plan progress
    await updatePlanProgress(planId);

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Update milestone error:', error);
    res.status(500).json({ error: 'Failed to update milestone', code: 'SERVER_ERROR' });
  }
});

// Delete milestone
router.delete('/:dealRoomId/action-plans/:planId/milestones/:milestoneId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { planId, milestoneId } = req.params;

    const result = await query(
      'DELETE FROM milestones WHERE id = $1 AND action_plan_id = $2 RETURNING id',
      [milestoneId, planId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Milestone not found', code: 'NOT_FOUND' });
    }

    await updatePlanProgress(planId);

    res.json({ message: 'Milestone deleted successfully' });
  } catch (error) {
    console.error('Delete milestone error:', error);
    res.status(500).json({ error: 'Failed to delete milestone', code: 'SERVER_ERROR' });
  }
});

// ============================================
// ACTION ITEM ROUTES
// ============================================

// Create action item
router.post('/:dealRoomId/action-plans/:planId/items', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { planId } = req.params;
    const { error, value } = createActionItemSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const {
      milestoneId, title, description, priority, ownerType,
      assignedTo, stakeholderId, dueDate, sequenceOrder, dependencies,
    } = value;

    // Verify milestone belongs to this action plan
    const milestoneCheck = await query(
      'SELECT id FROM milestones WHERE id = $1 AND action_plan_id = $2',
      [milestoneId, planId]
    );

    if (milestoneCheck.rows.length === 0) {
      return res.status(400).json({ error: 'Milestone not found in this action plan', code: 'INVALID_MILESTONE' });
    }

    const result = await query(
      `INSERT INTO action_items 
       (milestone_id, action_plan_id, title, description, priority, owner_type, assigned_to, stakeholder_id, due_date, sequence_order, dependencies, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       RETURNING *`,
      [milestoneId, planId, title, description, priority, ownerType, assignedTo, stakeholderId, dueDate, sequenceOrder, dependencies, req.user.id]
    );

    await updatePlanProgress(planId);

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Create action item error:', error);
    res.status(500).json({ error: 'Failed to create action item', code: 'SERVER_ERROR' });
  }
});

// Update action item
router.patch('/:dealRoomId/action-plans/:planId/items/:itemId', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { planId, itemId } = req.params;
    const { error, value } = updateActionItemSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Validate dependencies if provided
    if (value.dependencies && value.dependencies.length > 0) {
      const depCheck = await checkDependencies(itemId, value.dependencies);
      if (!depCheck.valid) {
        return res.status(400).json({ error: depCheck.error, code: 'INVALID_DEPENDENCIES' });
      }
    }

    const fieldMapping = {
      title: 'title',
      description: 'description',
      status: 'status',
      priority: 'priority',
      ownerType: 'owner_type',
      assignedTo: 'assigned_to',
      stakeholderId: 'stakeholder_id',
      dueDate: 'due_date',
      sequenceOrder: 'sequence_order',
      dependencies: 'dependencies',
    };

    const updates = [];
    const params = [];
    let paramIndex = 1;

    for (const [jsField, dbField] of Object.entries(fieldMapping)) {
      if (value[jsField] !== undefined) {
        if (jsField === 'dependencies') {
          updates.push(`${dbField} = $${paramIndex}::jsonb`);
          params.push(JSON.stringify(value[jsField]));
        } else {
          updates.push(`${dbField} = $${paramIndex}`);
          params.push(value[jsField]);
        }
        paramIndex++;
      }
    }

    if (value.status === 'completed') {
      updates.push(`completed_date = CURRENT_DATE`);
      updates.push(`completed_by = $${paramIndex}`);
      params.push(req.user.id);
      paramIndex++;
    }

    params.push(itemId, planId);

    const result = await query(
      `UPDATE action_items SET ${updates.join(', ')}
       WHERE id = $${paramIndex} AND action_plan_id = $${paramIndex + 1}
       RETURNING *`,
      params
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Action item not found', code: 'NOT_FOUND' });
    }

    // Check if this completion unblocks other items
    let unblockedItems = [];
    if (value.status === 'completed') {
      unblockedItems = await getBlockedItems(itemId);
    }

    await updatePlanProgress(planId);

    res.json({ 
      data: result.rows[0],
      unblockedItems,
    });
  } catch (error) {
    console.error('Update action item error:', error);
    res.status(500).json({ error: 'Failed to update action item', code: 'SERVER_ERROR' });
  }
});

// Delete action item
router.delete('/:dealRoomId/action-plans/:planId/items/:itemId', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { planId, itemId } = req.params;

    // Check if any items depend on this one
    const blockedItems = await getBlockedItems(itemId);
    if (blockedItems.length > 0) {
      return res.status(400).json({
        error: 'Cannot delete item with dependencies',
        code: 'HAS_DEPENDENCIES',
        blockedItems,
      });
    }

    const result = await query(
      'DELETE FROM action_items WHERE id = $1 AND action_plan_id = $2 RETURNING id',
      [itemId, planId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Action item not found', code: 'NOT_FOUND' });
    }

    await updatePlanProgress(planId);

    res.json({ message: 'Action item deleted successfully' });
  } catch (error) {
    console.error('Delete action item error:', error);
    res.status(500).json({ error: 'Failed to delete action item', code: 'SERVER_ERROR' });
  }
});

// ============================================
// COMMENT ROUTES
// ============================================

// Add comment to action item
router.post('/:dealRoomId/action-plans/:planId/items/:itemId/comments', authenticate, checkDealRoomAccess, sanitizeInput, async (req, res) => {
  try {
    const { planId, itemId } = req.params;
    const { error, value } = addCommentSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    // Verify item exists
    const itemCheck = await query(
      'SELECT id FROM action_items WHERE id = $1 AND action_plan_id = $2',
      [itemId, planId]
    );

    if (itemCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Action item not found', code: 'NOT_FOUND' });
    }

    const { content, isInternal } = value;

    const result = await query(
      `INSERT INTO action_item_comments (action_item_id, user_id, content, is_internal)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [itemId, req.user.id, content, isInternal]
    );

    // Get user info for response
    const userResult = await query(
      'SELECT first_name, last_name, email FROM users WHERE id = $1',
      [req.user.id]
    );

    res.status(201).json({
      data: {
        ...result.rows[0],
        user: userResult.rows[0],
      },
    });
  } catch (error) {
    console.error('Add comment error:', error);
    res.status(500).json({ error: 'Failed to add comment', code: 'SERVER_ERROR' });
  }
});

// Get comments for action item
router.get('/:dealRoomId/action-plans/:planId/items/:itemId/comments', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { itemId } = req.params;
    const { includeInternal } = req.query;

    let whereClause = 'aic.action_item_id = $1';
    const params = [itemId];

    // Only show internal comments to authenticated org members
    if (includeInternal !== 'true') {
      whereClause += ' AND aic.is_internal = FALSE';
    }

    const result = await query(
      `SELECT aic.*, u.first_name, u.last_name, u.email
       FROM action_item_comments aic
       JOIN users u ON aic.user_id = u.id
       WHERE ${whereClause}
       ORDER BY aic.created_at ASC`,
      params
    );

    res.json({ data: result.rows });
  } catch (error) {
    console.error('Get comments error:', error);
    res.status(500).json({ error: 'Failed to get comments', code: 'SERVER_ERROR' });
  }
});

// ============================================
// ANALYTICS & REPORTING
// ============================================

// Get action plan analytics
router.get('/:dealRoomId/action-plans/:planId/analytics', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { planId } = req.params;

    // Overall progress
    const progressResult = await query(
      `SELECT 
         COUNT(*) as total_items,
         COUNT(*) FILTER (WHERE status = 'completed') as completed,
         COUNT(*) FILTER (WHERE status = 'in_progress') as in_progress,
         COUNT(*) FILTER (WHERE status = 'blocked') as blocked,
         COUNT(*) FILTER (WHERE status = 'pending') as pending,
         COUNT(*) FILTER (WHERE due_date < CURRENT_DATE AND status NOT IN ('completed', 'cancelled')) as overdue
       FROM action_items
       WHERE action_plan_id = $1`,
      [planId]
    );

    // By owner type
    const byOwnerResult = await query(
      `SELECT 
         owner_type,
         COUNT(*) as total,
         COUNT(*) FILTER (WHERE status = 'completed') as completed
       FROM action_items
       WHERE action_plan_id = $1
       GROUP BY owner_type`,
      [planId]
    );

    // By priority
    const byPriorityResult = await query(
      `SELECT 
         priority,
         COUNT(*) as total,
         COUNT(*) FILTER (WHERE status = 'completed') as completed
       FROM action_items
       WHERE action_plan_id = $1
       GROUP BY priority`,
      [planId]
    );

    // Milestone progress
    const milestoneProgress = await query(
      `SELECT 
         m.id, m.name, m.status, m.due_date,
         COUNT(ai.id) as total_items,
         COUNT(ai.id) FILTER (WHERE ai.status = 'completed') as completed_items
       FROM milestones m
       LEFT JOIN action_items ai ON m.id = ai.milestone_id
       WHERE m.action_plan_id = $1
       GROUP BY m.id
       ORDER BY m.sequence_order`,
      [planId]
    );

    // Activity timeline (last 30 days)
    const activityResult = await query(
      `SELECT 
         DATE(updated_at) as date,
         COUNT(*) FILTER (WHERE status = 'completed') as completed
       FROM action_items
       WHERE action_plan_id = $1 AND updated_at > NOW() - INTERVAL '30 days'
       GROUP BY DATE(updated_at)
       ORDER BY date`,
      [planId]
    );

    res.json({
      data: {
        summary: progressResult.rows[0],
        byOwner: byOwnerResult.rows,
        byPriority: byPriorityResult.rows,
        milestones: milestoneProgress.rows,
        activityTimeline: activityResult.rows,
      },
    });
  } catch (error) {
    console.error('Get analytics error:', error);
    res.status(500).json({ error: 'Failed to get analytics', code: 'SERVER_ERROR' });
  }
});

// Export action plan to shareable format
router.get('/:dealRoomId/action-plans/:planId/export', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { planId, dealRoomId } = req.params;
    const { format = 'json' } = req.query;

    const planResult = await query(
      `SELECT ap.*, dr.name as deal_room_name
       FROM action_plans ap
       JOIN deal_rooms dr ON ap.deal_room_id = dr.id
       WHERE ap.id = $1`,
      [planId]
    );

    if (planResult.rows.length === 0) {
      return res.status(404).json({ error: 'Action plan not found', code: 'NOT_FOUND' });
    }

    const milestonesResult = await query(
      `SELECT m.*, 
              json_agg(
                json_build_object(
                  'title', ai.title,
                  'status', ai.status,
                  'priority', ai.priority,
                  'ownerType', ai.owner_type,
                  'dueDate', ai.due_date
                ) ORDER BY ai.sequence_order
              ) FILTER (WHERE ai.id IS NOT NULL) as items
       FROM milestones m
       LEFT JOIN action_items ai ON m.id = ai.milestone_id
       WHERE m.action_plan_id = $1
       GROUP BY m.id
       ORDER BY m.sequence_order`,
      [planId]
    );

    const exportData = {
      exportedAt: new Date().toISOString(),
      plan: planResult.rows[0],
      milestones: milestonesResult.rows,
    };

    if (format === 'json') {
      res.json({ data: exportData });
    } else {
      // Could add CSV/PDF export here
      res.json({ data: exportData });
    }
  } catch (error) {
    console.error('Export action plan error:', error);
    res.status(500).json({ error: 'Failed to export action plan', code: 'SERVER_ERROR' });
  }
});

module.exports = router;
