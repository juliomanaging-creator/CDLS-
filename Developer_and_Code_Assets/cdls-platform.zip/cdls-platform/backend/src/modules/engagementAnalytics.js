/**
 * CDLS Platform - Module 2: Engagement Analytics
 * Security Review: Rate limiting, data validation, PII protection
 */

const express = require('express');
const Joi = require('joi');
const { query, buildPaginationClause } = require('../utils/database');
const { authenticate, checkDealRoomAccess, sanitizeInput, createRateLimiter } = require('../middleware/security');

const router = express.Router();

// Rate limiter for event tracking (prevent abuse)
const eventRateLimiter = createRateLimiter({
  windowMs: 60000, // 1 minute
  max: 100, // 100 events per minute per user
});

// ============================================
// VALIDATION SCHEMAS
// ============================================

const trackEventSchema = Joi.object({
  dealRoomId: Joi.string().uuid().required(),
  eventType: Joi.string().valid(
    'page_view', 'document_view', 'document_download', 'time_spent',
    'scroll_depth', 'section_view', 'calculator_use', 'share', 'comment'
  ).required(),
  entityType: Joi.string().valid('deal_room', 'document', 'section', 'calculator', 'page'),
  entityId: Joi.string().uuid(),
  metadata: Joi.object().default({}),
  durationSeconds: Joi.number().integer().min(0).max(86400), // Max 24 hours
  scrollPercentage: Joi.number().integer().min(0).max(100),
  sessionId: Joi.string().max(64),
});

const batchEventsSchema = Joi.object({
  events: Joi.array().items(trackEventSchema).min(1).max(50).required(),
});

const dateRangeSchema = Joi.object({
  startDate: Joi.date().iso().required(),
  endDate: Joi.date().iso().min(Joi.ref('startDate')).required(),
});

// ============================================
// HELPER FUNCTIONS
// ============================================

const calculateEngagementScore = (events) => {
  let score = 0;
  
  const weights = {
    page_view: 1,
    document_view: 5,
    document_download: 10,
    time_spent: 0.1, // Per second
    scroll_depth: 0.5, // Per percentage point
    section_view: 3,
    calculator_use: 15,
    share: 20,
    comment: 25,
  };

  for (const event of events) {
    const baseScore = weights[event.event_type] || 0;
    
    if (event.event_type === 'time_spent') {
      score += baseScore * (event.duration_seconds || 0);
    } else if (event.event_type === 'scroll_depth') {
      score += baseScore * (event.scroll_percentage || 0);
    } else {
      score += baseScore;
    }
  }

  // Normalize to 0-100 scale
  return Math.min(100, Math.round(score));
};

const determineTrend = (currentScore, previousScore) => {
  if (!previousScore) return 'stable';
  const diff = currentScore - previousScore;
  if (diff > 10) return 'rising';
  if (diff < -10) return 'declining';
  return 'stable';
};

// Mask PII for analytics
const maskUserData = (events) => {
  return events.map(event => ({
    ...event,
    ip_address: event.ip_address ? event.ip_address.replace(/\d+$/, 'xxx') : null,
    user_agent: event.user_agent ? event.user_agent.substring(0, 50) + '...' : null,
  }));
};

// ============================================
// EVENT TRACKING ROUTES
// ============================================

// Track single event
router.post('/events', authenticate, eventRateLimiter, sanitizeInput, async (req, res) => {
  try {
    const { error, value } = trackEventSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { dealRoomId, eventType, entityType, entityId, metadata, durationSeconds, scrollPercentage, sessionId } = value;

    // Verify user has access to this deal room
    const accessCheck = await query(
      `SELECT 1 FROM deal_room_members WHERE deal_room_id = $1 AND user_id = $2`,
      [dealRoomId, req.user.id]
    );

    if (accessCheck.rows.length === 0) {
      return res.status(403).json({ error: 'Access denied', code: 'FORBIDDEN' });
    }

    const result = await query(
      `INSERT INTO engagement_events 
       (deal_room_id, user_id, session_id, event_type, entity_type, entity_id, metadata, duration_seconds, scroll_percentage, ip_address, user_agent)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
       RETURNING id, event_type, created_at`,
      [dealRoomId, req.user.id, sessionId, eventType, entityType, entityId, metadata, durationSeconds, scrollPercentage, req.ip, req.get('user-agent')]
    );

    // Check for alert-triggering conditions
    await checkAndCreateAlerts(dealRoomId, req.user.id, eventType, entityId);

    res.status(201).json({ data: result.rows[0] });
  } catch (error) {
    console.error('Track event error:', error);
    res.status(500).json({ error: 'Failed to track event', code: 'SERVER_ERROR' });
  }
});

// Batch track events
router.post('/events/batch', authenticate, eventRateLimiter, sanitizeInput, async (req, res) => {
  try {
    const { error, value } = batchEventsSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
    }

    const { events } = value;
    const insertedIds = [];

    // Use transaction for batch insert
    const client = await require('../utils/database').pool.connect();
    try {
      await client.query('BEGIN');

      for (const event of events) {
        const result = await client.query(
          `INSERT INTO engagement_events 
           (deal_room_id, user_id, session_id, event_type, entity_type, entity_id, metadata, duration_seconds, scroll_percentage, ip_address, user_agent)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
           RETURNING id`,
          [event.dealRoomId, req.user.id, event.sessionId, event.eventType, event.entityType, event.entityId, event.metadata, event.durationSeconds, event.scrollPercentage, req.ip, req.get('user-agent')]
        );
        insertedIds.push(result.rows[0].id);
      }

      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }

    res.status(201).json({ 
      data: { 
        insertedCount: insertedIds.length,
        ids: insertedIds 
      } 
    });
  } catch (error) {
    console.error('Batch track events error:', error);
    res.status(500).json({ error: 'Failed to track events', code: 'SERVER_ERROR' });
  }
});

// ============================================
// ANALYTICS DASHBOARD ROUTES
// ============================================

// Get deal room engagement summary
router.get('/deal-rooms/:dealRoomId/summary', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { startDate, endDate } = req.query;

    let dateFilter = '';
    const params = [dealRoomId];

    if (startDate && endDate) {
      const { error } = dateRangeSchema.validate({ startDate, endDate });
      if (error) {
        return res.status(400).json({ error: error.details[0].message, code: 'VALIDATION_ERROR' });
      }
      dateFilter = 'AND created_at BETWEEN $2 AND $3';
      params.push(startDate, endDate);
    }

    // Total events by type
    const eventsByType = await query(
      `SELECT event_type, COUNT(*) as count
       FROM engagement_events
       WHERE deal_room_id = $1 ${dateFilter}
       GROUP BY event_type`,
      params
    );

    // Unique visitors
    const uniqueVisitors = await query(
      `SELECT COUNT(DISTINCT user_id) as count
       FROM engagement_events
       WHERE deal_room_id = $1 ${dateFilter}`,
      params
    );

    // Total time spent
    const totalTime = await query(
      `SELECT COALESCE(SUM(duration_seconds), 0) as total_seconds
       FROM engagement_events
       WHERE deal_room_id = $1 AND event_type = 'time_spent' ${dateFilter}`,
      params
    );

    // Most viewed documents
    const topDocuments = await query(
      `SELECT entity_id, COUNT(*) as view_count
       FROM engagement_events
       WHERE deal_room_id = $1 AND event_type = 'document_view' AND entity_id IS NOT NULL ${dateFilter}
       GROUP BY entity_id
       ORDER BY view_count DESC
       LIMIT 5`,
      params
    );

    // Engagement over time (daily)
    const timeline = await query(
      `SELECT DATE(created_at) as date, COUNT(*) as events, COUNT(DISTINCT user_id) as visitors
       FROM engagement_events
       WHERE deal_room_id = $1 ${dateFilter}
       GROUP BY DATE(created_at)
       ORDER BY date`,
      params
    );

    res.json({
      data: {
        eventsByType: eventsByType.rows,
        uniqueVisitors: parseInt(uniqueVisitors.rows[0].count, 10),
        totalTimeSeconds: parseInt(totalTime.rows[0].total_seconds, 10),
        topDocuments: topDocuments.rows,
        timeline: timeline.rows,
      },
    });
  } catch (error) {
    console.error('Get engagement summary error:', error);
    res.status(500).json({ error: 'Failed to get engagement summary', code: 'SERVER_ERROR' });
  }
});

// Get engagement by stakeholder
router.get('/deal-rooms/:dealRoomId/stakeholders', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { page, limit } = req.query;
    const pagination = buildPaginationClause(page, limit, 50);

    const result = await query(
      `SELECT 
         u.id as user_id,
         u.email,
         u.first_name,
         u.last_name,
         COUNT(*) as total_events,
         COUNT(DISTINCT DATE(ee.created_at)) as active_days,
         MAX(ee.created_at) as last_activity,
         COALESCE(SUM(CASE WHEN ee.event_type = 'time_spent' THEN ee.duration_seconds ELSE 0 END), 0) as total_time_seconds,
         COUNT(CASE WHEN ee.event_type = 'document_view' THEN 1 END) as document_views,
         COUNT(CASE WHEN ee.event_type = 'document_download' THEN 1 END) as downloads
       FROM engagement_events ee
       JOIN users u ON ee.user_id = u.id
       WHERE ee.deal_room_id = $1
       GROUP BY u.id, u.email, u.first_name, u.last_name
       ORDER BY total_events DESC
       ${pagination.clause}`,
      [dealRoomId]
    );

    // Calculate engagement scores
    const stakeholdersWithScores = await Promise.all(result.rows.map(async (stakeholder) => {
      const recentEvents = await query(
        `SELECT event_type, duration_seconds, scroll_percentage
         FROM engagement_events
         WHERE deal_room_id = $1 AND user_id = $2 AND created_at > NOW() - INTERVAL '7 days'`,
        [dealRoomId, stakeholder.user_id]
      );

      const score = calculateEngagementScore(recentEvents.rows);

      return {
        ...stakeholder,
        engagementScore: score,
        isChampion: score >= 70,
        riskLevel: score < 20 ? 'high' : score < 50 ? 'medium' : 'low',
      };
    }));

    res.json({ data: stakeholdersWithScores, pagination });
  } catch (error) {
    console.error('Get stakeholder engagement error:', error);
    res.status(500).json({ error: 'Failed to get stakeholder engagement', code: 'SERVER_ERROR' });
  }
});

// Get document heatmap data
router.get('/documents/:documentId/heatmap', authenticate, async (req, res) => {
  try {
    const { documentId } = req.params;

    // Verify access
    const docCheck = await query(
      `SELECT dr.id as deal_room_id FROM documents d
       JOIN deal_rooms dr ON d.deal_room_id = dr.id
       JOIN deal_room_members drm ON dr.id = drm.deal_room_id
       WHERE d.id = $1 AND drm.user_id = $2`,
      [documentId, req.user.id]
    );

    if (docCheck.rows.length === 0) {
      return res.status(403).json({ error: 'Access denied', code: 'FORBIDDEN' });
    }

    // Get aggregated heatmap data
    const result = await query(
      `SELECT 
         COALESCE((metadata->>'page_number')::int, 1) as page_number,
         COUNT(*) as view_count,
         COALESCE(SUM(duration_seconds), 0) as total_time_seconds,
         COALESCE(AVG(scroll_percentage), 0) as avg_scroll_depth
       FROM engagement_events
       WHERE entity_id = $1 AND entity_type = 'document'
       GROUP BY (metadata->>'page_number')::int
       ORDER BY page_number`,
      [documentId]
    );

    res.json({ data: result.rows });
  } catch (error) {
    console.error('Get document heatmap error:', error);
    res.status(500).json({ error: 'Failed to get document heatmap', code: 'SERVER_ERROR' });
  }
});

// ============================================
// ENGAGEMENT SCORES
// ============================================

// Get current engagement score
router.get('/deal-rooms/:dealRoomId/score', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;

    // Get latest score
    const latestScore = await query(
      `SELECT * FROM engagement_scores
       WHERE deal_room_id = $1 AND user_id IS NULL
       ORDER BY score_date DESC
       LIMIT 1`,
      [dealRoomId]
    );

    // Get previous score for trend
    const previousScore = await query(
      `SELECT overall_score FROM engagement_scores
       WHERE deal_room_id = $1 AND user_id IS NULL
       ORDER BY score_date DESC
       OFFSET 1
       LIMIT 1`,
      [dealRoomId]
    );

    if (latestScore.rows.length === 0) {
      // Calculate fresh score
      const events = await query(
        `SELECT event_type, duration_seconds, scroll_percentage
         FROM engagement_events
         WHERE deal_room_id = $1 AND created_at > NOW() - INTERVAL '7 days'`,
        [dealRoomId]
      );

      const score = calculateEngagementScore(events.rows);
      const trend = determineTrend(score, previousScore.rows[0]?.overall_score);

      return res.json({
        data: {
          overallScore: score,
          trend,
          calculatedAt: new Date().toISOString(),
          isRealtime: true,
        },
      });
    }

    const trend = determineTrend(
      latestScore.rows[0].overall_score,
      previousScore.rows[0]?.overall_score
    );

    res.json({
      data: {
        ...latestScore.rows[0],
        trend,
      },
    });
  } catch (error) {
    console.error('Get engagement score error:', error);
    res.status(500).json({ error: 'Failed to get engagement score', code: 'SERVER_ERROR' });
  }
});

// Score history
router.get('/deal-rooms/:dealRoomId/score/history', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { days = 30 } = req.query;

    const result = await query(
      `SELECT score_date, overall_score, view_score, time_score, interaction_score, trend
       FROM engagement_scores
       WHERE deal_room_id = $1 AND user_id IS NULL AND score_date > NOW() - INTERVAL '1 day' * $2
       ORDER BY score_date`,
      [dealRoomId, Math.min(parseInt(days, 10), 365)]
    );

    res.json({ data: result.rows });
  } catch (error) {
    console.error('Get score history error:', error);
    res.status(500).json({ error: 'Failed to get score history', code: 'SERVER_ERROR' });
  }
});

// ============================================
// ALERTS
// ============================================

// Check and create engagement alerts
const checkAndCreateAlerts = async (dealRoomId, userId, eventType, entityId) => {
  try {
    // High engagement alert - key document viewed
    if (eventType === 'document_view') {
      const docCheck = await query(
        `SELECT name, is_confidential FROM documents WHERE id = $1`,
        [entityId]
      );

      if (docCheck.rows[0]?.is_confidential) {
        await query(
          `INSERT INTO engagement_alerts (deal_room_id, user_id, alert_type, severity, title, message, metadata)
           VALUES ($1, $2, 'key_document_viewed', 'info', 'Key Document Viewed', $3, $4)`,
          [dealRoomId, userId, `A confidential document was viewed: ${docCheck.rows[0].name}`, { documentId: entityId }]
        );
      }
    }

    // Engagement spike detection
    const recentCount = await query(
      `SELECT COUNT(*) FROM engagement_events
       WHERE deal_room_id = $1 AND user_id = $2 AND created_at > NOW() - INTERVAL '1 hour'`,
      [dealRoomId, userId]
    );

    if (parseInt(recentCount.rows[0].count, 10) > 20) {
      const existingAlert = await query(
        `SELECT id FROM engagement_alerts
         WHERE deal_room_id = $1 AND user_id = $2 AND alert_type = 'engagement_spike' AND created_at > NOW() - INTERVAL '1 hour'`,
        [dealRoomId, userId]
      );

      if (existingAlert.rows.length === 0) {
        await query(
          `INSERT INTO engagement_alerts (deal_room_id, user_id, alert_type, severity, title, message)
           VALUES ($1, $2, 'engagement_spike', 'warning', 'Engagement Spike Detected', 'High activity detected from this stakeholder')`,
          [dealRoomId, userId]
        );
      }
    }
  } catch (error) {
    console.error('Check alerts error:', error);
    // Don't throw - this is a background task
  }
};

// Get alerts
router.get('/deal-rooms/:dealRoomId/alerts', authenticate, checkDealRoomAccess, async (req, res) => {
  try {
    const { dealRoomId } = req.params;
    const { unreadOnly, page, limit } = req.query;
    const pagination = buildPaginationClause(page, limit, 50);

    let whereClause = 'deal_room_id = $1';
    const params = [dealRoomId];

    if (unreadOnly === 'true') {
      whereClause += ' AND is_read = FALSE';
    }

    const result = await query(
      `SELECT ea.*, u.email, u.first_name, u.last_name
       FROM engagement_alerts ea
       LEFT JOIN users u ON ea.user_id = u.id
       WHERE ${whereClause}
       ORDER BY ea.created_at DESC
       ${pagination.clause}`,
      params
    );

    res.json({ data: result.rows, pagination });
  } catch (error) {
    console.error('Get alerts error:', error);
    res.status(500).json({ error: 'Failed to get alerts', code: 'SERVER_ERROR' });
  }
});

// Mark alert as read
router.patch('/alerts/:alertId/read', authenticate, async (req, res) => {
  try {
    const { alertId } = req.params;

    const result = await query(
      `UPDATE engagement_alerts SET is_read = TRUE, read_at = NOW()
       WHERE id = $1
       RETURNING *`,
      [alertId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Alert not found', code: 'NOT_FOUND' });
    }

    res.json({ data: result.rows[0] });
  } catch (error) {
    console.error('Mark alert read error:', error);
    res.status(500).json({ error: 'Failed to update alert', code: 'SERVER_ERROR' });
  }
});

module.exports = router;
