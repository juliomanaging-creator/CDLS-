/**
 * CDLS Platform - Database Utilities
 * Security Review: Parameterized queries, connection pooling, SQL injection prevention
 */

const { Pool } = require('pg');
const config = require('../config');

// Create connection pool with secure defaults
const pool = new Pool({
  connectionString: config.database.url,
  ssl: config.database.ssl ? { rejectUnauthorized: true } : false,
  min: config.database.pool.min,
  max: config.database.pool.max,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

// Test connection on startup
pool.on('connect', () => {
  console.log('Database connection established');
});

pool.on('error', (err) => {
  console.error('Unexpected database error:', err);
  process.exit(-1);
});

/**
 * Execute a parameterized query
 * SECURITY: Always use parameterized queries to prevent SQL injection
 * @param {string} text - SQL query with $1, $2, etc. placeholders
 * @param {Array} params - Query parameters
 * @returns {Promise<Object>} Query result
 */
const query = async (text, params = []) => {
  const start = Date.now();
  try {
    const result = await pool.query(text, params);
    const duration = Date.now() - start;
    
    // Log query performance (without sensitive data)
    if (config.env === 'development') {
      console.log({
        query: text.substring(0, 100),
        duration: `${duration}ms`,
        rows: result.rowCount,
      });
    }
    
    return result;
  } catch (error) {
    console.error('Database query error:', {
      query: text.substring(0, 100),
      error: error.message,
    });
    throw error;
  }
};

/**
 * Execute query within a transaction
 * @param {Function} callback - Async function receiving client
 * @returns {Promise<any>} Transaction result
 */
const transaction = async (callback) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
};

/**
 * Build a safe WHERE clause from filters
 * SECURITY: Prevents SQL injection by using parameterized queries
 * @param {Object} filters - Key-value pairs for WHERE conditions
 * @param {number} startIndex - Starting parameter index
 * @returns {Object} { clause: string, values: Array, nextIndex: number }
 */
const buildWhereClause = (filters, startIndex = 1) => {
  const conditions = [];
  const values = [];
  let index = startIndex;
  
  // Whitelist of allowed column names
  const allowedColumns = [
    'id', 'org_id', 'user_id', 'deal_room_id', 'stakeholder_id',
    'status', 'type', 'created_at', 'updated_at', 'name', 'email',
    'document_id', 'event_type', 'is_active', 'stage'
  ];
  
  for (const [key, value] of Object.entries(filters)) {
    // SECURITY: Only allow whitelisted column names
    const columnName = key.replace(/[^a-z_]/gi, '');
    if (!allowedColumns.includes(columnName)) {
      throw new Error(`Invalid column name: ${key}`);
    }
    
    if (value === null) {
      conditions.push(`${columnName} IS NULL`);
    } else if (Array.isArray(value)) {
      const placeholders = value.map((_, i) => `$${index + i}`).join(', ');
      conditions.push(`${columnName} IN (${placeholders})`);
      values.push(...value);
      index += value.length;
    } else {
      conditions.push(`${columnName} = $${index}`);
      values.push(value);
      index++;
    }
  }
  
  return {
    clause: conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '',
    values,
    nextIndex: index,
  };
};

/**
 * Build safe ORDER BY clause
 * SECURITY: Whitelist approach for column names
 * @param {string} column - Column to sort by
 * @param {string} direction - ASC or DESC
 * @param {Array} allowedColumns - Whitelist of sortable columns
 * @returns {string} ORDER BY clause
 */
const buildOrderByClause = (column, direction = 'DESC', allowedColumns = []) => {
  const safeColumn = column?.replace(/[^a-z_]/gi, '');
  const safeDirection = direction?.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
  
  if (!safeColumn || !allowedColumns.includes(safeColumn)) {
    return 'ORDER BY created_at DESC';
  }
  
  return `ORDER BY ${safeColumn} ${safeDirection}`;
};

/**
 * Build safe pagination clause
 * SECURITY: Validate and constrain pagination values
 * @param {number} page - Page number (1-indexed)
 * @param {number} limit - Items per page
 * @param {number} maxLimit - Maximum allowed limit
 * @returns {Object} { clause: string, offset: number, limit: number }
 */
const buildPaginationClause = (page = 1, limit = 20, maxLimit = 100) => {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(maxLimit, Math.max(1, parseInt(limit, 10) || 20));
  const offset = (safePage - 1) * safeLimit;
  
  return {
    clause: `LIMIT ${safeLimit} OFFSET ${offset}`,
    offset,
    limit: safeLimit,
    page: safePage,
  };
};

/**
 * Escape special characters for LIKE queries
 * SECURITY: Prevents LIKE injection
 * @param {string} value - Value to escape
 * @returns {string} Escaped value
 */
const escapeLike = (value) => {
  if (typeof value !== 'string') return '';
  return value.replace(/[%_\\]/g, '\\$&');
};

// Graceful shutdown
const shutdown = async () => {
  console.log('Closing database connections...');
  await pool.end();
  console.log('Database connections closed');
};

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

module.exports = {
  query,
  transaction,
  buildWhereClause,
  buildOrderByClause,
  buildPaginationClause,
  escapeLike,
  pool,
};
