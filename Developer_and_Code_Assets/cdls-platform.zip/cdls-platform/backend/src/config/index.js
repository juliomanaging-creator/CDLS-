/**
 * CDLS Platform - Secure Configuration
 * Security Review: Environment validation, no hardcoded secrets
 */

const Joi = require('joi');

// Environment variable validation schema
const envSchema = Joi.object({
  NODE_ENV: Joi.string().valid('development', 'staging', 'production').required(),
  PORT: Joi.number().default(3001),
  
  // Database - NEVER hardcode credentials
  DATABASE_URL: Joi.string().required(),
  DB_SSL: Joi.boolean().default(true),
  DB_POOL_MIN: Joi.number().default(2),
  DB_POOL_MAX: Joi.number().default(10),
  
  // JWT Configuration
  JWT_SECRET: Joi.string().min(32).required(),
  JWT_EXPIRES_IN: Joi.string().default('24h'),
  JWT_REFRESH_EXPIRES_IN: Joi.string().default('7d'),
  
  // Rate Limiting
  RATE_LIMIT_WINDOW_MS: Joi.number().default(900000), // 15 minutes
  RATE_LIMIT_MAX_REQUESTS: Joi.number().default(100),
  
  // AWS S3 for document storage
  AWS_ACCESS_KEY_ID: Joi.string().required(),
  AWS_SECRET_ACCESS_KEY: Joi.string().required(),
  AWS_S3_BUCKET: Joi.string().required(),
  AWS_REGION: Joi.string().default('us-west-2'),
  
  // Encryption
  ENCRYPTION_KEY: Joi.string().length(32).required(),
  
  // CORS
  CORS_ORIGINS: Joi.string().default('http://localhost:3000'),
  
  // Session
  SESSION_SECRET: Joi.string().min(32).required(),
}).unknown();

const { error, value: envVars } = envSchema.validate(process.env);

if (error) {
  throw new Error(`Configuration validation error: ${error.message}`);
}

module.exports = {
  env: envVars.NODE_ENV,
  port: envVars.PORT,
  isProduction: envVars.NODE_ENV === 'production',
  
  database: {
    url: envVars.DATABASE_URL,
    ssl: envVars.DB_SSL,
    pool: {
      min: envVars.DB_POOL_MIN,
      max: envVars.DB_POOL_MAX,
    },
  },
  
  jwt: {
    secret: envVars.JWT_SECRET,
    expiresIn: envVars.JWT_EXPIRES_IN,
    refreshExpiresIn: envVars.JWT_REFRESH_EXPIRES_IN,
  },
  
  rateLimit: {
    windowMs: envVars.RATE_LIMIT_WINDOW_MS,
    maxRequests: envVars.RATE_LIMIT_MAX_REQUESTS,
  },
  
  aws: {
    accessKeyId: envVars.AWS_ACCESS_KEY_ID,
    secretAccessKey: envVars.AWS_SECRET_ACCESS_KEY,
    s3Bucket: envVars.AWS_S3_BUCKET,
    region: envVars.AWS_REGION,
  },
  
  encryption: {
    key: envVars.ENCRYPTION_KEY,
  },
  
  cors: {
    origins: envVars.CORS_ORIGINS.split(','),
  },
  
  session: {
    secret: envVars.SESSION_SECRET,
  },
};
