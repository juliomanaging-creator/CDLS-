// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

/**
 * @title HAUL Token - California Dealer Logistics Solutions
 * @notice Revenue-backed utility token for zero-emission vehicle hauling network
 * @dev Implements tiered profit-sharing mechanism for dealer network participants
 * 
 * TOKENOMICS STRUCTURE:
 * - LP Tier (Limited Partners): 20% revenue share
 * - GP Tier (General Partners): 40% revenue share  
 * - Strategic Tier: 60% revenue share
 * 
 * TOKEN UTILITY:
 * 1. Governance: Vote on network policies, pricing structures, infrastructure investments
 * 2. Fee Reduction: Reduce platform fees by staking $HAUL
 * 3. Priority Access: Premium route assignments and capacity allocation
 * 4. Liquidity Mining: Earn yield by providing DEX liquidity
 */
contract HAULToken is ERC20, AccessControl, ReentrancyGuard {
    
    // ============================================
    // ACCESS CONTROL ROLES
    // ============================================
    bytes32 public constant SETTLEMENT_ROLE = keccak256("SETTLEMENT_ROLE");
    bytes32 public constant ADMIN_ROLE = keccak256("ADMIN_ROLE");
    
    // ============================================
    // DEALER TIER STRUCTURE
    // ============================================
    enum DealerTier { LP, GP, Strategic }
    
    struct DealerProfile {
        address walletAddress;
        string dealerId;
        string dealerName;
        DealerTier tier;
        uint256 totalHaulEarned;
        uint256 totalRevenueGenerated;
        uint256 totalUnitsHauled;
        uint256 joinDate;
        bool active;
    }
    
    // ============================================
    // SETTLEMENT TRACKING
    // ============================================
    struct Settlement {
        bytes32 batchId;
        address dealer;
        uint256 haulMinted;
        uint256 revenueAmount;
        uint256 unitsHauled;
        uint256 timestamp;
        bool confirmed;
    }
    
    // ============================================
    // STATE VARIABLES
    // ============================================
    mapping(address => DealerProfile) public dealers;
    mapping(bytes32 => Settlement) public settlements;
    mapping(DealerTier => uint256) public tierAllocations;
    
    address[] public dealerList;
    bytes32[] public settlementHistory;
    
    uint256 public totalNetworkRevenue;
    uint256 public totalUnitsHauled;
    uint256 public constant MAX_SUPPLY = 100_000_000 * 10**18; // 100M tokens
    
    // ============================================
    // EVENTS
    // ============================================
    event DealerRegistered(address indexed dealer, string dealerId, DealerTier tier);
    event BatchSettled(bytes32 indexed batchId, address indexed dealer, uint256 haulMinted, uint256 revenue);
    event TierUpdated(address indexed dealer, DealerTier oldTier, DealerTier newTier);
    
    // ============================================
    // CONSTRUCTOR
    // ============================================
    constructor() ERC20("HAUL Token", "HAUL") {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
        _grantRole(ADMIN_ROLE, msg.sender);
        _grantRole(SETTLEMENT_ROLE, msg.sender);
        
        // Initialize tier allocations (percentage * 100 for precision)
        tierAllocations[DealerTier.LP] = 20;        // 20%
        tierAllocations[DealerTier.GP] = 40;        // 40%
        tierAllocations[DealerTier.Strategic] = 60; // 60%
    }
    
    // ============================================
    // DEALER MANAGEMENT
    // ============================================
    
    /**
     * @notice Register a new dealer in the network
     * @param dealerAddress Ethereum wallet address
     * @param dealerId Unique dealer identifier
     * @param dealerName Business name
     * @param tier Initial dealer tier (LP, GP, or Strategic)
     */
    function registerDealer(
        address dealerAddress,
        string memory dealerId,
        string memory dealerName,
        DealerTier tier
    ) external onlyRole(ADMIN_ROLE) {
        require(!dealers[dealerAddress].active, "Dealer already registered");
        
        dealers[dealerAddress] = DealerProfile({
            walletAddress: dealerAddress,
            dealerId: dealerId,
            dealerName: dealerName,
            tier: tier,
            totalHaulEarned: 0,
            totalRevenueGenerated: 0,
            totalUnitsHauled: 0,
            joinDate: block.timestamp,
            active: true
        });
        
        dealerList.push(dealerAddress);
        
        emit DealerRegistered(dealerAddress, dealerId, tier);
    }
    
    /**
     * @notice Update dealer tier (e.g., LP → GP after capital increase)
     */
    function updateDealerTier(address dealerAddress, DealerTier newTier) 
        external 
        onlyRole(ADMIN_ROLE) 
    {
        require(dealers[dealerAddress].active, "Dealer not found");
        
        DealerTier oldTier = dealers[dealerAddress].tier;
        dealers[dealerAddress].tier = newTier;
        
        emit TierUpdated(dealerAddress, oldTier, newTier);
    }
    
    // ============================================
    // SETTLEMENT EXECUTION
    // ============================================
    
    /**
     * @notice Execute batch settlement and mint $HAUL tokens
     * @param dealerAddress Dealer receiving tokens
     * @param batchId Unique batch identifier
     * @param revenueAmount Total revenue generated in batch (in cents to avoid decimals)
     * @param unitsHauled Number of vehicles hauled
     * 
     * @dev This is called by the off-chain settlement engine after batch validation
     * 
     * SETTLEMENT FLOW:
     * 1. Backend aggregates completed hauls into batch
     * 2. Backend calls this function with validated data
     * 3. Smart contract calculates $HAUL allocation based on tier
     * 4. Tokens are minted directly to dealer wallet
     * 5. Settlement record stored on-chain for transparency
     */
    function settleHaul(
        address dealerAddress,
        bytes32 batchId,
        uint256 revenueAmount,
        uint256 unitsHauled
    ) external onlyRole(SETTLEMENT_ROLE) nonReentrant {
        require(dealers[dealerAddress].active, "Dealer not active");
        require(settlements[batchId].timestamp == 0, "Batch already settled");
        require(revenueAmount > 0 && unitsHauled > 0, "Invalid batch data");
        
        DealerProfile storage dealer = dealers[dealerAddress];
        
        // Calculate $HAUL allocation based on tier
        // Revenue is in cents, so we divide by 100 and multiply by tier percentage
        uint256 haulToMint = (revenueAmount * tierAllocations[dealer.tier]) / 10000;
        
        // Convert to token decimals (18 decimals)
        haulToMint = haulToMint * 10**16; // cents to tokens with 18 decimals
        
        require(totalSupply() + haulToMint <= MAX_SUPPLY, "Would exceed max supply");
        
        // Mint tokens to dealer
        _mint(dealerAddress, haulToMint);
        
        // Update dealer profile
        dealer.totalHaulEarned += haulToMint;
        dealer.totalRevenueGenerated += revenueAmount;
        dealer.totalUnitsHauled += unitsHauled;
        
        // Update network metrics
        totalNetworkRevenue += revenueAmount;
        totalUnitsHauled += unitsHauled;
        
        // Record settlement
        settlements[batchId] = Settlement({
            batchId: batchId,
            dealer: dealerAddress,
            haulMinted: haulToMint,
            revenueAmount: revenueAmount,
            unitsHauled: unitsHauled,
            timestamp: block.timestamp,
            confirmed: true
        });
        
        settlementHistory.push(batchId);
        
        emit BatchSettled(batchId, dealerAddress, haulToMint, revenueAmount);
    }
    
    // ============================================
    // VIEW FUNCTIONS
    // ============================================
    
    /**
     * @notice Get dealer profile information
     */
    function getDealerProfile(address dealerAddress) 
        external 
        view 
        returns (DealerProfile memory) 
    {
        return dealers[dealerAddress];
    }
    
    /**
     * @notice Get settlement details by batch ID
     */
    function getSettlement(bytes32 batchId) 
        external 
        view 
        returns (Settlement memory) 
    {
        return settlements[batchId];
    }
    
    /**
     * @notice Get total number of registered dealers
     */
    function getDealerCount() external view returns (uint256) {
        return dealerList.length;
    }
    
    /**
     * @notice Get network-wide statistics
     */
    function getNetworkStats() external view returns (
        uint256 _totalNetworkRevenue,
        uint256 _totalUnitsHauled,
        uint256 _totalDealers,
        uint256 _totalSupply,
        uint256 _settlementsCount
    ) {
        return (
            totalNetworkRevenue,
            totalUnitsHauled,
            dealerList.length,
            totalSupply(),
            settlementHistory.length
        );
    }
    
    /**
     * @notice Calculate estimated $HAUL for a given revenue and tier
     * @dev Useful for dealers to preview their earnings
     */
    function estimateHaulEarnings(uint256 revenueInCents, DealerTier tier) 
        external 
        view 
        returns (uint256) 
    {
        return (revenueInCents * tierAllocations[tier] * 10**16) / 10000;
    }
}
