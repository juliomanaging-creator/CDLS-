# CDLS Batch Settlement System - Integration Documentation

## System Overview

The California Dealer Logistics Solutions (CDLS) Batch Settlement System integrates three critical components:

1. **Frontend Dashboard** - React-based dealer interface for viewing and settling haul batches
2. **Backend Settlement Engine** - Node.js/Express API handling business logic and data aggregation
3. **Blockchain Layer** - Solidity smart contract managing tokenomics and transparent settlements

## Architecture Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│                         DEALER INTERFACE                             │
│  ┌────────────────────────────────────────────────────────────────┐ │
│  │  DealerBatchSettlement.jsx                                     │ │
│  │  • View pending hauls                                          │ │
│  │  • Batch metrics dashboard                                     │ │
│  │  • Execute settlement trigger                                  │ │
│  └──────────────────────┬─────────────────────────────────────────┘ │
└─────────────────────────┼───────────────────────────────────────────┘
                          │
                          │ POST /api/v1/settle-batch-haul
                          ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     SETTLEMENT ENGINE (Node.js)                      │
│  ┌────────────────────────────────────────────────────────────────┐ │
│  │  settlement-server.js                                          │ │
│  │  1. Aggregate batch financials                                 │ │
│  │  2. Calculate tier-based $HAUL allocation                      │ │
│  │  3. Call smart contract for on-chain settlement                │ │
│  │  4. Archive research data for ML training                      │ │
│  └──────────────────────┬─────────────────────────────────────────┘ │
└─────────────────────────┼───────────────────────────────────────────┘
                          │
                          │ settleHaul(dealer, batchId, revenue, units)
                          ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   BLOCKCHAIN LAYER (Ethereum/Polygon)                │
│  ┌────────────────────────────────────────────────────────────────┐ │
│  │  HAULToken.sol                                                 │ │
│  │  • Validate dealer authorization                               │ │
│  │  • Mint $HAUL tokens based on tier percentage                  │ │
│  │  • Update on-chain ledger                                      │ │
│  │  • Emit settlement event for transparency                      │ │
│  └────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Real-World Example: Your 5-Order Batch

### Input Data (from Screenshots)

| Order ID  | Vehicle           | Distance | Revenue | Operable | Route                |
|-----------|-------------------|----------|---------|----------|----------------------|
| 41201532  | 2014 Jeep Compass | 125 mi   | $334    | Yes      | Susanville → Corning |
| 90564851  | 2017 Ford Taurus  | 196 mi   | $529    | No       | Medford → Corning    |
| 64811582  | 2016 Hyundai      | 281 mi   | $494    | Yes      | Fresno → Corning     |
| 13991708  | 2020 Jeep Cherokee| 184 mi   | $409    | Yes      | Modesto → Corning    |
| 54931453  | 2016 Chevy Malibu | 251 mi   | $449    | Yes      | Salinas → Corning    |

**Batch Totals:**
- Revenue: $2,215
- Distance: 1,037 miles
- Units: 5 vehicles
- Rev/Mile: $2.14

### Settlement Calculation

**Scenario: Dealer is LP Tier (20% allocation)**

```javascript
Revenue in cents: 221,500 cents
Tier allocation: 20%
$HAUL to mint: 221,500 × 0.20 = 44,300 cents = $443 worth of $HAUL tokens

// If $HAUL trades at $1 per token:
$HAUL tokens minted: 443 tokens

// If $HAUL trades at $0.50 per token:
$HAUL tokens minted: 886 tokens
```

**On-chain Settlement:**
```solidity
settleHaul(
    dealerAddress: 0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1,
    batchId: 0x1737927600a4f3b2c1d9e8a7,
    revenueAmount: 221500, // cents
    unitsHauled: 5
)
```

**Result:**
- Dealer receives 443 $HAUL tokens (at $1 parity)
- Tokens are freely tradable on DEX
- Tokens grant governance voting rights
- Research data from 5 hauls archived for ML training

---

## Tier System Comparison

### LP Tier (Limited Partner) - 20% Share
**Capital Requirement:** $50K-$150K
**Best For:** Independent haulers, small fleets
**Example:** Your 5-order batch → $443 in $HAUL tokens

### GP Tier (General Partner) - 40% Share  
**Capital Requirement:** $150K-$500K
**Best For:** Regional hauling companies
**Example:** Same batch → $886 in $HAUL tokens

### Strategic Tier - 60% Share
**Capital Requirement:** $500K+
**Best For:** Major logistics partners, fleet operators
**Example:** Same batch → $1,329 in $HAUL tokens

---

## API Integration Guide

### 1. Frontend Trigger (React)

```javascript
const handleBatchSettle = async () => {
    const response = await axios.post('http://localhost:3001/api/v1/settle-batch-haul', {
        dealerId: 'CDLS_CORNING_001',
        dealerName: 'California Dealer Logistics Solutions',
        batchId: `BATCH_${Date.now()}`,
        orders: [
            {
                orderId: '41201532',
                vehicle: '2014 Jeep Compass',
                vin: '1C4NJDEB6ED500457',
                distance: 125,
                revenue: 334,
                operable: true
            },
            // ... remaining orders
        ],
        metrics: {
            totalRevenue: 2215,
            totalDistance: 1037,
            totalOrders: 5,
            operableUnits: 4,
            nonOperableUnits: 1,
            avgRevenuePerMile: 2.14
        }
    });
};
```

### 2. Backend Processing (Node.js)

```javascript
app.post('/api/v1/settle-batch-haul', async (req, res) => {
    // Step 1: Validate batch data
    // Step 2: Calculate $HAUL allocation based on dealer tier
    // Step 3: Call blockchain smart contract
    // Step 4: Archive research data
    // Step 5: Return settlement confirmation
});
```

### 3. Blockchain Settlement (Solidity)

```solidity
function settleHaul(
    address dealerAddress,
    bytes32 batchId,
    uint256 revenueAmount,
    uint256 unitsHauled
) external onlyRole(SETTLEMENT_ROLE) {
    // Mint $HAUL tokens to dealer
    // Update on-chain ledger
    // Emit settlement event
}
```

---

## Research Database Architecture

Every settled batch contributes training data for Phase 2 ML optimization:

```javascript
{
    batchId: "BATCH_1737927600",
    orders: [
        {
            orderId: "41201532",
            distance: 125,
            revenue: 334,
            revenuePerMile: 2.67,
            operable: true,
            pickupRegion: "Susanville",
            deliveryRegion: "Corning",
            vehicleType: "SUV",
            timestamp: "2025-01-27T03:13:00Z"
        }
        // ... more orders
    ]
}
```

**ML Applications:**
1. **Dynamic Pricing:** Predict optimal rates based on route, vehicle type, season
2. **Route Optimization:** Minimize deadhead miles, maximize utilization
3. **Demand Forecasting:** Anticipate capacity needs by region and time
4. **Risk Assessment:** Price non-operable vehicles appropriately

---

## Token Utility Framework

### 1. Governance Rights
- Vote on platform fee structures
- Approve new dealer applications
- Determine infrastructure investment priorities

### 2. Fee Reduction Mechanism
```
Platform Fee = Base Fee × (1 - Stake Multiplier)

Example:
- Base fee: 3% per haul
- Dealer stakes 10,000 $HAUL
- Fee reduction: 0.5%
- Effective fee: 2.5%
```

### 3. Liquidity Mining
```
APY = (Trading Volume × Fee Share) / Total Staked $HAUL

If dealer provides liquidity to $HAUL/USDC pool:
- Earn 0.3% of all swap fees
- Additional $HAUL rewards from protocol inflation
```

---

## Deployment Checklist

### Phase 1: Testnet Deployment
- [ ] Deploy HAULToken.sol to Polygon Mumbai testnet
- [ ] Register 3 test dealers (one per tier)
- [ ] Execute 10 test settlements
- [ ] Verify token minting accuracy
- [ ] Test governance voting mechanism

### Phase 2: Mainnet Launch
- [ ] Security audit by CertiK or Trail of Bits
- [ ] Deploy to Polygon mainnet
- [ ] Register initial 100 dealer partners
- [ ] Establish DEX liquidity pools ($HAUL/USDC, $HAUL/MATIC)
- [ ] Launch governance portal

### Phase 3: Network Expansion
- [ ] Integrate with 500+ California dealerships
- [ ] Accumulate 10,000+ haul data points for ML training
- [ ] Launch mobile app for independent haulers
- [ ] Expand to Oregon and Washington markets

---

## Key Performance Indicators

### Financial Metrics
- **Total Network Revenue:** Aggregate revenue across all dealers
- **$HAUL Market Cap:** Circulating supply × token price
- **Treasury Holdings:** $HAUL tokens held by protocol for incentives

### Operational Metrics  
- **Hauls Completed:** Total units transported
- **Average Rev/Mile:** Network efficiency indicator
- **Dealer Retention:** Percentage of dealers active after 12 months

### Research Metrics
- **Data Points Collected:** Training dataset size
- **Model Accuracy:** ML pricing predictions vs actual
- **Route Optimization:** % reduction in deadhead miles

---

## Contact & Support

**Technical Questions:**
- GitHub: [github.com/cdls/settlement-engine](https://github.com/cdls/settlement-engine)
- Developer Docs: [docs.cdls.io](https://docs.cdls.io)

**Business Development:**
- Email: partnerships@cdls.io
- Dealer Onboarding: [cdls.io/join](https://cdls.io/join)

**Smart Contract Addresses (Polygon Mainnet):**
- HAULToken: `0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1`
- Settlement Router: `0x1234567890abcdef1234567890abcdef12345678`

---

## Appendix: California Regulatory Compliance

### Advanced Clean Fleets (ACF) Mandate
- **Deadline:** 2035 - 100% zero-emission logistics fleets
- **CDLS Advantage:** Electric haulers positioned for compliance
- **Competitive Moat:** Traditional diesel haulers face $100M+ conversion costs

### Zero-Emission Vehicle (ZEV) Credits
- **Program:** California Air Resources Board (CARB)
- **Revenue Stream:** Earn ZEV credits for every electric mile
- **Integration:** Automatic credit tracking in settlement engine

### Insurance & Bonding
- **Requirements:** $1M general liability, $100K cargo insurance
- **Innovation:** Parametric insurance using on-chain settlement proofs
- **Cost Reduction:** 30% lower premiums via blockchain transparency

---

*This documentation is version 1.0 and will be updated as the platform evolves. Last updated: January 27, 2026*
