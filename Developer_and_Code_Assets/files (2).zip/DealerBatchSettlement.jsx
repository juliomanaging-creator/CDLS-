import React, { useState } from 'react';
import axios from 'axios';

const DealerBatchSettlement = () => {
  const [orders, setOrders] = useState([
    {
      orderId: '41201532',
      orderDate: '07/22/2025',
      vehicle: '2014 Jeep Compass',
      vin: '1C4NJDEB6ED500457',
      distance: 125,
      cost: 334,
      operable: true,
      pickupAddress: '704-485 Richmond Road East Susanville, CA 96130',
      pickupContact: 'Jake Cunningham',
      pickupPhone: '530-257-5092',
      deliveryAddress: '1809 Solano Street Corning, CA 96021',
      deliveryContact: 'Martin Pelayo',
      deliveryPhone: '530-567-6594',
      status: 'pending'
    },
    {
      orderId: '90564851',
      orderDate: '07/25/2025',
      vehicle: '2017 Ford Taurus',
      vin: '1FAHP2F80HG120980',
      distance: 196,
      cost: 529,
      operable: false, // Non-operable requires special handling
      pickupAddress: '828 N CENTRAL AVE MEDFORD, OR 97501',
      pickupContact: 'ANY PICKARD',
      pickupPhone: '(541) 245-1740',
      deliveryAddress: '1809 Solano Street Corning, CA 96021',
      deliveryContact: 'Martin Pelayo',
      deliveryPhone: '530-567-6594',
      status: 'pending',
      notes: 'Text seller 2 hours in advance'
    },
    {
      orderId: '64811582',
      orderDate: '08/01/2025',
      vehicle: '2016 Hyundai TUCSON',
      vin: 'KM8J33A29GU201388',
      distance: 281,
      cost: 494,
      operable: true,
      pickupAddress: '5590 North Blackstone Avenue Fresno, CA 93710',
      pickupContact: 'Kareem Meqdad',
      pickupPhone: '559-433-5553',
      deliveryAddress: '1809 Solano Street Corning, CA 96021',
      deliveryContact: 'Martin Pelayo',
      deliveryPhone: '530-567-6594',
      status: 'pending'
    },
    {
      orderId: '13991708',
      orderDate: '08/28/2025',
      vehicle: '2020 Jeep Cherokee',
      vin: '1C4PJMDN1LD612519',
      distance: 184,
      cost: 409,
      operable: true,
      pickupAddress: '4360 Mchenry Ave Modesto, CA 95356',
      pickupContact: 'Juan Aguilar',
      pickupPhone: '2095508210',
      deliveryAddress: '1809 Solano Street Corning, CA 96021',
      deliveryContact: 'Martin Pelayo',
      deliveryPhone: '530-567-6594',
      status: 'pending'
    },
    {
      orderId: '54931453',
      orderDate: '09/04/2025',
      vehicle: '2016 Chevrolet Malibu',
      vin: '1G1ZE5ST0GF291225',
      distance: 251,
      cost: 449,
      operable: true,
      pickupAddress: '1980 North Davis Road Salinas, CA 93907',
      pickupContact: 'Christian Torres',
      pickupPhone: '8314448444',
      deliveryAddress: '1809 Solano Street Corning, CA 96021',
      deliveryContact: 'Martin Pelayo',
      deliveryPhone: '530-567-6594',
      status: 'pending'
    }
  ]);

  const [settling, setSettling] = useState(false);
  const [settlementResult, setSettlementResult] = useState(null);

  // Calculate batch metrics
  const batchMetrics = {
    totalOrders: orders.length,
    totalDistance: orders.reduce((sum, o) => sum + o.distance, 0),
    totalRevenue: orders.reduce((sum, o) => sum + o.cost, 0),
    operableUnits: orders.filter(o => o.operable).length,
    nonOperableUnits: orders.filter(o => !o.operable).length,
    avgRevenuePerMile: (orders.reduce((sum, o) => sum + o.cost, 0) / 
                        orders.reduce((sum, o) => sum + o.distance, 0)).toFixed(2)
  };

  const handleBatchSettle = async () => {
    setSettling(true);
    try {
      const response = await axios.post('http://localhost:3001/api/v1/settle-batch-haul', {
        dealerId: 'CDLS_CORNING_001',
        dealerName: 'California Dealer Logistics Solutions',
        batchId: `BATCH_${Date.now()}`,
        orders: orders.map(o => ({
          orderId: o.orderId,
          vehicle: o.vehicle,
          vin: o.vin,
          distance: o.distance,
          revenue: o.cost,
          operable: o.operable
        })),
        metrics: batchMetrics
      });

      setSettlementResult(response.data);
      
      // Mark all orders as settled
      setOrders(orders.map(o => ({ ...o, status: 'settled' })));
      
      alert(`✅ Settlement Complete!\n$HAUL Tokens Minted: ${response.data.totalHaulMinted}\nTransaction ID: ${response.data.transactionId}`);
    } catch (error) {
      console.error('Settlement failed:', error);
      alert('❌ Settlement failed. Check logs.');
    } finally {
      setSettling(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 mb-8 border border-white/20">
          <h1 className="text-4xl font-bold text-white mb-2">
            🚛 CDLS Batch Settlement Dashboard
          </h1>
          <p className="text-blue-200">Zero-Emission Vehicle Hauling - California Advanced Clean Fleets Compliant</p>
        </div>

        {/* Batch Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-green-500 to-green-700 rounded-xl p-6 text-white">
            <div className="text-3xl font-bold">{batchMetrics.totalOrders}</div>
            <div className="text-green-100">Total Orders</div>
          </div>
          <div className="bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl p-6 text-white">
            <div className="text-3xl font-bold">{batchMetrics.totalDistance}</div>
            <div className="text-blue-100">Total Miles</div>
          </div>
          <div className="bg-gradient-to-br from-purple-500 to-purple-700 rounded-xl p-6 text-white">
            <div className="text-3xl font-bold">${batchMetrics.totalRevenue}</div>
            <div className="text-purple-100">Batch Revenue</div>
          </div>
          <div className="bg-gradient-to-br from-yellow-500 to-yellow-700 rounded-xl p-6 text-white">
            <div className="text-3xl font-bold">${batchMetrics.avgRevenuePerMile}</div>
            <div className="text-yellow-100">Rev/Mile</div>
          </div>
        </div>

        {/* Orders Table */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 overflow-hidden mb-8">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-black/30">
                <tr>
                  <th className="px-6 py-4 text-left text-white font-semibold">Order ID</th>
                  <th className="px-6 py-4 text-left text-white font-semibold">Vehicle</th>
                  <th className="px-6 py-4 text-left text-white font-semibold">Route</th>
                  <th className="px-6 py-4 text-center text-white font-semibold">Distance</th>
                  <th className="px-6 py-4 text-center text-white font-semibold">Revenue</th>
                  <th className="px-6 py-4 text-center text-white font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {orders.map((order) => (
                  <tr key={order.orderId} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 text-white font-mono">{order.orderId}</td>
                    <td className="px-6 py-4">
                      <div className="text-white font-semibold">{order.vehicle}</div>
                      <div className="text-gray-400 text-sm">{order.vin}</div>
                      {!order.operable && (
                        <span className="inline-block mt-1 px-2 py-1 bg-red-500/20 text-red-300 text-xs rounded">
                          Non-Operable
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-white text-sm">{order.pickupAddress.split(',')[1]}</div>
                      <div className="text-gray-400 text-xs">→ {order.deliveryAddress.split(',')[1]}</div>
                    </td>
                    <td className="px-6 py-4 text-center text-white font-semibold">{order.distance} mi</td>
                    <td className="px-6 py-4 text-center text-green-400 font-bold">${order.cost}</td>
                    <td className="px-6 py-4 text-center">
                      {order.status === 'pending' ? (
                        <span className="px-3 py-1 bg-yellow-500/20 text-yellow-300 rounded-full text-sm">
                          Pending
                        </span>
                      ) : (
                        <span className="px-3 py-1 bg-green-500/20 text-green-300 rounded-full text-sm">
                          Settled ✓
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Settlement Action */}
        <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-bold mb-2">Ready to Settle Batch</h3>
              <p className="text-blue-100">
                This will mint $HAUL tokens proportional to your dealer tier and revenue contribution
              </p>
            </div>
            <button
              onClick={handleBatchSettle}
              disabled={settling || orders.some(o => o.status === 'settled')}
              className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold text-lg shadow-2xl hover:bg-blue-50 disabled:bg-gray-400 disabled:text-gray-600 transition-all transform hover:scale-105"
            >
              {settling ? '⏳ Processing Settlement...' : '🚀 Execute Settlement & Mint $HAUL'}
            </button>
          </div>
        </div>

        {/* Settlement Result */}
        {settlementResult && (
          <div className="mt-8 bg-green-500/20 backdrop-blur-lg rounded-2xl p-8 border border-green-500/50">
            <h3 className="text-2xl font-bold text-green-300 mb-4">✅ Settlement Successful</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <div className="text-gray-300 mb-1">Transaction ID</div>
                <div className="text-white font-mono">{settlementResult.transactionId}</div>
              </div>
              <div>
                <div className="text-gray-300 mb-1">$HAUL Tokens Minted</div>
                <div className="text-3xl font-bold text-green-400">{settlementResult.totalHaulMinted}</div>
              </div>
              <div>
                <div className="text-gray-300 mb-1">Dealer Tier Share</div>
                <div className="text-white font-semibold">{settlementResult.tierShare}% (LP Tier)</div>
              </div>
              <div>
                <div className="text-gray-300 mb-1">Research Data Points Recorded</div>
                <div className="text-white font-semibold">{settlementResult.dataPointsRecorded}</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DealerBatchSettlement;
